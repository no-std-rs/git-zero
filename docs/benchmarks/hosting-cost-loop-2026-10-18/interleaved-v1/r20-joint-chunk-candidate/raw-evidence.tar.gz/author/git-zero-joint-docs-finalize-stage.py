from pathlib import Path
import hashlib,json
stage=Path('/tmp/git-zero-joint-docs-stage-v1');pub=stage/'r20-joint-chunk-candidate';final=Path('/tmp/git-zero-hosting-joint-chunk/docs/benchmarks/hosting-cost-loop-2026-10-18/interleaved-v1/r20-joint-chunk-candidate')
def record(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
p=pub/'README.md';s=p.read_text();s=s.replace('three completed pairs, three exact variance-proof roots plus the earlier corrected first16 proof, the initial failed64 runtime, and six final bounded controls','six roots from three completed pairs, five offline variance-proof attempts (one initial failed setup and four successful proofs), the initial failed64 runtime, and six final bounded controls');p.write_text(s)
def remap(v):
 if isinstance(v,str) and v.startswith(str(pub)+'/'):return str(final)+v[len(str(pub)):]
 if isinstance(v,list):return [remap(x) for x in v]
 if isinstance(v,dict):return {k:remap(x) for k,x in v.items()}
 return v
for name in ['implementation-ledger.json','publication-validation.json']:
 p=pub/name;j=remap(json.loads(p.read_text()))
 if name=='publication-validation.json':j['staged_readme_count_correction']='Explicit eighteen-root decomposition: six pair roots +five offline proof attempts +one failed runtime +six bounded controls. Handed-off source/raw evidence unchanged.';j['finalize_stage_program']=record(Path(__file__))
 p.write_text(json.dumps(j,indent=2)+'\n')
(pub/'SHA256SUMS').write_text(''.join(f"{record(p)['sha256']}  {p.name}\n" for p in sorted(pub.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
p=stage/'stage-validation.json';j=json.loads(p.read_text());j['files']=[record(p) for p in sorted(pub.iterdir()) if p.is_file()];j['final_publication_path']=str(final);j['post_stage_count_and_path_finalization']=True;p.write_text(json.dumps(j,indent=2)+'\n')
print(json.dumps({'publication':str(pub),'files':len(j['files']),'stage_validation':record(p)},indent=2))
