"""Resource checks and evidence copying only; never starts a runtime or service request."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, stat, sys
receipt_path=Path('/tmp/git-zero-joint-tmpfs-resource-receipt.json')
receipt=json.loads(receipt_path.read_text());prefix=Path(receipt['path'])
mode,name=sys.argv[1:3]
assert name and '/' not in name and name not in ['.','..']
root=prefix/name;meta=Path('/tmp/git-zero-joint-correctness-manifests')/name

def rec(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(4*1024**2):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}

def footprint(path):return sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())

if mode=='preflight':
 upper=int(sys.argv[3]);st=prefix.lstat()
 assert stat.S_ISDIR(st.st_mode) and not prefix.is_symlink() and st.st_uid==1000 and stat.S_IMODE(st.st_mode)==0o700
 assert not root.exists() and not meta.exists()
 mem={k:int(v.split()[0])*1024 for k,v in (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines()) if k in ['MemAvailable','MemTotal','Shmem']}
 used=footprint(prefix);sv=os.statvfs('/dev/shm');tv=os.statvfs('/tmp')
 assert mem['MemAvailable']>=receipt['minimum_memavailable_before_new_scope_bytes']
 assert used+upper<=receipt['artifact_planning_limit_bytes']
 assert sv.f_bavail*sv.f_frsize>=upper and tv.f_bavail*tv.f_frsize>=256*1024**2
 meta.mkdir(parents=True)
 out={'kind':'authorized resource preflight only; no runtime started by this helper','at_utc':datetime.now(timezone.utc).isoformat(),'artifact_root':str(root),'backing':'volatile tmpfs local-only; no performance or power-loss durability claim','resource_receipt':rec(receipt_path),'memory':mem,'shm_available_bytes':sv.f_bavail*sv.f_frsize,'tmp_available_bytes':tv.f_bavail*tv.f_frsize,'existing_volatile_logical_bytes':used,'planned_scope_upper_bytes':upper,'artifact_budget_bytes':receipt['artifact_planning_limit_bytes']}
 (meta/'pre-scope-resource.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
elif mode=='mirror':
 assert root.is_dir() and meta.is_dir();files=[]
 for p in root.iterdir():
  if p.is_file() and p.stat().st_size<=4*1024**2:
   target=meta/p.name;shutil.copy2(p,target);files.append({'persistent':rec(target),'volatile_original':str(p)})
 out={'kind':'persistent compact evidence mirror, not a full volatile raw-state archive','at_utc':datetime.now(timezone.utc).isoformat(),'artifact_root':str(root),'volatile_logical_bytes':footprint(root),'files':files}
 (meta/'compact-mirror-inventory.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'scope':name,'mirrored_files':len(files),'volatile_logical_bytes':out['volatile_logical_bytes']},indent=2))
elif mode=='snapshot':
 rows=[];cache={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   cwd=Path(os.readlink(p/'cwd'))
   if not cwd.is_relative_to(root):continue
   exe=Path(os.readlink(p/'exe'))
   if str(exe) not in cache:cache[str(exe)]=rec(exe)
   rows.append({'pid':int(p.name),'cwd':str(cwd),'exe':str(exe),'exe_file':cache[str(exe)],'cmdline':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')})
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 out={'kind':'actual scoped host process/executable snapshot during local correctness gate','at_utc':datetime.now(timezone.utc).isoformat(),'artifact_root':str(root),'backing':'volatile tmpfs local-only','processes':rows}
 for p in [root/'runtime-processes-host.json',meta/'runtime-processes-host.json']:p.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({'scope':name,'processes':len(rows),'executables':sorted(cache)},indent=2))
else:raise SystemExit('mode must be preflight, mirror or snapshot')
