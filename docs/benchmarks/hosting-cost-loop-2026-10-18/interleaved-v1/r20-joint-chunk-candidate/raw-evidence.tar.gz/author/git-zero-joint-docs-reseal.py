from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
stage=Path('/tmp/git-zero-joint-docs-stage-v1');cap=stage/'capsule';pub=stage/'r20-joint-chunk-candidate';final=Path('/tmp/git-zero-hosting-joint-chunk/docs/benchmarks/hosting-cost-loop-2026-10-18/interleaved-v1/r20-joint-chunk-candidate')
def rec(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(4*1024**2):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
archive=pub/'raw-evidence.tar.gz';old=rec(archive);backup=stage/'raw-evidence-intermediate-v1.tar.gz';assert not backup.exists();shutil.copy2(archive,backup)
mp=cap/'CAPSULE-MANIFEST.json';m=json.loads(mp.read_text());entries={e['archive_path']:e for e in m['files']}
# The original stdout redirect was still empty when copied by its own producer.
# Recopy the complete immutable build log and preserve the original capsule.
for src in [Path('/tmp/git-zero-joint-docs-stage-build-01.log'),Path('/tmp/git-zero-joint-docs-finalize-stage.py'),Path(__file__)]:
 dest=cap/'author'/src.name;shutil.copy2(src,dest);a,b=rec(src),rec(dest);assert a['sha256']==b['sha256'];rel=str(dest.relative_to(cap));entries[rel]={'archive_path':rel,'original':a,'bytes':b['bytes'],'sha256':b['sha256']}
m['files']=[entries[k] for k in sorted(entries)];m['file_count']=len(entries);m['publication_producer_correction']={'original_capsule':old,'preserved_intermediate_capsule':rec(backup),'reason':'Initial builder copied its own still-empty redirected log; final complete log recopied and every original path freshly reverified. Source and raw correctness evidence unchanged.'};mp.write_text(json.dumps(m,indent=2)+'\n')
# Verify ALL copied originals now, not only the immutable archive counterparts.
for e in m['files']:
 a=rec(e['original']['path']);b=rec(cap/e['archive_path']);assert a['bytes']==e['bytes'] and a['sha256']==e['sha256'] and b['sha256']==e['sha256'],e['archive_path']
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in sorted(cap.rglob('*')):
    if p.is_file():tar.add(p,arcname=str(p.relative_to(cap)),recursive=False)
member_bytes=0
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(entries)+2
 for mem in members:
  assert mem.isfile() and not Path(mem.name).is_absolute() and '..' not in Path(mem.name).parts
  f=tar.extractfile(mem);h=hashlib.sha256();n=0
  while b:=f.read(4*1024**2):h.update(b);n+=len(b)
  a=rec(cap/mem.name);assert a['bytes']==n and a['sha256']==h.hexdigest();member_bytes+=n
new=rec(archive);new['path']=str(final/'raw-evidence.tar.gz')
p=pub/'implementation-ledger.json';j=json.loads(p.read_text());j['capsule']['file']=new;j['capsule']['manifest']=rec(mp);j['capsule']['verified_members']=len(members);j['capsule']['uncompressed_member_bytes']=member_bytes;j['publication_producer_correction']=m['publication_producer_correction'];p.write_text(json.dumps(j,indent=2)+'\n')
p=pub/'publication-validation.json';j=json.loads(p.read_text());j['capsule']=new;j['manifest']=rec(mp);j['member_count']=len(members);j['member_bytes']=member_bytes;j['all_copied_original_paths_freshly_SHA_verified']=True;j['copied_original_paths_verified']=len(entries);j['publication_producer_correction']=m['publication_producer_correction'];j['reseal_program']=rec(Path(__file__));p.write_text(json.dumps(j,indent=2)+'\n')
(pub/'SHA256SUMS').write_text(''.join(f"{rec(p)['sha256']}  {p.name}\n" for p in sorted(pub.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
for p in pub.iterdir():shutil.copy2(p,final/p.name)
p=stage/'stage-validation.json';j=json.loads(p.read_text());j['files']=[rec(p) for p in sorted(pub.iterdir()) if p.is_file()];j['capsule_members']=len(members);j['capsule_uncompressed_bytes']=member_bytes;j['all_copied_originals_freshly_verified']=True;j['intermediate_capsule_preserved']=rec(backup);p.write_text(json.dumps(j,indent=2)+'\n')
print(json.dumps({'capsule':new,'members':len(members),'member_bytes':member_bytes,'fresh_verified_originals':len(entries),'intermediate_capsule_preserved':rec(backup)},indent=2))
