"""Seal independent SOURCE-only decision after verifying the final author handoff."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import subprocess

SHA = "b74c91738a3fbfe3ebf30a936fbf9d7ff79f1ae0"
BASE = "f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5"
PREFIX = Path("/tmp/git-zero-joint-source-review-" + SHA)
REPO = Path("/tmp/git-zero-hosting-joint-chunk")
HANDOFF = Path("/tmp/git-zero-joint-chunk-source-handoff.json")

spec = importlib.util.spec_from_file_location("audit", str(PREFIX) + "-audit.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
rec = audit.file_record
read = audit.read_json

assert subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip() == SHA
assert subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD^"], text=True).strip() == BASE
assert subprocess.check_output(["git", "-C", str(REPO), "status", "--porcelain=v1"], text=True) == ""
subprocess.run(["git", "-C", str(REPO), "diff", "--check", "HEAD^", "HEAD"], check=True)

handoff = read(HANDOFF)
assert rec(HANDOFF)["sha256"] == "fd0720e9646777e04fbe4b36d22c20afadf14fc3c9f8fbeb166bc12073032f8b"
assert rec("/tmp/git-zero-joint-chunk-source-handoff.md")["sha256"] == "31f11fa6ab60ee427a627eed23f1d2e0a080d2ed1dd1f939009dec771f6dc118"
assert handoff["source"]["commit"] == SHA and handoff["source"]["parent"] == BASE and handoff["source"]["clean"] is True

records = {}
def validate_records(value):
    if isinstance(value, dict):
        if {"path", "bytes", "sha256"} <= value.keys():
            path = value["path"]
            if path not in records:
                records[path] = rec(path)
            assert records[path]["bytes"] == value["bytes"] and records[path]["sha256"] == value["sha256"], path
        for v in value.values():
            validate_records(v)
    elif isinstance(value, list):
        for v in value:
            validate_records(v)
validate_records(handoff)

pairs_inventory = read(str(PREFIX) + "-sealed-pairs-inventory.json")
control_inventory = read(str(PREFIX) + "-bounded-controls-inventory.json")
actual_roots = {r["root"]: r for r in pairs_inventory["roots"] + control_inventory["roots"]}
old = read("/tmp/git-zero-joint-bounded-evidence-inventory.json")
for r in old["roots"]:
    before = {e["path"]: (e["bytes"], e["sha256"]) for e in r["entries"] if e["kind"] == "file"}
    now = {e["path"]: (e["bytes"], e["sha256"]) for e in actual_roots[r["root"]]["entries"] if e["kind"] == "regular_file"}
    assert before == now, r["root"]
raw_roots = [r for r in actual_roots.values() if r["root"] != "/tmp/git-zero-joint-correctness-manifests"]
assert len(raw_roots) == handoff["raw_scope_inventory"]["root_count"] == 18
assert sum(r["file_count"] for r in raw_roots) == handoff["raw_scope_inventory"]["regular_file_count"] == 7684
assert sum(r["logical_file_bytes"] for r in raw_roots) == handoff["raw_scope_inventory"]["logical_bytes"] == 24347201196

budget_counts = {}
process_coverage = []
for scope in handoff["bounded_scopes"]:
    name = scope["name"]
    root = Path(scope["raw_root"])
    contracts = [read(root / ("allocation-contract.json" if name == "joint-allocation-01" else "contract.json"))]
    if name == "joint-faults-01":
        contracts.append(read(root / "fault-contract.json"))
    if name == "joint-plan-01":
        contracts.append(read(root / "plan-pressure-contract.json"))
    budget_counts[name] = sum(audit.metrics_bounds(c) for c in contracts)
    snapshot = read(root / "runtime-processes-host.json")
    native = [p for p in snapshot["processes"] if Path(p["exe"]).name == "repository-host"]
    if name == "joint-http-01":
        assert snapshot["processes"] == []
        env_scope = "Late empty snapshot after completion; actual live Native/process environment proof absent."
    elif name == "joint-allocation-01":
        assert not native
        env_scope = "Native is in-process in counted allocator runner, not a separate Native process; actual source/runner/runtime maps retained."
    else:
        assert len(native) == 1
        for k, v in native[0]["actual_GIT_environment"].items():
            assert k.startswith("GIT_ZERO_") or k in {"GIT_CONFIG_NOSYSTEM", "GIT_CONFIG_GLOBAL", "GIT_DIR", "GIT_WORK_TREE", "GIT_PROTOCOL", "GIT_USER_AGENT", "GIT_PAGER"} or (k in {"GIT_CONFIG_COUNT", "GIT_TERMINAL_PROMPT"} and v == "0")
        env_scope = "Actual scoped external Native snapshot with known-only Git environment; no claim to cover every restarted Native instance."
    process_coverage.append({"scope": name, "snapshot": rec(root / "runtime-processes-host.json"), "observed_process_count": len(snapshot["processes"]), "observed_external_Native_count": len(native), "proof_scope": env_scope})

cleanup_path = Path("/tmp/git-zero-joint-final-owned-cleanup.json")
cleanup = read(cleanup_path)
volatile = [r for r in actual_roots.values() if r["root"].startswith("/dev/shm/")]
assert sum(r["logical_file_bytes"] for r in volatile) == cleanup["volatile_total_logical_bytes"] == 18411096507
assert cleanup["volatile_total_logical_bytes"] < cleanup["artifact_budget_bytes"] == 24 * 1024**3
assert cleanup["owned_runtime_process_matches"] == []
assert all(p["bind_available"] for p in cleanup["owned_ports"])

inputs = [rec(str(PREFIX) + suffix) for suffix in ["-pair-audit.json", "-scope-audit.json", "-controls-audit.json", "-sealed-pairs-inventory.json", "-bounded-controls-inventory.json", "-audit.py"]]
findings = [
    {"invariant": "Generic Joint/default/control semantics", "result": "PASS", "evidence": "Joint joins Multi's 32-owner limit and bypasses only Multi's 15MiB unallocated secondary-admission heuristic; cold Cloudflare API and CLI default Joint, warm/local Off, off/on=One/one/Multi unchanged.", "source": "examples/repository-host/src/native.rs:625,725,737,1905 and src/bin/repository-host.rs:21,80"},
    {"invariant": "Actual ownership and required pressure priority", "result": "PASS", "evidence": "Actual 32MiB owning-byte and 256 combined-entry checks remain; pool32, chunk/response16MiB and socket262144 unchanged. Required metadata/response retention evicts newest secondary then anchor before response FIFO. Admission is first-fit and never replaces live owners; allocator and held-plan controls exercise pressure.", "source": "examples/repository-host/src/native.rs:1757,1802,1880,1949"},
    {"invariant": "Authority, verified bytes, masks, tokens and accounting", "result": "PASS", "evidence": "Only ordinary verified GETs can admit; startup/observer/PUT cannot. Current-authoritative Full pruning, exact descriptor validation, signed cached masks/continuation revalidation, Full stable token, registration checks, request-error resets and synchronous GC/fault/NULL accounting are unchanged production paths.", "source": "examples/repository-host/src/native.rs:770,873,1928,1980,2140,2233"},
    {"invariant": "Change boundary", "result": "PASS", "evidence": "Exactly native.rs, CLI and Rust gate change. All six production Worker modules and whole Cloudflare tree equal R19; dependencies/lock, rates, scorer, benchmark workload, production configuration, transport/schema stay unchanged."},
]
limitations = [
    "Source approval only. Mandatory five fresh original-R1/final repetitions across all four workloads are NOT DONE; no cost, speed, full-bill, plateau or stopping claim.",
    "First16 historical actual Native proc environment was not captured. Its Multi read plans/consumed/unsupported are39/39/0 and Joint39/38/1; final manifest observer usage after the last snapshot is UNKNOWN/NULL.",
    "Fresh canonical64 has actual known-only live Native Git environment and39/39 consumed reads/0unsupported in both modes,7 consumed receives; bootstrap lineage320B and final400B. No upload-advertisement runtime certification coverage claimed.",
    "Traced64 is fallback-only: both39 read plans unsupported/0consumed, receive7/7. It cannot stand in for optimized canonical proof.",
    "Raw response encoding differs in one first16 row(-17B,74 ordered decoded objects), one canonical64 row(-45B,64 objects), and two fallback rows(+39B/71 objects,+22B/77 objects). Actual bodies remain; exact existing decode/strict-index/fsck/archive proofs were inspected and independently rehashed. No timing/nondeterminism cause claim.",
    "Canonical Multi history-nohave23 displayed key delta3GET/37,786,156B versus actual aggregate7GET/67,258,344B has NULL per-key closure. No epoch identity or ordered whole-key GET/admission timeline is proved, even when histogram deltas arithmetically reconcile.",
    "Failed first64 Multi observer returned actual503 with EAGAIN; underlying cause UNKNOWN. Actual failed body is absent, not reconstructed; successful contract and source-after map are absent. Historical v1 runner ELF is absent; its recorded hash and actual archived Rust source remain. Actual production Native ELF is preserved/rehashed separately.",
    "Fault cohort has38 records:10read modes,14publication attempts and13same-Native distinct next pushes. GC LIST before next PUT is proved11/13, with unknown-sql and gateway-lost-reply explicit exclusions. Unfired partial-delete attempt0 remains separately paid and distinct from fired attempt1. Final SQLR/SQLW remain NULL and accounting_complete=false; known counters do not close missing receipt usage.",
    "HTTP live process snapshot was late and empty; no actual live HTTP proc/env claim. Source/runtime before-after maps, explicit disabled preparation/socket, zero consumed gateway paths and real ordinary-HTTP admissions/hits remain adequate for this source-level compatibility control. No rerun was made to conceal the gap.",
    "All13 raw /dev/shm roots are volatile memory-backed local-only correctness evidence, visible in actual escalated host namespace; no performance or power-loss durability claim. Compact /tmp mirrors omit large raw data.",
    "Warm and HTTP exceeded each536,870,912B scope estimate by9,204,374B and9,188,108B respectively. Actual volatile total18,411,096,507B stays below24GiB; all preflights met>=40GiB MemAvailable. Cleanup has no visible known scoped runtime matches and both ports bindable, with22unreadable own-UID proc entries and33vanished during its scan; no global process-absence claim.",
    "Review ran no builds, tests, servers, service requests, process inspections, source edits, pushes, CI or merges. It audited exact source, author execution logs, preserved actual bytes/receipts and final continuity. Independent audit's initial schema and lineage-stage assumptions failed before output and were corrected/disclosed in pair-audit JSON.",
]

md = f"""Approved SOURCE only: `{SHA}`, exact R19 parent `{BASE}`. No source blocker remains. The worktree is clean, and the three-file change adds generic Joint admission/default/CLI control while preserving the actual 32 MiB owning limit, 256 combined entries, 32 chunk owners, 16 MiB chunk/response limits and 262,144 B socket reservation. Required pressure priority, first-fit without live-owner replacement, current Full pruning, authority, signed masks/tokens, GC and NULL accounting remain intact. Production Worker tree is unchanged (`7f41db4407963ed04e6cbe19556b1416633caf18`).

Independent read-only checks rehashed all current 39 source/runtime map entries, actual Native ELF `2633e97fa9f50afa3b17fe53bdc39e42b1f0ff011f3bed4084c717afc4ffc507`, v2 runner `29fa1c4cfb9a9175b505fb3269ea0cdc05e16f6a2c78981f0caeebcc5287b3e3`, all 40 request/response pairs in each preserved pair, final handoff inputs and every raw evidence file. Author logs establish 130 library tests and all-target Clippy with denied warnings; formatter and independent diff checks pass. No review build or runtime was launched.

Clean64 has 49 matched ordinary rows: GET 375→282 and read 3,418,793,827→2,987,738,608 B, with paid startup 12 GET/80,369,928 B each. Actual 39/39 reads and 7/7 receives consumed in each mode, with live known-only Native Git environment. Manifest/write/storage parity holds. 39 responses are raw equal; the −45 B remaining representation has exact 64-object ordered decode/strict Git/archive proof. These are correctness and accounting observations.

All six bounded controls pass: actual retained heap 30,061,177 B ≤ charged 30,305,781 B; twelve 16,652,187 B responses retain required response priority; held signed plan pressure produces paid discard +1, evictions +15 and admissions +8; fault/NULL/ambiguous publication/same-Native recovery, same-root restart, warm and ordinary HTTP checks pass. Faults retain 14 publication attempts, including the separately paid unfired partial-delete attempt 0. GC LIST before next PUT is proved in 11/13 cases; the two source exclusions remain explicit. Final fault SQLR/SQLW are NULL and accounting is incomplete.

Important retained limits: first16 final observer usage is UNKNOWN and historical actual Native proc environment absent (read consumption Multi 39/39, Joint 38/39). Traced64 is fallback-only. Failed64 actual 503 body and historical v1 runner ELF are unavailable; they were not reconstructed. Canonical history-nohave23 per-key display disagrees with aggregate, so closure remains NULL; no ordered whole-key timeline is claimed. Actual raw encoding variances and earlier failed offline checks remain preserved. HTTP's actual process snapshot was late/empty; its ordinary-HTTP compatibility result is supported by exact maps and actual disabled-preparation/admission/hit controls, with no live HTTP proc-env claim.

Fresh inventories cover 18 raw roots/7,684 files/24,347,201,196 B, plus the complete 3,134-file compact mirror. The 13 volatile raw roots use 18,411,096,507 B < 24 GiB; every preflight met 40 GiB available RAM. Warm/HTTP estimates were low by 9,204,374/9,188,108 B. Cleanup shows both owned ports bindable and no visible known scoped matches, with 22 unreadable own-UID proc entries and 33 vanished during the scan. Raw tmpfs is volatile local-only and has no timing or power-loss durability claim.

The [machine-readable review]({PREFIX}.json) links exact source, handoff, independent audits and exhaustive SHA inventories. Approval covers this exact SOURCE commit. Docs/ledger approval is separate. Mandatory five fresh original-R1/final repetitions across all four workloads are **NOT DONE**; no cost/speed/full-bill acceptance, plateau or stopping claim is made.
"""
md_path = Path(str(PREFIX) + ".md")
json_path = Path(str(PREFIX) + ".json")
assert not md_path.exists() and not json_path.exists()
md_path.write_text(md)
result = {
    "kind": "independent exact-SHA SOURCE-only review",
    "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "decision": "SOURCE_APPROVED",
    "source_commit": SHA,
    "source_parent": BASE,
    "source_worktree": str(REPO),
    "worktree_clean_at_final_decision": True,
    "source_blockers": [],
    "source_findings": findings,
    "Native_tree": "ff99eaf58a5e4f68e744d0b50ddee2af67aff1cf",
    "Worker_six_modules_tree": "7f41db4407963ed04e6cbe19556b1416633caf18",
    "whole_Native_source_file_SHA_is_not_ELF_identity": {"bytes": 138095, "sha256": "59d2e8ed53ba8d15c2eb99aea5b7aeb18a31111715ded1c4265961b6851e2cde", "includes_tests": True},
    "author_final_handoff": rec(HANDOFF),
    "author_final_handoff_markdown": rec("/tmp/git-zero-joint-chunk-source-handoff.md"),
    "every_handoff_file_record_independently_rehashed": records,
    "independent_audit_artifacts": inputs,
    "raw_inventory_reconciliation": {"18_raw_roots_all_author_and_independent_file_SHA_inventories_equal": True, "raw_regular_files": 7684, "raw_logical_bytes": 24347201196, "volatile_roots": 13, "volatile_logical_bytes": 18411096507, "additional_compact_mirror_files": 3134},
    "additional_all_contract_budget_snapshots_checked": budget_counts,
    "bounded_actual_process_snapshot_proof_scopes": process_coverage,
    "owned_cleanup_receipt": rec(cleanup_path),
    "limits_and_unperformed_work": limitations,
    "full_bill_usd": None,
    "cost_speed_acceptance": False,
    "mandatory_five_fresh_originalR1_final_all_four_workloads_complete": False,
    "docs_ledger_approval": False,
    "push_CI_merge_or_primary_mutation": False,
    "review_markdown": rec(md_path),
    "review_sealer_program": rec(Path(__file__)),
}
json_path.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"decision": result["decision"], "source_commit": SHA, "verified_handoff_file_records": len(records), "review": rec(json_path), "markdown": rec(md_path)}, indent=2))
