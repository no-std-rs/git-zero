from pathlib import Path
import datetime,gzip,hashlib,io,json,os,shutil,subprocess,tarfile
stage=Path('/tmp/git-zero-joint-docs-stage-v1');assert not stage.exists();stage.mkdir(mode=0o700);cap=stage/'capsule';cap.mkdir();pub=stage/'r20-joint-chunk-candidate';pub.mkdir();wt=Path('/tmp/git-zero-hosting-joint-chunk');crate=wt/'examples/repository-host';tmp=Path('/tmp');meta=tmp/'git-zero-joint-correctness-manifests';source='b74c91738a3fbfe3ebf30a936fbf9d7ff79f1ae0'
assert subprocess.check_output(['git','-C',str(wt),'rev-parse','HEAD']).decode().strip()==source;assert not subprocess.check_output(['git','-C',str(wt),'status','--porcelain'])
def record(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(4*1024**2):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def load(p):return json.loads(Path(p).read_text())
copied={}
def copy(src,rel):
 src=Path(src);dest=cap/rel;assert not dest.exists(),str(dest);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);a,b=record(src),record(dest);assert a['bytes']==b['bytes'] and a['sha256']==b['sha256'];copied[str(rel)]={'archive_path':str(rel),'original':a,'bytes':b['bytes'],'sha256':b['sha256']}
handoff=load(tmp/'git-zero-joint-chunk-source-handoff.json');rawroots=[Path(v['root']) for v in handoff['raw_scope_inventory']['roots']]
# Persistent mirrors include all accepted v2 compact receipts, source/runtime maps,
# contexts, traces, and the explicit late HTTP process-snapshot disclosure.
for p in sorted(meta.rglob('*')):
 if p.is_file():copy(p,Path('attempts')/p.relative_to(meta))
# v1 first16/failed64 and first16 proof roots have no persistent mirror. Publish
# bounded top-level evidence and logs only, retaining full large payload inventories.
for root in rawroots:
 if (meta/root.name).exists():continue
 for p in sorted(root.iterdir()):
  if p.is_file() and p.stat().st_size<=4*1024**2 and p.suffix in ['.json','.md','.log','.body','.headers','.status','.request','.toml','.txt','.stdout','.stderr']:
   copy(p,Path('attempts')/root.name/p.name)
 logs=root/'logs'
 if logs.is_dir():
  for p in sorted(logs.rglob('*.log')):
   if p.is_file() and p.stat().st_size<=4*1024**2:copy(p,Path('attempts')/root.name/'logs'/p.relative_to(logs))
# Exact small author artifacts: helper code, all logs, reports, inventories,
# archived Rust drivers and receipts. ELF binaries remain local-only.
for p in sorted(tmp.glob('git-zero-joint*')):
 if not p.is_file() or p.name=='git-zero-joint-build-ledger.py':continue
 if p.suffix in ['.json','.md','.log','.py','.rs'] and p.stat().st_size<=8*1024**2:copy(p,Path('author')/p.name)
for name in ['git-zero-cache-headroom-independent-design-review.md','git-zero-cache-headroom-independent-design-review.json','git-zero-multi-chunk-source-review-f124d3b71ce1.md']:
 copy(tmp/name,Path('inputs')/name)
copy(Path(__file__),Path('author')/Path(__file__).name)
# Fresh actual inventory of every original raw regular file plus symlinks;
# content SHA values come from the independently verified sealed inventories.
rawfiles=[];symlinks=[]
for item in handoff['raw_scope_inventory']['inventories']:
 j=load(item['path'])
 if 'roots' in j:
  for root in j['roots']:
   base=Path(root['root'])
   for e in root.get('entries',root.get('files',[])):
    p=base/e['path']
    if e['kind']=='file':assert p.is_file() and not p.is_symlink() and p.stat().st_size==e['bytes'];rawfiles.append({'path':str(p),'bytes':e['bytes'],'sha256':e['sha256']})
    elif e['kind']=='symlink':assert p.is_symlink() and str(p.readlink())==e['target'];symlinks.append({'path':str(p),'target':e['target']})
 else:
  for e in j['files']:
   p=Path(e['path']);assert p.is_file() and p.stat().st_size==e['bytes'];rawfiles.append(dict(e))
  for e in j['symlinks']:symlinks.append(e)
assert len(rawfiles)==7684 and len({e['path'] for e in rawfiles})==7684
# Explicitly include every actual path from final source maps and live snapshots,
# including all seven map runtime labels and canonical executable aliases.
current={};runtime_labels={}
def include_current(p,expected=None):
 p=Path(p)
 if str(p) not in current:current[str(p)]=record(p)
 a=current[str(p)]
 if expected:assert a['bytes']==expected['bytes'] and a['sha256']==expected['sha256'],str(p)
 return a
m=load(meta/'canonical64-multi-01/source-before.json')
for k,v in m.items():
 p=Path(v['path']) if 'path' in v else crate/k;a=include_current(p,v)
 if k in ['native_binary','runner_binary'] or k.startswith('runtime_'):runtime_labels[k]=a
assert len(runtime_labels)==7
for p in meta.glob('*/runtime-processes-host.json'):
 for process in load(p)['processes']:
  include_current(process['exe'],process['exe_file'])
for key in ['actual_Native_versioned','actual_runner_v2_versioned','actual_runner_v2_source','historical_runner_v1_source']:include_current(handoff['artifacts'][key]['path'],handoff['artifacts'][key])
local={'kind':'exhaustive original stopped raw-scope inventory plus fresh current source/runtime support files','source_commit':source,'raw_regular_file_count':len(rawfiles),'raw_logical_bytes':sum(e['bytes'] for e in rawfiles),'raw_files':rawfiles,'raw_symlinks':symlinks,'raw_integrity_scope':'Every path/type/size rechecked at packaging; SHA content identities are the full author inventories independently rehashed by SOURCE review. No additional runtime or mutable state.','current_supporting_files_fresh_SHA_verified':list(current.values()),'all_seven_current_runtime_map_labels':runtime_labels,'historical_runner_v1_ELF_is_not_present':True,'historical_record_scope':'Original before/after v1 runner identity is historical only. Its old target now contains v2; absent v1 ELF is not placed in a fresh actual-file inventory. Actual archived v1 Rust source is included.','compiler_cache_scope':'Other target incremental/intermediate caches are rebuildable and excluded, not deleted. No claim to inventory all /tmp or all node_modules.','publication_limits':'Large raw Git/R2/SQL/state, pack bodies, wanted archives, seed packs and all ELF payloads stay local-only. Compact counterparts below do not imply all raw files published. Raw /dev/shm is volatile local-only and sandbox-hidden unless escalated; no speed/power-loss claim.'}
(cap/'LOCAL-ONLY-INVENTORY.json').write_text(json.dumps(local,indent=2)+'\n')
manifest={'kind':'R20 compact correctness publication manifest, no benchmark or acceptance','source_commit':source,'file_count':len(copied),'files':list(copied.values()),'local_only_inventory':record(cap/'LOCAL-ONLY-INVENTORY.json'),'local_scope_summary':{'roots':18,'regular_files':7684,'logical_bytes':24347201196,'current_runtime_map_labels':list(runtime_labels)},'large_raw_and_ELF_bytes_included':False,'scope_limits':'No missing actual current runtime-map files; all seven plus observed executable aliases are freshly hashed in LOCAL-ONLY-INVENTORY. Old v1 runner is explicitly historical/absent. All failures/unknowns/incomplete scopes preserved; SOURCE approval is not ledger or measurement approval.'}
(cap/'CAPSULE-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=pub/'raw-evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in sorted(cap.rglob('*')):
    if p.is_file():tar.add(p,arcname=str(p.relative_to(cap)),recursive=False)
# Fully reopen the capsule and verify every member's bytes/hash against staging.
checks=[]
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(copied)+2
 for mem in members:
  assert mem.isfile() and not Path(mem.name).is_absolute() and '..' not in Path(mem.name).parts
  f=tar.extractfile(mem);h=hashlib.sha256();n=0
  while b:=f.read(4*1024**2):h.update(b);n+=len(b)
  expected=record(cap/mem.name);assert n==expected['bytes'] and h.hexdigest()==expected['sha256'];checks.append({'archive_path':mem.name,'bytes':n,'sha256':h.hexdigest()})
reviewbase=tmp/('git-zero-joint-source-review-'+source)
for ext in ['md','json']:shutil.copy2(Path(str(reviewbase)+'.'+ext),pub/('source-review.'+ext))
for ext in ['md','json']:shutil.copy2(tmp/('git-zero-joint-chunk-source-handoff.'+ext),pub/('source-handoff.'+ext))
shutil.copy2(tmp/'git-zero-cache-headroom-independent-design-review.md',pub/'independent-design-review.md');shutil.copy2(tmp/'git-zero-joint-final-owned-cleanup.json',pub/'cleanup.json')
ledger={'kind':'R20 Joint SOURCE-approved correctness implementation/evidence ledger','status':'pending-independent-ledger-review; no screen acceptance','source_commit':source,'parent':'f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5','native_source_tree':'ff99eaf58a5e4f68e744d0b50ddee2af67aff1cf','worker_source_tree':'7f41db4407963ed04e6cbe19556b1416633caf18','production_Worker_changed':False,'source_files_changed':handoff['source']['changed_files'],'source_review':{'json':record(pub/'source-review.json'),'md':record(pub/'source-review.md'),'scope':'Independent exact-SHA SOURCE-only approval. Ledger and mandatory fresh measurements remain separate.'},'implementation':{'new_generic_mode':'joint','candidate_default':'Joint','retained_controls':'off|on=One|one|multi; oldMulti keeps nonempty-pool17MiB ceiling','sole_policy_change':'Remove only the unallocated15MiB secondary admission heuristic in Joint; preserve actual owning charge and all other policy/authority/caps','joint_retained_bytes':33554432,'joint_entry_limit':256,'max_chunks':32,'chunk_entry_bytes':16777216,'response_entry_bytes':16777216,'conditional_socket_bytes':262144,'required_pressure':'Newest secondary, then anchor, before response LRU','admission':'All already-required ordinary verified misses, first-fit; never evict live owner just to admit','prune':'Only current complete confirmed Full authority; observer/startup/PUT do not admit'},'complete_scope_handoff':record(pub/'source-handoff.json'),'complete_scope_handoff_markdown':record(pub/'source-handoff.md'),'matched_correctness_pairs':handoff['pairs'],'bounded_results':handoff['bounded_results'],'complete_bounded_gates':handoff['bounded_scopes'],'failed_runtime_and_offline_scopes':{'failed64':handoff['failed64'],'offline':handoff['preserved_offline_failures']},'continuity':handoff['artifacts'],'checks':handoff['checks'],'full_local_inventory':{'archive_path':'LOCAL-ONLY-INVENTORY.json','file':record(cap/'LOCAL-ONLY-INVENTORY.json'),'raw_roots':18,'raw_regular_files':7684,'raw_logical_bytes':24347201196,'all7_current_runtime_map_files_present':True,'current_runtime_files_freshly_verified':runtime_labels,'actual_supporting_paths':len(current),'historical_v1_ELF_present':False},'capsule':{'file':record(archive),'manifest_archive_path':'CAPSULE-MANIFEST.json','manifest':record(cap/'CAPSULE-MANIFEST.json'),'verified_members':len(checks),'uncompressed_member_bytes':sum(e['bytes'] for e in checks),'all_member_bytes_SHA_verified':True},'resource_cleanup':handoff['resource_and_cleanup'],'publication_limits':local['publication_limits'],'conditional_model_only':{'approval_md':record(pub/'independent-design-review.md'),'approval_original_json':record(tmp/'git-zero-cache-headroom-independent-design-review.json'),'approval_json_capsule_path':'inputs/git-zero-cache-headroom-independent-design-review.json','conditional_replay_extra_GET':193,'conditional_gross_USD':0.06948,'net_unconditional_lower_bound_USD':0,'R19_measured_denominator_USD':None,'not_an_observed_count_or_saving_target':True},'full_bill_USD':None,'Worker_CPU_or_DO_duration_or_Native_speed_claim':False,'cost_resource_acceptance_promotion_plateau_stopping_claim':False,'fresh_independent_screen_required':True,'mandatory_final_five_original_final_pairs_NOT_done':True,'ledger_phase_build_runtime_push_CI_deploy_or_primary_edits':False,'only_new_R20_publication_folder_changed':True}
(pub/'implementation-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
readme='''# R20: actual joint ownership for verified GET chunks\n\nSOURCE `b74c91738a3fbfe3ebf30a936fbf9d7ff79f1ae0`, exact parent R19 `f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5`, has independent SOURCE-only approval. This documentation commit awaits separate ledger review.\n\nGeneric `joint` becomes the default and omits only Multi's unallocated 15 MiB admission heuristic. The actual 32 MiB / 256 combined-entry / 32-chunk budget, 16 MiB chunk and response limits, pressure order, authority, pruning, publication and GC behavior remain. `off`, `on`/`one`, and old `multi` remain controls.\n\nThe local same-source 49-row comparisons record ordinary GETs **186→139 (16 MiB)** and **375→282 (clean 64 MiB)**. Write and storage guards match. Three total response pairs have exact decoded-object proofs instead of raw-byte equality across these canonical pairs: first16 has one −17 B variance; clean64 has one −45 B variance (**two canonical response pairs**, plus two separately traced fallback variances). Actual wire bytes and representation differences remain explicit; no cause is claimed. These are correctness/accounting controls, not priced benchmarks or speed results.\n\n- [Implementation/evidence ledger](implementation-ledger.json), [sealed source handoff](source-handoff.md), and [independent source review](source-review.md)\n- [Independent conditional design review](independent-design-review.md)\n- [Compact evidence capsule](raw-evidence.tar.gz), including `CAPSULE-MANIFEST.json` and exhaustive `LOCAL-ONLY-INVENTORY.json`\n- [Publication validation](publication-validation.json), [owned cleanup](cleanup.json), and [checksums](SHA256SUMS)\n\nAll 18 stopped raw roots remain explicit: three completed pairs, three exact variance-proof roots plus the earlier corrected first16 proof, the initial failed64 runtime, and six final bounded controls. The source handoff is authoritative for the exact list: 7,684 regular files / 24,347,201,196 logical bytes. Large Git/R2/SQL/state, pack bodies, archives and ELF payloads remain local-only; all seven current mapped runtime paths and executable aliases are freshly verified. Historical v1 runner ELF is absent and is not presented as a current file.\n\nLimits remain explicit: first16 final observer traffic is UNKNOWN/NULL after its last snapshot; failed64's actual 503 body was not saved and EAGAIN cause is unknown; traced64 is fallback-only because inherited Trace2 disabled lineage; top-key display is not a whole-DO timeline; fault SQLR/SQLW stay NULL/incomplete. GC LIST-before-next-PUT is proven in 11/13 following pushes, with two source exclusions. The unfired partial-delete attempt remains paid and separate. HTTP's late empty process snapshot is disclosed; no rerun concealed it.\n\nRaw `/dev/shm` state is volatile local-only and visible in the escalated runtime namespace; no power-loss or timing claim. Actual volatile artifacts total 18,411,096,507 B below the authorized 24 GiB planning limit; every runtime scope passed the 40 GiB MemAvailable threshold. Warm/HTTP per-scope estimates were low by about 9.2 MB each; total budget stayed within its limit. No source, evidence or compiler cache was deleted.\n\nThe conditional 193-GET / $0.06948 model is not a measured target; unconditional net lower bound is zero and the full bill remains NULL. Fresh independent measurement, all-profile guards and the mandatory final five original/final pairs remain separate. No acceptance, plateau or stopping claim follows.\n'''
# Correct the explicit count in prose before publication; do not retain an
# abandoned numerical wording as if it were an observed result.
readme=readme.replace('Three total response pairs have exact decoded-object proofs instead of raw-byte equality across these canonical pairs:', 'Two canonical response pairs have exact decoded-object proofs instead of raw-byte equality:')
readme=readme.replace('(**two canonical response pairs**, plus two separately traced fallback variances)', '(plus two separately traced fallback variances)')
(pub/'README.md').write_text(readme)
validation={'kind':'actual staged publication validation, not ledger approval','source_commit':source,'worktree_was_clean_source_at_stage':True,'source_review_original_json':record(Path(str(reviewbase)+'.json')),'source_review_original_md':record(Path(str(reviewbase)+'.md')),'capsule':record(archive),'manifest':record(cap/'CAPSULE-MANIFEST.json'),'all_members_reopened_and_SHA_verified':True,'member_count':len(checks),'member_bytes':sum(e['bytes'] for e in checks),'local_raw_files_all_exist_type_size_rechecked':7684,'local_raw_SHA_provenance':'Author exhaustive inventories independently rehashed by SOURCE reviewer; raw scopes stopped and unchanged. Not claiming to rehash every raw byte again during packaging.','current_runtime_map_files_all7_freshly_SHA_verified':runtime_labels,'current_supporting_paths_freshly_SHA_verified':len(current),'no_unsafe_archive_members':True,'missing_current_actual_files':[],'historical_v1_runner_ELF_is_explicitly_absent':True,'large_ELF_state_pack_payloads_published':False,'stage_program':record(Path(__file__)),'ledger_review':'PENDING'}
(pub/'publication-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
checksums=[]
for p in sorted(pub.iterdir()):
 if p.is_file():checksums.append(f"{record(p)['sha256']}  {p.name}\n")
(pub/'SHA256SUMS').write_text(''.join(checksums))
summary={'kind':'staged R20-only docs package, exact source unchanged','stage':str(stage),'publication':str(pub),'files':[record(p) for p in sorted(pub.iterdir()) if p.is_file()],'capsule_members':len(checks),'capsule_uncompressed_bytes':sum(e['bytes'] for e in checks),'local_raw_files':len(rawfiles),'current_runtime_labels':list(runtime_labels),'current_supporting_paths':len(current),'worktree_not_edited_by_staging':True}
(stage/'stage-validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'stage':str(stage),'publication_files':len(summary['files']),'archive':record(archive),'capsule_members':len(checks),'current_runtime_labels':list(runtime_labels),'actual_supporting_paths':len(current)},indent=2))
