"""Read-only sealed-tree inventory. Does not launch runtimes or delete state."""
from pathlib import Path
import datetime,hashlib,json,stat,sys
output=Path(sys.argv[1]);assert not output.exists();roots=[]
for arg in sys.argv[2:]:
 root=Path(arg);assert root.is_dir();files=[]
 for p in sorted(root.rglob('*')):
  st=p.lstat();v={'path':str(p.relative_to(root))}
  if stat.S_ISLNK(st.st_mode):v.update(kind='symlink',target=str(p.readlink()))
  elif stat.S_ISDIR(st.st_mode):v.update(kind='directory')
  elif stat.S_ISREG(st.st_mode):
   h=hashlib.sha256();n=0
   with p.open('rb') as f:
    while b:=f.read(4*1024**2):n+=len(b);h.update(b)
   assert n==st.st_size and p.stat().st_mtime_ns==st.st_mtime_ns,('changed during inventory',p)
   v.update(kind='file',bytes=n,sha256=h.hexdigest())
  else:v.update(kind='special',mode=stat.S_IFMT(st.st_mode))
  files.append(v)
 roots.append({'root':str(root),'file_count':sum(v['kind']=='file' for v in files),'logical_bytes':sum(v.get('bytes',0) for v in files),'entries':files})
j={'kind':'actual read-only full scoped evidence inventory','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime_environment':'actual escalated host namespace; /dev/shm is sandbox-hidden otherwise','backing_scope':'/tmp disk roots persistent locally; /dev/shm roots volatile memory-backed local-only, no power-loss or performance claim','roots':roots};b=(json.dumps(j,indent=2)+'\n').encode();output.write_bytes(b);print(json.dumps({'inventory':str(output),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'roots':[(r['root'],r['file_count'],r['logical_bytes']) for r in roots]},indent=2))
