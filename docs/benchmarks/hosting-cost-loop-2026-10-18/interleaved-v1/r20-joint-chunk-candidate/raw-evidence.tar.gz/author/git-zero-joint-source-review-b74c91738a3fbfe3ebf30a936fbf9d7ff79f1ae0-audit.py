"""Independent read-only source/evidence audit; no builds, services, or process reads."""
from pathlib import Path
import datetime
import hashlib
import json
import stat
import subprocess
import sys

COMMIT = "b74c91738a3fbfe3ebf30a936fbf9d7ff79f1ae0"
BASE = "f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5"
REPO = Path("/tmp/git-zero-hosting-joint-chunk")
CRATE = REPO / "examples/repository-host"
PREFIX = Path("/tmp/git-zero-joint-source-review-" + COMMIT)
RAW = Path("/dev/shm/git-zero-joint-correctness-20261018")
MIRROR = Path("/tmp/git-zero-joint-correctness-manifests")


def file_record(p):
    p = Path(p)
    before = p.stat()
    h = hashlib.sha256()
    size = 0
    with p.open("rb") as f:
        while chunk := f.read(2 * 1024 * 1024):
            h.update(chunk)
            size += len(chunk)
    after = p.stat()
    assert size == before.st_size == after.st_size
    assert (before.st_ino, before.st_mtime_ns) == (after.st_ino, after.st_mtime_ns), p
    return {"path": str(p), "bytes": size, "sha256": h.hexdigest()}


def read_json(p):
    return json.loads(Path(p).read_text())


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args], text=True).strip()


def write_result(suffix, data):
    out = Path(str(PREFIX) + suffix)
    assert not out.exists(), out
    out.write_text(json.dumps(data, indent=2) + "\n")
    print(json.dumps(file_record(out)))


def audit_source():
    assert git("rev-parse", "HEAD") == COMMIT
    assert git("rev-parse", "HEAD^") == BASE
    assert git("status", "--porcelain=v1") == ""
    changed = git("diff", "--name-only", BASE, COMMIT).splitlines()
    assert changed == [
        "examples/repository-host/src/bin/repository-host.rs",
        "examples/repository-host/src/native.rs",
        "examples/repository-host/tests/multi_chunk_cloudflare.rs",
    ]
    assert git("rev-parse", COMMIT + ":examples/repository-host/cloudflare/src") == git(
        "rev-parse", BASE + ":examples/repository-host/cloudflare/src"
    )
    assert git("rev-parse", COMMIT + ":examples/repository-host/cloudflare") == git(
        "rev-parse", BASE + ":examples/repository-host/cloudflare"
    )
    before = read_json(MIRROR / "canonical64-multi-01/source-before.json")
    current = {}
    for name, expected in before.items():
        p = Path(expected["path"]) if "path" in expected else CRATE / name
        r = file_record(p)
        assert (r["bytes"], r["sha256"]) == (expected["bytes"], expected["sha256"]), name
        current[name] = r
    for scope in ["canonical64-multi-01", "canonical64-joint-01"]:
        assert read_json(MIRROR / scope / "source-before.json") == before
        assert read_json(MIRROR / scope / "source-after.json") == before
    archived = {
        "production_Native": file_record("/tmp/git-zero-joint-native-v1-binary"),
        "runner_v2_ELF": file_record("/tmp/git-zero-joint-driver-v2-binary"),
        "runner_v2_source": file_record("/tmp/git-zero-joint-driver-v2.rs"),
        "runner_v1_source_only": file_record("/tmp/git-zero-joint-first-pair-driver-v1.rs"),
    }
    assert archived["production_Native"]["sha256"] == current["native_binary"]["sha256"]
    assert archived["runner_v2_ELF"]["sha256"] == current["runner_binary"]["sha256"]
    assert archived["runner_v2_source"]["sha256"] == current["tests/multi_chunk_cloudflare.rs"]["sha256"]
    return {
        "commit": COMMIT,
        "parent": BASE,
        "worktree_clean": True,
        "changed_files": changed,
        "Native_tree": git("rev-parse", COMMIT + ":examples/repository-host/src"),
        "Worker_six_modules_tree": git("rev-parse", COMMIT + ":examples/repository-host/cloudflare/src"),
        "entire_Cloudflare_tree_unchanged_from_parent": True,
        "all_actual_current_canonical_map_entries_rehashed": current,
        "archives": archived,
        "historical_v1_runner_ELF_actual_byte_claim": False,
    }


def usage(metrics, key):
    return metrics["cloudflare_services"][key]


def pair_review(receipt_name, canonical=False):
    receipt_path = Path("/tmp") / receipt_name
    receipt = read_json(receipt_path)
    roots = [Path(p) for p in receipt["roots"]]
    cs = [read_json(r / "contract.json") for r in roots]
    assert [c["mode"] for c in cs] == ["multi", "joint"]
    assert all(len(c["rows"]) == 49 for c in cs)
    assert cs[0]["input_manifest"] == cs[1]["input_manifest"]
    assert cs[0]["final_manifest"] == cs[1]["final_manifest"]
    for name in ["fixture-input-seal.json", "fixture-copy-seal.json", "closed-history-sequence.json"]:
        assert read_json(roots[0] / name) == read_json(roots[1] / name)
    assert read_json(roots[0] / "fixture-input-seal.json") == read_json(roots[0] / "fixture-copy-seal.json")
    maps = [read_json(r / "source-before.json") for r in roots]
    assert maps[0] == maps[1]
    for r, m in zip(roots, maps):
        assert m == read_json(r / "source-after.json")
    mutation_fields = ["r2_class_a", "r2_deletes", "r2_written_bytes", "r2_live_objects", "r2_live_bytes", "r2_peak_bytes", "do_rows_written", "do_sqlite_bytes", "manifest_bytes", "manifest_generation"]
    row_deltas = []
    actual_response_pairs = []
    for a, b in zip(cs[0]["rows"], cs[1]["rows"]):
        name = a.get("name", a.get("kind"))
        assert name == b.get("name", b.get("kind"))
        for phase in ["before", "after"]:
            for k in mutation_fields:
                assert usage(a[phase], k) == usage(b[phase], k), (name, phase, k)
            for m in [a[phase], b[phase]]:
                assert m["cache_retained_bytes"] <= 33554432
                assert m["joint_cache_retained_peak_bytes"] <= 33554432
                assert m["joint_cache_entries"] <= 256
                assert m["protected_chunk_entries"] <= 32
                assert m["cloudflare_services"]["accounting_complete"] is True
            for k in ["r2_put", "r2_delete", "r2_list", "manifest_cas"]:
                assert a[phase]["cloudflare_services"]["operations"].get(k) == b[phase]["cloudflare_services"]["operations"].get(k)
        row_deltas.append({"name": name, "actual_aggregate_deltas": [
            {k: usage(row["after"], k) - usage(row["before"], k) for k in ["r2_class_b", "r2_read_bytes", "worker_requests", "do_requests", "do_rows_read", "do_rows_written"]}
            for row in [a, b]
        ]})
        if "response_sha256" in a:
            body_name = a["name"] if "name" in a else "thin-receive"
            bodies = [file_record(r / (body_name + ".body")) for r in roots]
            requests = [file_record(r / (body_name + ".request")) for r in roots]
            assert requests[0]["sha256"] == requests[1]["sha256"]
            assert bodies[0]["sha256"] == a["response_sha256"]
            assert bodies[1]["sha256"] == b["response_sha256"]
            assert all(bod["bytes"] == row.get("response_bytes", bod["bytes"]) for bod, row in zip(bodies, [a, b]))
            for r in roots:
                header = (r / (body_name + ".headers")).read_text()
                assert header.startswith("HTTP/1.1 200 "), (r, body_name)
                status_file = r / (body_name + ".status")
                if status_file.exists():
                    assert status_file.read_text() == "200"
            variance = None
            if bodies[0]["sha256"] != bodies[1]["sha256"]:
                vv = [v for v in receipt["raw_response_encoding_variances"] if v["name"] == name]
                assert len(vv) == 1
                claimed = vv[0]["exact_decoded_object_equality_proof"]
                actual = file_record(claimed["path"])
                assert actual == claimed
                proof = read_json(claimed["path"])
                pa, pb = proof["results"]
                assert proof["same_ordered_OIDs"] is True
                equality_key = "all_decoded_OID_type_size_content_SHA256_exactly_equal"
                if equality_key not in proof:
                    assert proof["row"] == "latest-23" and "all74_decoded_OID_type_size_content_SHA256_exactly_equal" in proof
                    equality_key = "all74_decoded_OID_type_size_content_SHA256_exactly_equal"
                assert proof[equality_key] is True
                assert pa["decoded_objects"] == pb["decoded_objects"]
                assert [v["OID"] for v in pa["ordered_pack_records"]] == [v["OID"] for v in pb["ordered_pack_records"]]
                decoded_count = proof.get("decoded_objects", 74)
                assert len(pa["decoded_objects"]) == decoded_count
                for bod, request, result in zip(bodies, requests, [pa, pb]):
                    assert bod["sha256"] == result["raw_body_sha256"]
                    request_sha = result["request"]["sha256"] if "request" in result else result["request_sha256"]
                    assert request["sha256"] == request_sha
                    assert result["strict_index_pack_passed"] is True
                    assert result["verify_pack_passed"] is True
                    assert result["fsck_strict_passed"] is True
                    assert result["archive_equals_source"] is True
                    if "archive" in result:
                        assert file_record(result["archive"]["path"]) == result["archive"]
                    else:
                        archive = file_record(Path(claimed["path"]).parent / (result["mode"] + "-wanted-archive.tar"))
                        assert archive["sha256"] == result["archive_sha256"] and archive["bytes"] == result["archive_bytes"]
                assert pa.get("archive", {}).get("sha256", pa.get("archive_sha256")) == pb.get("archive", {}).get("sha256", pb.get("archive_sha256"))
                variance = {"proof": actual, "ordered_decoded_objects": decoded_count, "body_difference_joint_minus_multi": bodies[1]["bytes"] - bodies[0]["bytes"]}
            actual_response_pairs.append({"name": name, "bodies": bodies, "requests": requests, "raw_equal": bodies[0]["sha256"] == bodies[1]["sha256"], "variance_existing_strict_Git_proof_rehashed": variance})
    assert len(actual_response_pairs) == 40
    totals = []
    for r, c, expected in zip(roots, cs, receipt["totals"]):
        delta = {k: sum(usage(x["after"], k) - usage(x["before"], k) for x in c["rows"]) for k in ["r2_class_b", "r2_read_bytes"]}
        assert delta["r2_class_b"] == expected["ordinary_49_row_GET_attempts"]
        assert delta["r2_read_bytes"] == expected["ordinary_49_row_read_bytes"]
        for actual_key, total_key in [("r2_class_b", "actual_last_snapshot_GET_attempts"), ("r2_read_bytes", "actual_last_snapshot_read_bytes")]:
            assert usage(c["final"], actual_key) == expected[total_key]
            assert usage(c["startup_paid_recovery"], actual_key) + delta[actual_key] == usage(c["final"], actual_key)
        final = c["final"]
        if canonical:
            assert final["gateway_read_plans"] == final["gateway_read_consumed"] == 39
            assert final["gateway_read_unsupported"] == 0
            assert final["gateway_receive_consumed"] == 7
            assert c["startup_paid_recovery"]["history_lineage_bytes"] == 320
            assert final["history_lineage_bytes"] == 400
            env = read_json(r / "runtime-processes-host.json")
            native = [p for p in env["processes"] if Path(p["exe"]).name == "repository-host"]
            assert len(native) == 1
            assert native[0]["exe_file"]["sha256"] == maps[0]["native_binary"]["sha256"]
            allowed = {"GIT_CONFIG_NOSYSTEM", "GIT_CONFIG_GLOBAL", "GIT_DIR", "GIT_WORK_TREE", "GIT_PROTOCOL", "GIT_USER_AGENT", "GIT_PAGER"}
            for k, v in native[0]["actual_GIT_environment"].items():
                assert k.startswith("GIT_ZERO_") or k in allowed or (k in {"GIT_CONFIG_COUNT", "GIT_TERMINAL_PROMPT"} and v == "0")
        totals.append({"mode": c["mode"], "ordinary49": delta, "startup_GETs": usage(c["startup_paid_recovery"], "r2_class_b"), "startup_read_bytes": usage(c["startup_paid_recovery"], "r2_read_bytes"), "last_W_DO_SQLR_SQLW": {k: usage(final, k) for k in ["worker_requests", "do_requests", "do_rows_read", "do_rows_written"]}, "read_plans": final["gateway_read_plans"], "read_consumed": final["gateway_read_consumed"], "read_unsupported": final["gateway_read_unsupported"], "receive_consumed": final["gateway_receive_consumed"]})
    return {"receipt": file_record(receipt_path), "contracts": [file_record(r / "contract.json") for r in roots], "roots": [str(r) for r in roots], "same_frozen_source_and_exact_copied_fixture": True, "same_input_final_manifest_and_actual_mutation_storage_fields": True, "49_rows_each_independently_reconciled": row_deltas, "40_response_pairs_actual_bytes_independently_rehashed": actual_response_pairs, "totals": totals, "closed_ordered_per_key_GET_timeline": None, "full_bill_usd": None, "performance_cost_acceptance_claim": False}


def inventory(roots):
    result = []
    for root in map(Path, roots):
        assert root.is_dir() and not root.is_symlink()
        entries = []
        for p in sorted(root.rglob("*")):
            st = p.lstat()
            rel = str(p.relative_to(root))
            if stat.S_ISREG(st.st_mode):
                entry = file_record(p)
                entry["path"] = rel
                entry["kind"] = "regular_file"
            elif stat.S_ISDIR(st.st_mode):
                entry = {"path": rel, "kind": "directory"}
            elif stat.S_ISLNK(st.st_mode):
                entry = {"path": rel, "kind": "symlink", "target": str(p.readlink())}
            else:
                raise AssertionError(("unexpected special evidence entry", p))
            entries.append(entry)
        result.append({"root": str(root), "file_count": sum(e["kind"] == "regular_file" for e in entries), "logical_file_bytes": sum(e.get("bytes", 0) for e in entries), "entries": entries})
    return {"kind": "fresh independent exhaustive SHA256 inventory of explicitly scoped preserved evidence", "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source_commit": COMMIT, "reads_only": True, "actual_host_namespace": True, "tmpfs_backing": "volatile memory-backed local-only correctness evidence; no performance or power-loss durability claim", "roots": result}


def metrics_bounds(value):
    found = 0
    if isinstance(value, dict):
        if "joint_cache_retained_peak_bytes" in value:
            assert value["cache_retained_bytes"] <= 33554432
            assert value["joint_cache_retained_peak_bytes"] <= 33554432
            assert value["joint_cache_entries"] <= 256
            assert value["protected_chunk_entries"] <= 32
            found += 1
        found += sum(metrics_bounds(v) for v in value.values())
    elif isinstance(value, list):
        found += sum(metrics_bounds(v) for v in value)
    return found


def audit_controls():
    source = audit_source()
    canonical_map = read_json(MIRROR / "canonical64-joint-01/source-before.json")
    scopes = []
    for name in ["joint-allocation-01", "joint-plan-01", "joint-faults-01", "joint-restart-01", "joint-warm-01", "joint-http-01"]:
        raw, meta = RAW / name, MIRROR / name
        before, after = read_json(raw / "source-before.json"), read_json(raw / "source-after.json")
        assert before == after == canonical_map
        cleanup = read_json(raw / "cleanup.json")
        assert cleanup["owned_process_groups_stopped"] is True
        resource = read_json(meta / "pre-scope-resource.json")
        assert resource["artifact_root"] == str(raw)
        assert resource["memory"]["MemAvailable"] >= 40 * 1024**3
        assert resource["existing_volatile_logical_bytes"] + resource["planned_scope_upper_bytes"] <= 24 * 1024**3
        assert resource["tmp_available_bytes"] >= 256 * 1024**2
        mirror = read_json(meta / "compact-mirror-inventory.json")
        for f in mirror["files"]:
            assert file_record(f["persistent"]["path"]) == f["persistent"]
            r = file_record(f["volatile_original"])
            assert (r["bytes"], r["sha256"]) == (f["persistent"]["bytes"], f["persistent"]["sha256"])
        contract_name = "allocation-contract.json" if name == "joint-allocation-01" else "contract.json"
        c = read_json(raw / contract_name)
        budget_snapshots = metrics_bounds(c)
        assert c["full_bill_usd"] is None
        item = {"scope": name, "source_maps_equal_current_frozen_canonical": True, "contract": file_record(raw / contract_name), "mirror_inventory": file_record(meta / "compact-mirror-inventory.json"), "all_mirrored_bytes_match_stopped_raw_files": True, "resource_preflight": file_record(meta / "pre-scope-resource.json"), "cleanup": file_record(raw / "cleanup.json"), "bounded_metrics_snapshots_checked": budget_snapshots}
        if name == "joint-allocation-01":
            a = c["admitted"]
            assert a["delta"] == max(a["retained_live"] - a["baseline_live"], 0)
            assert a["delta"] <= a["metrics"]["cache_retained_bytes"]
            assert a["metrics"]["protected_chunk_entries"] > 1
            assert a["metrics"]["protected_chunk_bytes"] >= 16 * 1024**2
            assert c["initial"]["protected_chunk_admissions"] == 0
            assert len(c["pressure"]) == 12
            for r in c["pressure"]:
                assert 16 * 1024**2 - 262144 < r["response_bytes"] <= 16 * 1024**2
                assert r["after"]["protected_chunk_bytes"] == 0
                assert r["after"]["cache_entries"] == 1
                assert r["after"]["protected_chunk_evictions"] > r["before"]["protected_chunk_evictions"]
                assert usage(r["after"], "r2_class_b") > usage(r["before"], "r2_class_b")
            assert c["restart"]["protected_chunk_entries"] == c["restart"]["protected_chunk_admissions"] == 0
            item["actual_retained_heap_delta"] = a["delta"]
            item["conservative_retained_charge"] = a["metrics"]["cache_retained_bytes"]
            item["actual_productive_response_bytes_each"] = [r["response_bytes"] for r in c["pressure"]]
            item["allocation_scope"] = "counted in-process Native from exact Rust library; cross-request owned-cache bound, request transient peak separately recorded"
        else:
            assert c["initial"]["protected_chunk_entries"] == c["initial"]["protected_chunk_admissions"] == 0
            for k in ["protected_chunk_admissions", "protected_chunk_prunes"]:
                assert c["observer_before"][k] == c["observer_after"][k]
            if name == "joint-plan-01":
                p = read_json(raw / "plan-pressure-contract.json")
                assert p["trace"]["gateway_hook_fired"] is True
                delta = {k: p["after"][k] - p["before"][k] for k in ["gateway_read_paid_discards", "protected_chunk_evictions", "protected_chunk_admissions"]}
                assert all(v > 0 for v in delta.values())
                assert p["refill"]["after"]["protected_chunk_entries"] > 0
                assert p["big"]["after"]["protected_chunk_bytes"] == 0
                response = file_record(raw / "pressure-plan-discard.body")
                assert response["sha256"] == p["response"]["response_sha256"] and response["bytes"] == p["response"]["response_bytes"]
                item.update(held_plan=file_record(raw / "plan-pressure-contract.json"), actual_deltas=delta, actual_response=response)
            elif name == "joint-faults-01":
                f = read_json(raw / "fault-contract.json")
                rr = [r for r in f["rows"] if r["kind"] == "read fault"]
                pp = [r for r in f["rows"] if r["kind"] == "publication attempt"]
                nn = [r for r in f["rows"] if r["kind"] == "same Native distinct next push"]
                assert len(f["rows"]) == 38 and len(rr) == 10 and len(pp) == 14 and len(nn) == 13
                assert len({r["mode"] for r in pp if r["fired"]}) == 13
                for r in rr + pp:
                    name_part = "fetch-" + r["mode"] if r["kind"] == "read fault" else f"push-{r['mode']}-{r['attempt']}"
                    status_line = (raw / (name_part + ".headers")).read_text().splitlines()[0]
                    assert status_line.split()[1] == str(r["status"])
                    assert file_record(raw / (name_part + ".body"))["sha256"] == r["response_sha256"]
                    if r["mode"] == "unknown-sql":
                        assert r["after"]["cloudflare_services"]["do_rows_read"] is None
                    if r["kind"] == "publication attempt":
                        assert sum(v["name"] == "manifest_cas" for v in r["trace"]["trace"]) <= 1
                assert next(r for r in rr if r["mode"] == "missing-receipt")["after"]["cloudflare_services"]["accounting_complete"] is False
                gc = []
                for r in nn:
                    ops = r["trace"]["trace"]
                    put = next(i for i, v in enumerate(ops) if v["name"] == "r2_put")
                    before_put = ops[:put]
                    observed = any(v["name"] == "r2_list" and v["route"] == "/_services/gc" for v in before_put)
                    if r["mode"] not in ["unknown-sql", "gateway-lost-reply"]:
                        assert observed
                    gc.append({"mode": r["mode"], "actual_GC_LIST_before_next_PUT": observed, "actual_GC_delete_attempts_before_next_PUT": sum(v["name"] == "r2_delete" and v["route"] == "/_services/gc" for v in before_put)})
                partial = []
                for r in pp:
                    if r["mode"] == "partial-delete":
                        delta = {}
                        for k in ["worker_requests", "do_requests", "do_rows_read", "do_rows_written", "r2_class_a", "r2_class_b", "r2_read_bytes", "r2_written_bytes", "r2_deletes", "manifest_generation"]:
                            a, b = usage(r["before"], k), usage(r["after"], k)
                            delta[k] = None if a is None or b is None else b - a
                        partial.append({"attempt": r["attempt"], "status": r["status"], "fault_actually_fired": r["fired"], "observed_known_counter_deltas_only": delta, "accounting_complete_after": r["after"]["cloudflare_services"]["accounting_complete"]})
                assert [r["fault_actually_fired"] for r in partial] == [False, True]
                assert c["final"]["cloudflare_services"]["do_rows_read"] is None
                assert c["final"]["cloudflare_services"]["do_rows_written"] is None
                assert c["final"]["cloudflare_services"]["accounting_complete"] is False
                item.update(fault_contract=file_record(raw / "fault-contract.json"), record_count=38, read_fault_modes=10, publication_attempts=14, fired_publication_modes=13, same_Native_next_pushes=13, same_Native_GC_observations=gc, preserved_partial_delete_attempts=partial, unknown_SQLR_SQLW=None, complete_full_accounting=False)
            elif name == "joint-restart-01":
                restarted = read_json(raw / "same-root-restarted.body")
                received = read_json(raw / "restarted-receive-after.body")
                assert restarted["protected_chunk_entries"] == restarted["protected_chunk_admissions"] == 0
                assert received["gateway_receive_consumed"] > restarted["gateway_receive_consumed"]
                item["same_root_restarted_empty_then_actual_prepared_receive"] = True
            elif name == "joint-warm-01":
                assert c["final"]["protected_chunk_admissions"] == 0
                assert usage(c["final"], "r2_class_b") == usage(c["initial"], "r2_class_b")
                assert usage(c["final"], "r2_read_bytes") == usage(c["initial"], "r2_read_bytes")
                item["warm_no_chunk_admission_or_additional_R2_reads"] = True
            elif name == "joint-http-01":
                assert c["final"]["gateway_read_consumed"] == c["final"]["gateway_receive_consumed"] == 0
                assert c["final"]["protected_chunk_admissions"] > 1 and c["final"]["protected_chunk_hits"] > 0
                item["ordinary_HTTP_actual_multi_chunk_admission_and_hits"] = True
        scopes.append(item)
    return {"kind": "independent source and completed bounded-control evidence audit; no performance or full-bill claim", "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source": source, "scopes": scopes, "full_bill_usd": None, "performance_cost_acceptance": False}


if __name__ == "__main__":
    if sys.argv[1] == "audit-pairs":
        result = {"kind": "independent exact source and preserved pair evidence audit; SOURCE approval awaits final bounded controls", "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source": audit_source(), "pairs": [pair_review("git-zero-joint-first16-paired-review.json"), pair_review("git-zero-joint-fallback64-paired-review.json"), pair_review("git-zero-joint-canonical64-paired-review.json", canonical=True)], "offline_audit_corrections": ["First independent audit stopped with KeyError before producing output because first16 uses all74_decoded.../request_sha256/archive_sha256 and v2 uses generic all_decoded.../request/archive objects. Explicitly support both preserved schemas; actual evidence unchanged.", "Second audit stopped before output on an overstrict startup-lineage==400 assumption. Raw receipts have 320B bootstrap lineage and 400B final lineage in both canonical modes; now assert each at its actual stage. No production or evidence mutation."]}
        write_result("-pair-audit.json", result)
    elif sys.argv[1] == "inventory":
        write_result("-" + sys.argv[2] + "-inventory.json", inventory(sys.argv[3:]))
    elif sys.argv[1] == "audit-controls":
        write_result("-controls-audit.json", audit_controls())
    else:
        raise SystemExit("use audit-pairs or inventory NAME ROOT...")
