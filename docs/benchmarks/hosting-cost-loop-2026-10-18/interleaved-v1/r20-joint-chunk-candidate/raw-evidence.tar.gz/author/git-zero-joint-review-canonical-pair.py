from pathlib import Path
import hashlib,json,sys
profile=sys.argv[1]
assert profile=='64'
roots=[Path('/dev/shm/git-zero-joint-correctness-20261018/canonical64-multi-01'),Path('/dev/shm/git-zero-joint-correctness-20261018/canonical64-joint-01')]
def rec(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def usage(m,k):return m['cloudflare_services'][k]
def complete_keys(m):
 a=m['cloudflare_services']['r2_key_access'];return not a['truncated'] and len(a['top_keys'])==a['tracked_keys']
def access(m):return {v['key']:v for v in m['cloudflare_services']['r2_key_access']['top_keys']}
cs=[json.loads((r/'contract.json').read_text()) for r in roots]
maps=[json.loads((r/'source-before.json').read_text()) for r in roots]
assert maps[0]==maps[1]
for r,m in zip(roots,maps):assert m==json.loads((r/'source-after.json').read_text())
for name in ['fixture-input-seal.json','fixture-copy-seal.json','closed-history-sequence.json']:
 assert json.loads((roots[0]/name).read_text())==json.loads((roots[1]/name).read_text()),name
assert cs[0]['input_manifest']==cs[1]['input_manifest']
assert cs[0]['final_manifest']==cs[1]['final_manifest']
assert len(cs[0]['rows'])==len(cs[1]['rows'])==49
for root,c in zip(roots,cs):
 assert c['startup_paid_recovery']['history_lineage_bytes']>0
 assert c['rows'][0]['after']['gateway_read_consumed']>c['rows'][0]['before']['gateway_read_consumed']
 actual=json.loads((root/'runtime-processes-host.json').read_text())
 native=[p for p in actual['processes'] if Path(p['exe']).name=='repository-host']
 assert len(native)==1
 for key,value in native[0]['actual_GIT_environment'].items():
  assert key.startswith('GIT_ZERO_') or key in ['GIT_CONFIG_NOSYSTEM','GIT_CONFIG_GLOBAL','GIT_DIR','GIT_WORK_TREE','GIT_PROTOCOL','GIT_USER_AGENT','GIT_PAGER'] or (key in ['GIT_CONFIG_COUNT','GIT_TERMINAL_PROMPT'] and value=='0'),(key,'unknown Native GIT environment')

write_fields=['r2_class_a','r2_deletes','r2_written_bytes','r2_live_objects','r2_live_bytes','r2_peak_bytes','do_rows_written','do_sqlite_bytes','manifest_bytes','manifest_generation']
rows=[];responses=[];variances=[]
for i,(a,b) in enumerate(zip(cs[0]['rows'],cs[1]['rows'])):
 name=a.get('name',a.get('kind'));assert name==b.get('name',b.get('kind'))
 for phase in ['before','after']:
  for k in write_fields:assert usage(a[phase],k)==usage(b[phase],k),(name,phase,k,usage(a[phase],k),usage(b[phase],k))
  for k in ['r2_put','r2_delete','r2_list','manifest_cas']:
   assert a[phase]['cloudflare_services']['operations'].get(k)==b[phase]['cloudflare_services']['operations'].get(k),(name,phase,k)
  for x in [a[phase],b[phase]]:
   assert x['cache_retained_bytes']<=33554432 and x['joint_cache_retained_peak_bytes']<=33554432 and x['joint_cache_entries']<=256 and x['protected_chunk_entries']<=32
   assert x['cloudflare_services']['accounting_complete'] is True
 proof=[]
 for root,row in zip(roots,[a,b]):
  before,after=row['before'],row['after'];old,new=access(before),access(after)
  gets=usage(after,'r2_class_b')-usage(before,'r2_class_b');read=usage(after,'r2_read_bytes')-usage(before,'r2_read_bytes')
  closure=None
  if complete_keys(before) and complete_keys(after):
   delta=[]
   for key in sorted(set(old)|set(new)):
    o,n=old.get(key,{}),new.get(key,{})
    g=n.get('get_attempts',0)-o.get('get_attempts',0);r=n.get('read_bytes',0)-o.get('read_bytes',0)
    assert g>=0 and r>=0,(name,key,'counter scope reset')
    if g or r:delta.append({'key':key,'GET_attempts':g,'read_bytes':r})
   assert sum(v['GET_attempts'] for v in delta)==gets and sum(v['read_bytes'] for v in delta)==read,(name,'complete key closure')
   closure=delta
  proof.append({'mode':root.name.split('-')[-2],'GET_attempts':gets,'read_bytes':read,'aggregate_receipts_complete':True,'complete_key_histogram_delta_if_available':closure,'key_scope':'top10 recent per-DO display is partial whenever displayed<tracked, even if internal truncated=false; unknown keys never zero; no ordered GET/admission timeline claim'})
 if 'response_sha256' in a:
  file='thin-receive.body' if 'name' not in a else name+'.body'
  records=[rec(r/file) for r in roots]
  request_file='thin-receive.request' if 'name' not in a else name+'.request'
  request_records=[rec(r/request_file) for r in roots]
  assert request_records[0]['sha256']==request_records[1]['sha256'],(name,'actual request mismatch')
  assert records[0]['sha256']==a['response_sha256'] and records[1]['sha256']==b['response_sha256']
  raw_equal=records[0]['sha256']==records[1]['sha256']
  if not raw_equal:
   proof_path=Path('/tmp/git-zero-joint-correctness-manifests')/('canonical64-'+name+'-proof-01')/'proof.json';variance_proof=json.loads(proof_path.read_text())
   assert variance_proof['all_decoded_OID_type_size_content_SHA256_exactly_equal'] and variance_proof['same_ordered_OIDs']
   assert all(x['sha256']==v['raw_body_sha256'] for x,v in zip(records,variance_proof['results']))
   variances.append({'row':i,'name':name,'raw_body_byte_difference_joint_minus_multi':records[1]['bytes']-records[0]['bytes'],'exact_decoded_object_equality_proof':rec(proof_path),'timing_or_nondeterminism_cause_proved':False})
  responses.append({'row':i,'name':name,'files':records,'actual_requests':request_records,'raw_bytes_equal':raw_equal,'decoded_objects_equal':True})
 if name and name.startswith('latest-') and name[7:].isdigit():assert all(p['GET_attempts']>0 and p['read_bytes']>0 for p in proof)
 rows.append({'row':i,'name':name,'actual_reads':proof,'write_storage_SQLW_guards_equal':True,'response_sha256':a.get('response_sha256')})
totals=[]
for root,c in zip(roots,cs):
 f=c['final'];u=f['cloudflare_services'];startup=c['startup_paid_recovery']['cloudflare_services']
 by_kind={}
 for name,predicate in [('pushes',lambda x:x.get('name','').startswith('push-')),('fetches',lambda x:'gets' in x),('thin_receive',lambda x:'kind'in x)]:
  rr=[x for x in c['rows'] if predicate(x)]
  by_kind[name]={'rows':len(rr),'actual_GET_attempts':sum(usage(x['after'],'r2_class_b')-usage(x['before'],'r2_class_b') for x in rr),'actual_read_bytes':sum(usage(x['after'],'r2_read_bytes')-usage(x['before'],'r2_read_bytes') for x in rr)}
 totals.append({'root':str(root),'mode':c['mode'],'actual_last_snapshot_GET_attempts':u['r2_class_b'],'actual_last_snapshot_read_bytes':u['r2_read_bytes'],'startup_paid_GET_attempts':startup['r2_class_b'],'startup_paid_read_bytes':startup['r2_read_bytes'],'ordinary_49_row_GET_attempts':sum(usage(x['after'],'r2_class_b')-usage(x['before'],'r2_class_b') for x in c['rows']),'ordinary_49_row_read_bytes':sum(usage(x['after'],'r2_read_bytes')-usage(x['before'],'r2_read_bytes') for x in c['rows']),'by_kind':by_kind,'worker_requests_at_last_snapshot':u['worker_requests'],'DO_requests_at_last_snapshot':u['do_requests'],'SQLR_at_last_snapshot':u['do_rows_read'],'SQLW_at_last_snapshot':u['do_rows_written'],'r2_written_bytes':u['r2_written_bytes'],'r2_live_bytes':u['r2_live_bytes'],'r2_peak_bytes':u['r2_peak_bytes'],'r2_live_objects':u['r2_live_objects'],'SQLite_bytes':u['do_sqlite_bytes'],'joint_peak_bytes':f['joint_cache_retained_peak_bytes'],'admissions':f['protected_chunk_admissions'],'pressure_evictions':f['protected_chunk_pressure_evictions'],'prunes':f['protected_chunk_prunes']})
out={'kind':'offline same-source actual production clean-environment pair correctness/accounting review, no performance or cost result','environment_scope':'Actual Native proc GIT environment captured; allowed variables only; observed bootstrap lineage and consumed first Full gateway read required. No advertisement request in this workload.','roots':[str(r) for r in roots],'maps_equal_before_after_across_modes':True,'durable_source_R2_SQL_byte_seals_equal':True,'input_final_manifest_equal':True,'matched_rows':rows,'actual_response_files_verified':responses,'raw_response_encoding_variances':variances,'totals':totals,'counter_scope_limit':'Last Native metrics snapshot is explicitly after the final manifest observer and captures its actual aggregate server counters. All49ordinary rows and paid startup are separately closed. Scope follows current Worker/DO and actual per-RPC accounting; no full-bill or performance claim.','final_manifest_observer_block_actual_deltas':[{k:usage(c['final'],k)-usage(c['rows'][-1]['after'],k) for k in ['worker_requests','do_requests','do_rows_read','do_rows_written','r2_class_b','r2_read_bytes']} for c in cs],'full_bill_usd':None,'net_cost_speed_acceptance_claim':False,'inputs':[rec(r/'contract.json') for r in roots],'review_program':rec(Path(__file__)),'offline_review_correction':'Initial tool-only review incorrectly expected tracked_keys/truncated=false to imply a complete key display. Corrected to require displayed==tracked; all raw evidence unchanged.'}
p=Path(f'/tmp/git-zero-joint-canonical{profile}-paired-review.json');p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'review':rec(p),'rows':len(rows),'actual_response_pairs':len(responses),'totals':totals},indent=2))
