"""Offline decoding of preserved responses only; no service or source mutation."""
from pathlib import Path
import datetime,hashlib,json,os,struct,subprocess,sys
name,row,*root_strings=sys.argv[1:]
assert len(root_strings)==2
prefix=Path('/dev/shm/git-zero-joint-correctness-20261018');out=prefix/name
assert not out.exists();out.mkdir()
roots=list(map(Path,root_strings));results=[]
def digest(b):return hashlib.sha256(b).hexdigest()
def record(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def git(repo,args,input=None,save=None):
 cmd=['git','-C',str(repo),*args]
 p=subprocess.run(cmd,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if save:
  (out/(save+'.stdout')).write_bytes(p.stdout);(out/(save+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==0,(cmd,p.returncode,p.stderr.decode(errors='replace'))
 return p.stdout
for mode,root in zip(['multi','joint'],roots):
 req=(root/(row+'.request')).read_bytes();body=(root/(row+'.body')).read_bytes();assert (root/(row+'.status')).read_text()=='200'
 # The saved request deliberately negotiates plain PACK, not sideband.
 assert b'side-band' not in req
 want=req.split(b'want ',1)[1].split()[0].decode();have=req.split(b'have ',1)[1].split()[0].decode()
 at=body.find(b'PACK');assert at>=4
 packet_prefix=body[:at];i=0;packets=[]
 while i<len(packet_prefix):
  size=int(packet_prefix[i:i+4],16);assert size>=4;packets.append(packet_prefix[i+4:i+size].decode());i+=size
 assert i==len(packet_prefix) and packets==[f'ACK {have}\n']
 packed=body[at:];assert struct.unpack('!I',packed[4:8])[0]==2;count=struct.unpack('!I',packed[8:12])[0];assert hashlib.sha1(packed[:-20]).digest()==packed[-20:]
 repo=out/(mode+'.git');p=subprocess.run(['git','init','-q','--bare',str(repo)],capture_output=True);assert p.returncode==0
 seed=git(root/'source',['pack-objects','--stdout','--revs','--window=0'],(have+'\n').encode());(out/(mode+'-seed.pack')).write_bytes(seed)
 git(repo,['index-pack','--stdin','--strict'],seed,mode+'-seed-index');git(repo,['update-ref','refs/heads/actual-have',have])
 index=git(repo,['index-pack','--stdin','--strict','--fix-thin'],packed,mode+'-index');oid=index.decode().strip().split()[-1];idx=repo/'objects'/'pack'/('pack-'+oid+'.idx')
 listing=git(repo,['verify-pack','-v',str(idx)],save=mode+'-verify-pack');records=[]
 for line in listing.decode().splitlines():
  cols=line.split()
  if len(cols)>=5 and len(cols[0])==40 and cols[1] in ['commit','tree','blob','tag']:
   records.append({'OID':cols[0],'type':cols[1],'reported_size':int(cols[2]),'pack_bytes':int(cols[3]),'offset':int(cols[4]),'delta_depth':int(cols[5]) if len(cols)>5 else 0,'delta_base':cols[6] if len(cols)>6 else None})
 records.sort(key=lambda x:x['offset']);assert len(records)==count
 objects=[]
 for v in records:
  kind=git(repo,['cat-file','-t',v['OID']]).decode().strip();data=git(repo,['cat-file',kind,v['OID']]);assert hashlib.sha1(f'{kind} {len(data)}\0'.encode()+data).hexdigest()==v['OID'];objects.append({'OID':v['OID'],'type':kind,'bytes':len(data),'content_SHA256':digest(data)})
 git(repo,['update-ref','refs/heads/wanted',want]);git(repo,['fsck','--strict','--no-reflogs'],save=mode+'-fsck')
 archive=git(repo,['archive',want]);(out/(mode+'-wanted-archive.tar')).write_bytes(archive);source_archive=git(root/'source',['archive',want]);assert archive==source_archive
 if mode=='multi':(out/'source-wanted-archive.tar').write_bytes(source_archive)
 results.append({'mode':mode,'wanted_ref':want,'acknowledged_have':have,'seed_pack_sha256':digest(seed),'raw_body':record(root/(row+'.body')),'request':record(root/(row+'.request')),'raw_body_sha256':digest(body),'raw_body_bytes':len(body),'prefix_hex':packet_prefix.hex(),'packet_controls':packets,'pack_offset':at,'pack_header_version':2,'pack_header_objects':count,'pack_sha256':digest(packed),'pack_trailer_sha1':packed[-20:].hex(),'pack_trailer_verified':True,'strict_index_pack_passed':True,'verify_pack_passed':True,'fsck_strict_passed':True,'archive':record(out/(mode+'-wanted-archive.tar')),'archive_equals_source':True,'ordered_pack_records':records,'decoded_objects':objects})
a,b=results;assert a['request']['sha256']==b['request']['sha256'] and a['prefix_hex']==b['prefix_hex'];assert a['wanted_ref']==b['wanted_ref'] and a['acknowledged_have']==b['acknowledged_have'];assert a['decoded_objects']==b['decoded_objects'];assert a['archive']['sha256']==b['archive']['sha256'];changes=[]
for x,y in zip(a['ordered_pack_records'],b['ordered_pack_records']):
 if any(x[k]!=y[k] for k in ['type','reported_size','pack_bytes','delta_depth','delta_base']):changes.append({'OID':x['OID'],'multi':x,'joint':y})
proof={'kind':'offline actual raw Git response variance decoding; no runtime or source change','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'row':row,'roots':[str(r) for r in roots],'backing':'volatile local-only tmpfs; compact proof mirrored to /tmp','same_request_and_ACK_prefix':True,'sideband':'not negotiated; complete plain ACK packet prefix parsed, then unframed raw PACK through verified checksum','same_ordered_OIDs':True,'all_decoded_OID_type_size_content_SHA256_exactly_equal':True,'decoded_objects':len(a['decoded_objects']),'raw_body_byte_difference_joint_minus_multi':b['raw_body_bytes']-a['raw_body_bytes'],'pack_encoding_changes':changes,'results':results,'cause_scope':'Representation differences established in listed pack records; no timing or nondeterminism cause claim; no production encoding adjustment','proof_program':record(Path(__file__))}
p=out/'proof.json';p.write_text(json.dumps(proof,indent=2)+'\n');meta=Path('/tmp/git-zero-joint-correctness-manifests')/name;assert meta.is_dir();(meta/'proof.json').write_bytes(p.read_bytes());print(json.dumps({'proof':record(p),'persistent':record(meta/'proof.json'),'objects':len(a['decoded_objects']),'difference':proof['raw_body_byte_difference_joint_minus_multi'],'changed_record_OIDs':[v['OID'] for v in changes]},indent=2))
