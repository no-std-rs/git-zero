"""Compare fresh run receipts; never benchmarks, repairs or modifies raw evidence."""
import collections,csv,hashlib,json
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r13-r15-screen/run-39106495382')
PROVIDERS=['r13','r14','r15'];PROFILES=['16mib-cold','16mib-warm','64mib-cold','64mib-warm']
def save(n,v):(ROOT/n).write_text(json.dumps(v,indent=2)+'\n')
def counts(rows):
    keys=rows[0]['cloudflare_workload_delta']
    return {k:None if rows[0]['cloudflare_workload_delta'][k] is None else sum(r['cloudflare_workload_delta'][k] for r in rows) for k in keys}
def difference(a,b):return {k:None if a[k] is None or b[k] is None else a[k]-b[k] for k in a}
trial_records=[];operation_records=[];fixed_differences=[];sql_rows=[];tail_details=[]
for profile in PROFILES:
    directory=ROOT/'profiles'/profile
    if not (directory/'checksum-verification.txt').exists():continue
    reports={p:json.loads((directory/p/f'{profile}.json').read_text()) for p in PROVIDERS}
    for sample in [-1,0,1]:
        by={p:[r for r in v['raw'] if r['sample']==sample and r['backend']=='cloudflare-local'] for p,v in reports.items()}
        aggregate={p:counts(rows) for p,rows in by.items()}
        fixed_differences.append({'profile':profile,'sample':sample,'warmup':sample<0,'r14_minus_r13':difference(aggregate['r14'],aggregate['r13']),'r15_minus_r14':difference(aggregate['r15'],aggregate['r14'])})
        for p,rows in by.items():
            totals=collections.Counter()
            for r in rows:
                for k,v in r['service_metrics_delta'].items():
                    if k.startswith('gateway_read_'):totals[k]+=v
            final=next(r for r in reports[p]['cloudflare_runs'] if r['sample']==sample)['final_object_stats']
            assert final['manifest'].get('garbage',[])==[]
            assert final['cloudflare_services']['do_sqlite_bytes']==24576
            assert final['retired_chunk_deletes']>0
            rec={'provider':p,'profile':profile,'sample':sample,'warmup':sample<0,'actual_gateway_native_events':dict(totals),'fixed_workload_receipt':aggregate[p],'first_push_receipt':rows[0]['cloudflare_workload_delta'],'first_push_SQLite_bytes_before':rows[0]['cloudflare_services_before']['do_sqlite_bytes'],'first_push_SQLite_bytes_after':rows[0]['cloudflare_services_after']['do_sqlite_bytes'],'startup_receipt':final['cloudflare_services']['by_phase']['startup'],'actual_final_SQLite_bytes':final['cloudflare_services']['do_sqlite_bytes'],'actual_retired_chunk_deletes':final['retired_chunk_deletes'],'actual_final_manifest_debt':final['manifest'].get('garbage',[]),'observability_limit':'Actual observed trial only; absence of a transition or HEAD does not establish permanent proof validity. No observer repair is credited to the fixed objective.'}
            if p=='r15' and profile.endswith('cold'):
                assert totals['gateway_read_consumed']>0 and totals['gateway_read_plans']>=totals['gateway_read_consumed']
                assert totals['gateway_read_errors']==totals['gateway_read_generation_changed']==totals['gateway_read_paid_discards']==0
            else:assert totals['gateway_read_consumed']==totals['gateway_read_plans']==0
            trial_records.append(rec)
            pushes=[r for r in rows if r['operation']['kind']=='push']
            sql_rows.append({'provider':p,'profile':profile,'sample':sample,'warmup':sample<0,'first_push_actual_SQL_rows_written':pushes[0]['cloudflare_workload_delta']['do_rows_written'],'all_pushes_actual_SQL_rows_written':sum(r['cloudflare_workload_delta']['do_rows_written'] for r in pushes),'all_fixed_actual_SQL_rows_written':aggregate[p]['do_rows_written'],'per_push_actual_SQL_rows_written':[{'generation':r['operation']['generation'],'rows_written':r['cloudflare_workload_delta']['do_rows_written'],'rows_read':r['cloudflare_workload_delta']['do_rows_read']} for r in pushes]})
        for baseline,candidate in [('r13','r14'),('r14','r15')]:
            for a,b in zip(by[baseline],by[candidate]):
                assert a['operation']==b['operation']
                receipt_diff=difference(b['cloudflare_workload_delta'],a['cloudflare_workload_delta'])
                entry={'profile':profile,'sample':sample,'warmup':sample<0,'baseline':baseline,'candidate':candidate,'operation':b['operation'],'actual_receipt_difference':receipt_diff,'candidate_gateway_native_events':{k:v for k,v in b['service_metrics_delta'].items() if k.startswith('gateway_read_')},'baseline_SQLite_before_after':[a[f'cloudflare_services_{when}']['do_sqlite_bytes'] for when in ['before','after']],'candidate_SQLite_before_after':[b[f'cloudflare_services_{when}']['do_sqlite_bytes'] for when in ['before','after']]}
                if (baseline,candidate)==('r14','r15'):
                    for k in ['r2_class_a','r2_class_b','r2_read_bytes','r2_written_bytes','r2_deletes','do_rows_written','worker_gateway_requests']:
                        assert receipt_diff[k]==0,(profile,sample,b['operation']['key'],k,receipt_diff[k])
                    if b['operation']['kind']=='fetch':
                        consumed=b['service_metrics_delta'].get('gateway_read_consumed',0)
                        assert receipt_diff['worker_service_requests']==receipt_diff['worker_requests']==receipt_diff['do_requests']==-consumed,(profile,sample,b['operation']['key'],receipt_diff,consumed)
                operation_records.append(entry)
        assert aggregate['r14']['do_rows_written']<aggregate['r13']['do_rows_written']
        assert aggregate['r14']['do_rows_written']==aggregate['r15']['do_rows_written']
# Preserve every operation pair in each failed latency workload.
if (ROOT/'guard-report.json').exists():
    guards=json.loads((ROOT/'guard-report.json').read_text())
    for c in guards['comparisons']:
        for failed in c['failed_latency_guards']:
            profile=failed['profile'];group=failed['workload']
            detail={'comparison':c['name'],'profile':profile,'group':group,'guard':failed,'all_baseline_and_candidate_pairs':[]}
            for p in [c['baseline'],c['candidate']]:
                report=json.loads((ROOT/'profiles'/profile/p/f'{profile}.json').read_text())
                for r in report['raw']:
                    if r['warmup'] or r['backend']!='cloudflare-local' or r.get('operation',{}).get('group')!=group:continue
                    g=next(v for v in report['raw'] if v['backend']=='git' and v['sample']==r['sample'] and v.get('operation')==r['operation'])
                    host=r.get('ready_wall_ms',r['wall_ms']);git=g.get('ready_wall_ms',g['wall_ms'])
                    detail['all_baseline_and_candidate_pairs'].append({'provider':p,'sample':r['sample'],'operation':r['operation'],'host_ms':host,'git_ms':git,'ratio':host/git,'fixed_receipt':r['cloudflare_workload_delta'],'native_metric_delta':r['service_metrics_delta'],'host_client_resources':r['client_resources'],'Git_client_resources':g['client_resources'],'contention_before':r['run_contention_before'],'contention_after':r['run_contention_after']})
            tail_details.append(detail)
save('r14-r15-trial-activation-and-SQL-review.json',trial_records)
save('r14-r15-every-operation-receipt-differences.json',operation_records)
save('r14-r15-fixed-workload-receipt-differences.json',fixed_differences)
save('r14-r15-every-push-SQL-review.json',sql_rows)
save('latency-failure-pair-details.json',tail_details)
print(json.dumps({'trial_records':len(trial_records),'per_operation_comparison_receipts':len(operation_records),'failed_workload_details':len(tail_details)}))
