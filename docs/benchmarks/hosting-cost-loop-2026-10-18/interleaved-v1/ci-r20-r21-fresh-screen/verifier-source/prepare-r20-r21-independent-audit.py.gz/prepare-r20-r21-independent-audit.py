import json,hashlib,subprocess
from pathlib import Path
OLD=Path('/tmp/git-zero-r19-r20-run-39128927970-audit')
NEW=Path('/tmp/git-zero-r20-r21-run-39145424189-audit');NEW.mkdir(exist_ok=True)
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189');ROOT.mkdir(parents=True,exist_ok=True)
SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
DECL=Path('/tmp/git-zero-r20-r21-screen-source-identities.json')
d=json.loads(DECL.read_text());(ROOT/'prospective-source-identities.json').write_bytes(DECL.read_bytes())
def git(*a):return subprocess.check_output(['git','-C',str(SOURCE),*a])
def h(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==d['head'];assert git('status','--porcelain')==b''
prior=json.loads(Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970/expected-source-identities.json').read_text())
e={'reference_commit':d['baseline_reference'],'reference_tree':git('rev-parse',d['baseline_reference']+'^{tree}').decode().strip(),'reference_manifest_sha256':{p:h(git('show',d['baseline_reference']+':'+p)) for p in prior['reference_manifest_sha256']},'head':d['head'],'head_tree':git('rev-parse',d['head']+'^{tree}').decode().strip(),'head_parent':git('rev-parse',d['head']+'^').decode().strip(),'worker_source_tree':d['sources']['r21']['WorkerSRC'],'sources':{},'providers':{}}
for p,v in prior['sources'].items():e['sources'][p]={'current_sha256':h(git('show',d['head']+':'+p)),'prior_sha256':v['current_sha256']}
for label in ['r20','r21']:
 v=d['sources'][label];commit=v['commit']
 subprocess.run(['git','-C',str(SOURCE),'merge-base','--is-ancestor',commit,d['head']],check=True)
 e['providers'][label]={'commit':commit,'tree':git('rev-parse',commit+'^{tree}').decode().strip(),'native_source_tree':git('rev-parse',commit+':examples/repository-host/src').decode().strip(),'manifest_sha256':{p:h(git('show',commit+':'+p)) for p in ['Cargo.lock','Cargo.toml','examples/repository-host/Cargo.toml']}}
 assert e['providers'][label]['native_source_tree']==v['NativeSRC']
p=prior['pricing_source']['path'];e['pricing_source']={'path':p,'current_sha256':h(git('show',d['head']+':'+p)),'prior_sha256':prior['pricing_source']['current_sha256']}
(ROOT/'expected-source-identities.json').write_text(json.dumps(e,indent=2)+'\n')
provenance=[]
def adapt(s):
 return s.replace('r20','__NEXT__').replace('r19','r20').replace('__NEXT__','r21').replace('R20','__NEXT__').replace('R19','R20').replace('__NEXT__','R21').replace('39128927970','39145424189').replace('d5cdefe53fc24f34114292b7d19563e73afea293',d['head'])
for p in sorted(OLD.glob('*.py')):
 if p.name in ['seal-screen.py','source-policy-review.py']:continue
 (NEW/p.name).write_text(adapt(p.read_text()))
 provenance.append({'derived_script':p.name,'prior_code_only_path':str(p),'prior_code_SHA256':h(p.read_bytes()),'adaptation':'Updated current-run root/head/id/provider labels. R21-specific fit response policy amended independently before execution. No historical samples/reports/scores copied.'})
p=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970/summarize-chain.py');(ROOT/p.name).write_text(adapt(p.read_text()));provenance.append({'derived_script':'summarize-chain.py','prior_code_only_path':str(p),'prior_code_SHA256':h(p.read_bytes())})
(NEW/'ADAPTATION_PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'new_tooling':str(NEW),'new_root':str(ROOT),'source_files':len(e['sources']),'providers':e['providers']}))
