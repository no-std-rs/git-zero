"""Independent receipt, strict Git readiness, selected-pack and accounting audit.

Only reads reports produced by the already authorized Rust CI runner.
"""
import collections
import csv
import json
import math
from pathlib import Path

ROOT = Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189')
PROVIDERS = ["r20", "r21"]
PROFILES = ["16mib-cold", "16mib-warm", "64mib-cold", "64mib-warm"]
CONFIG = [
    ["receive.unpackLimit", "0"], ["transfer.unpackLimit", "0"],
    ["receive.autogc", "false"], ["gc.auto", "0"],
    ["receive.fsckObjects", "true"], ["core.fsync", "committed"],
    ["core.fsyncMethod", "fsync"], ["core.multiPackIndex", "true"],
    ["repack.writeBitmaps", "true"], ["pack.writeReverseIndex", "true"],
    ["pack.threads", "0"], ["pack.window", "10"], ["pack.depth", "50"],
    ["http.receivepack", "true"], ["pack.allowPackReuse", "multi"],
]
COMMANDS = [["multi-pack-index", "write", "--bitmap"],
            ["commit-graph", "write", "--reachable", "--split"]]
RATES = {"r2_class_a": 4.5 / 1e6, "r2_class_b": .36 / 1e6,
         "worker_requests": .30 / 1e6, "do_requests": .15 / 1e6,
         "do_rows_read": .001 / 1e6, "do_rows_written": 1 / 1e6}


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n")


def usage(snapshot, key):
    value = snapshot.get(key)
    observer = snapshot["by_phase"].get("stats", {}).get(key, 0)
    return None if value is None or observer is None else value - observer


def audit_snapshot(snapshot):
    assert snapshot["accounting_complete"] is True
    assert snapshot["accounting_errors"] == []
    assert snapshot["local_only"] is True and snapshot["runtime"] == "workerd"
    assert snapshot["counter_scope"] and snapshot["counter_epoch"]
    for key in ["worker_cpu_ms", "do_gb_seconds"]:
        assert snapshot[key] is None
    ops = snapshot["operations"]
    for name, op in ops.items():
        for key in ["attempts", "successes", "failures", "read_bytes", "written_bytes"]:
            assert isinstance(op[key], int) and op[key] >= 0
        assert op["attempts"] == op["successes"] + op["failures"]
        assert op["failures"] == 0
    gets = ops.get("r2_get", {})
    heads = ops.get("r2_head", {})
    assert gets.get("attempts", 0) + heads.get("attempts", 0) == snapshot["r2_class_b"]
    assert gets.get("read_bytes", 0) == snapshot["r2_read_bytes"]
    assert snapshot["r2_peak_bytes"] >= snapshot["r2_live_bytes"]
    assert snapshot["worker_requests"] == sum(snapshot[k] for k in [
        "worker_gateway_requests", "worker_service_requests", "worker_observer_requests"])


rows_out, trials, activation, per_rpc = [], [], [], []
counts = collections.Counter()
for profile in PROFILES:
    directory = ROOT / "profiles" / profile
    if not (directory / "checksum-verification.txt").exists():
        continue
    for provider in PROVIDERS:
        report = json.loads((directory / provider / f"{profile}.json").read_text())
        config = report["config"]
        assert config["reference"] == CONFIG
        assert config["reference_maintenance_commands"] == COMMANDS
        assert config["protocol"] == 0 and config["http_post_buffer"] == 268435456
        assert config["fetch_unpack_limit"] == 1
        assert report["fixture"]["working_tree_bytes"] == int(profile.split("mib")[0]) * 1024**2
        report_epoch = None
        for sample in [-1, 0, 1]:
            raw = [r for r in report["raw"] if r["sample"] == sample]
            cf = [r for r in raw if r["backend"] == "cloudflare-local"]
            run = next(r for r in report["cloudflare_runs"] if r["sample"] == sample)
            stats = run["final_object_stats"]
            selected = dict.fromkeys(["selected_packs", "selected_bytes", "total_packs", "total_bytes", "generation"], 0)
            fixed = dict.fromkeys(cf[0]["cloudflare_workload_delta"], 0)
            events = collections.Counter()
            requests = collections.Counter()
            for row in cf:
                counts["cloudflare_operation_rows"] += 1
                op = row["operation"]
                before, after = (row[f"cloudflare_services_{phase}"] for phase in ["before", "after"])
                for snapshot in [before, after]:
                    audit_snapshot(snapshot)
                assert (before["counter_scope"], before["counter_epoch"]) == (after["counter_scope"], after["counter_epoch"])
                epoch = (before["counter_scope"], before["counter_epoch"])
                if report_epoch is None:
                    report_epoch = epoch
                assert epoch == report_epoch
                delta = row["cloudflare_workload_delta"]
                for key, value in delta.items():
                    actual = None if usage(after, key) is None or usage(before, key) is None else usage(after, key) - usage(before, key)
                    assert value == actual, (profile, provider, sample, op["key"], key, value, actual)
                    assert value is None or value >= 0
                    fixed[key] = None if value is None or fixed[key] is None else fixed[key] + value
                assert delta["worker_observer_requests"] == 0
                metric = row["service_metrics_delta"]
                for key in ["history_projections", "history_full_restores", "cloud_view_rehydrates"]:
                    events[key] += metric.get(key, 0)
                # /metrics does not restore or change a native view. The initial
                # view has zero packs; contiguous numeric deltas therefore retain
                # the actual selected-pack gauges after every timed operation.
                for key in selected:
                    selected[key] += metric.get("native_view", {}).get(key, 0)
                    assert selected[key] >= 0
                assert selected["selected_packs"] <= selected["total_packs"]
                assert selected["selected_bytes"] <= selected["total_bytes"]
                binding = {}
                for name in set(before["operations"]) | set(after["operations"]):
                    binding[name] = {key:after["operations"].get(name, {}).get(key, 0) - before["operations"].get(name, {}).get(key, 0)
                                     for key in ["attempts", "successes", "failures", "read_bytes", "written_bytes"]}
                    assert all(value >= 0 for value in binding[name].values())
                    requests[name] += binding[name]["attempts"]
                per_rpc.append({"provider":provider,"profile":profile,"sample":sample,"operation":op,
                    "actual_snapshot_operation_delta_including_observer":binding,
                    "exact_timed_workload_receipt":delta,
                    "actual_observer_counter_delta":{k:after["by_phase"].get("stats",{}).get(k,0)-before["by_phase"].get("stats",{}).get(k,0)
                                                     for k in delta if after["by_phase"].get("stats",{}).get(k,0) is not None},
                    "actual_selected_numeric_gauges_after_timing":dict(selected),
                    "native_event_delta":{k:metric.get(k,0) for k in events}})
                counts["snapshot_receipts"] += 2
                if op["kind"] == "fetch":
                    assert before["r2_live_bytes"] == after["r2_live_bytes"]
                    assert before["r2_live_objects"] == after["r2_live_objects"]
                    assert before["do_sqlite_bytes"] == after["do_sqlite_bytes"]
                    assert before["manifest_generation"] == after["manifest_generation"] == op["generation"]
                    assert all(delta[k] == 0 for k in ["r2_class_a", "r2_deletes", "r2_written_bytes", "do_rows_written"])
                    if profile.endswith("warm"):
                        assert delta["r2_class_b"] == delta["r2_read_bytes"] == 0
                    counts["reads_without_authoritative_growth"] += 1
                else:
                    for field, key in [("count","compactions"),("input_bytes","compaction_input_bytes"),("output_bytes","compaction_output_bytes"),("retired_chunk_deletes","retired_chunk_deletes")]:
                        assert row["compaction_delta"][field] == metric[key]
                    counts["push_generation_compaction_checks"] += 1
                if sample >= 0:
                    rows_out.append({"provider":provider,"profile":profile,"sample":sample,"operation":op["key"],"group":op["group"],
                        **{"selected_"+k:v for k,v in selected.items()},"r2_read_bytes":delta["r2_read_bytes"],"r2_class_b":delta["r2_class_b"],
                        "actual_get_attempts_with_observer":binding.get("r2_get",{}).get("attempts",0),
                        "actual_head_attempts_with_observer":binding.get("r2_head",{}).get("attempts",0)})
            for row in raw:
                if row["backend"] != "git" or "operation" not in row:
                    continue
                op = row["operation"]
                if op["kind"] != "push":
                    continue
                maintenance = next(m for m in raw if m["backend"] == "git" and m["workload"] == "maintenance_after_"+op["key"])
                assert [c["args"] for c in maintenance["commands"]] == COMMANDS
                assert all(c["wall_ms"] > 0 for c in maintenance["commands"])
                assert math.isclose(sum(c["wall_ms"] for c in maintenance["commands"]), maintenance["wall_ms"], abs_tol=1e-6)
                for push in [row,next(r for r in cf if r["operation"]["key"] == op["key"])]:
                    assert math.isclose(push["wall_ms"],push["push_wire_wall_ms"],abs_tol=1e-6)
                    assert math.isclose(push["ready_wall_ms"],push["push_wire_wall_ms"]+push["maintenance_wall_ms"],abs_tol=1e-6)
                    assert push["push_wire_bytes"] == push["service_metrics_delta"]["input_bytes"]
                    if op["group"] == "large_push":
                        minimum = report["fixture"]["working_tree_bytes"]*.4 if op["generation"] == 1 else 3*1024**2
                        assert push["push_wire_bytes"] >= minimum
                    counts["ready_wire_threshold_checks"] += 1
                assert row["maintenance_wall_ms"] == maintenance["wall_ms"]
            audit_snapshot(stats["cloudflare_services"])
            actual_final = stats["native_view"]
            # The final inventory may perform a separately accounted full restore.
            assert selected["generation"] == actual_final["generation"] == 32
            assert selected["total_packs"] == actual_final["total_packs"]
            assert selected["total_bytes"] == actual_final["total_bytes"]
            activation.append({"provider":provider,"profile":profile,"sample":sample,"warmup":sample<0,
                "timed_native_events":dict(events),"final_native_events":{k:stats[k] for k in events},
                "last_timed_native_gauges":dict(selected),"observer_final_view":actual_final,
                "actual_snapshot_request_attempts_including_observer":dict(requests)})
            if profile.endswith("cold"):
                assert events["history_projections"] > 0
            if sample >= 0 and (ROOT/"offline"/f"{provider}-score.json").exists():
                score = json.loads((ROOT/"offline"/f"{provider}-score.json").read_text())
                scored = next(t for t in score["profiles"][profile]["trials"] if t["sample"] == sample)
                assert fixed == scored["fixed_workload"]
                actual_known = sum(fixed[k] * 1000 * rate for k,rate in RATES.items()) + stats["cloudflare_services"]["r2_peak_bytes"] / 1e9 * .015
                assert math.isclose(actual_known,scored["known_monthly_fixed_workload_usd"],abs_tol=1e-12)
                trials.append({"provider":provider,"profile":profile,"sample":sample,"independently_priced_fixed_usd":actual_known,
                    "exact_fixed_workload":fixed,"one_repository_peak_bytes":stats["cloudflare_services"]["r2_peak_bytes"],
                    "startup_separate":stats["cloudflare_services"]["by_phase"]["startup"]})

save("strict-receipt-review.json", {"counts":dict(counts),"priced_measured_trials":trials,
    "selection_gauge_method":"Cumulative numeric native_view deltas from zero-pack startup; /metrics has no view materialization side effect. Final full object inventory is separate.",
    "worker_class_b_method":"At every snapshot, R2 Class B = actual GET attempts + actual HEAD attempts; missing operation key means zero attempts. GET read_bytes reconcile exactly.",
    "all_reads_without_r2_sqlite_or_manifest_growth":True,"unknown_full_bill_usd":None})
save("activation-review.json",activation)
save("per-rpc-accounting-and-selected-packs.json",per_rpc)
with (ROOT/"actual-selected-packs-and-reads.tsv").open("w") as stream:
    if rows_out:
        writer=csv.DictWriter(stream,fieldnames=list(rows_out[0]),delimiter="\t")
        writer.writeheader();writer.writerows(rows_out)
print(json.dumps({"counts":dict(counts),"activation_trials":len(activation),"priced_measured_trials":len(trials)}))
