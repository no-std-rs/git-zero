"""Read-only complete source identities and current R20/R21 policy receipts."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189')
SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
d=json.loads((ROOT/'prospective-source-identities.json').read_text())
expected=json.loads((ROOT/'expected-source-identities.json').read_text())
def git(*a):return subprocess.check_output(['git','-C',str(SOURCE),*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def manifest(commit,prefix):return {p:sha(git('show',commit+':'+p)) for p in git('ls-tree','-r','--name-only',commit,'--',prefix).decode().splitlines()}
assert git('rev-parse','HEAD').decode().strip()==d['head']
assert git('status','--porcelain')==b''
common_native_tree=git('rev-parse',d['head']+':examples/repository-host/src').decode().strip();assert common_native_tree==d['sources']['integrated']['NativeSRC']
providers={}
for label in ['r20','r21']:
 v=d['sources'][label];commit=v['commit']
 providers[label]={'commit':commit,'native_source_tree':git('rev-parse',commit+':examples/repository-host/src').decode().strip(),'every_native_source_file_SHA256':manifest(commit,'examples/repository-host/src')}
 assert providers[label]['native_source_tree']==v['NativeSRC']
 assert manifest(commit,'examples/repository-host/cloudflare/src')==v['modules']
actual=manifest(d['head'],'examples/repository-host/src');pinned=providers['r21']['every_native_source_file_SHA256']
changed=[p for p in sorted(actual.keys()|pinned.keys()) if actual.get(p)!=pinned.get(p)]
assert changed==d['integrated_vs_provider_Native_source_differences'],changed
worker=manifest(d['head'],'examples/repository-host/cloudflare/src');assert worker==d['sources']['r21']['modules'];assert len(worker)==6
unchanged={p:v for p,v in expected['sources'].items() if p.endswith(('hosting-bench.rs','hosting-cost.rs','benchmark_cost.rs'))}
assert all(v['current_sha256']==v['prior_sha256'] for v in unchanged.values())
assert expected['pricing_source']['current_sha256']==expected['pricing_source']['prior_sha256']
native_changed=git('diff','--name-only',d['sources']['r20']['commit'],d['sources']['r21']['commit'],'--','examples/repository-host/src').decode().splitlines()
assert native_changed==['examples/repository-host/src/bin/repository-host.rs','examples/repository-host/src/native.rs']
policy={
 'default':'R20 Joint and R21 Joint both retain up to32 chunks in cold mode; warm Off. R20 upload responses use legacy evicting cache insertion. R21 Native and CLI default Fit; explicit Evict remains an available production policy.',
 'fit_scope':'Both production direct and gateway upload-pack miss paths call cache_upload_response. Fit is active only for Cloudflare+cold+Joint+nonempty protected owners; other cases use legacy cache_insert. Discovery stays on legacy insertion and mandatory pressure authority remains unchanged.',
 'fit_checks':'Only status200 nonempty upload bodies <=16MiB are eligible. Checked capacity/header/body arithmetic and full-new-ring growth bound preflight joint32MiB/256. Clone shares the Arc body; exact cloned owning weight and current metadata are rechecked. Optional rejection or actual try_reserve failure increments counters and does not evict or reorder existing owners. Successful commit allocates no further ring backing and records actual owning charge. Header cloning itself remains infallible as before.',
 'allocation_scope':'Source charges retained owning capacity, key/header bounds, body Arc, full new response-ring backing on top of old backing, pool backing+growth, proof/history/control and262144 socket reservation. It does not measure total request heap or allocator-internal realloc overlap. Source ring bound is not a runtime allocation trace.',
 'get_admission':'Production read_snapshot_selection_cached captures exact verified cached descriptors and visits every required verified missing ordinary GET through admit_chunk. Startup/recovery/observer/PUT/prewarm do not admit. New PUT chunks still require actual paid cold GET; warm payload GET stays zero where observed.',
 'selection_fallback':'Ordered selected digest+length descriptors include captured retained owners and all required misses. Invalid/stale preparation causes paid discard and safe ordinary reconstruction. Unsupported all-cache routes ordinary dispatch. No hypothetical GET/DO/byte/preparation saving or residency superset is asserted.',
 'joint_policy':'Both providers use actual first-fit32MiB/256 joint accounting, pool32, response/chunk16MiB, socket262144. Neither uses the historical Multi17MiB owning preference. Fit never evicts on optional admission; required metadata/discovery pressure still evicts newest secondary then anchor then response LRU.',
 'pruning':'Only confirmed current Full authority/current manifest snapshot establishes logical protected pruning; proposed, stale, ambiguous or projection state does not. Logical pruning is distinct from actual R2 deletion.',
 'runtime_limits':'All704 measured host rows for each provider and all warmups retain gauges/events. The frozen runner exports no complete ordered per-key cache membership/GET timeline, no measured per-push complete HTTP hash, and no transient request heap peak. No later callback/ACK/close/teardown absence, permanent proof validity, or free future GC/recovery is inferred.'}
review={'run_id':39145424189,'attempt':1,'head':d['head'],'providers':providers,'common_head_native_source_tree':common_native_tree,'common_head_native_source_manifest':actual,'head_native_differences_from_pinned_R21':changed,'difference_scope':d['difference_scope'],'common_six_Worker_modules':worker,'provider_native_changed_paths':native_changed,'runner_scorer_entries_unchanged':unchanged,'pricing_source':expected['pricing_source'],'ownership_source_policy':policy,'historical_samples_reports_scores_reused':False}
(ROOT/'whole-source-and-cache-policy-review.json').write_text(json.dumps(review,indent=2)+'\n')
failure='examples/repository-host/src/bin/hosting-bench/failure_logs.rs';prior='b74c91738a3fbfe3ebf30a936fbf9d7ff79f1ae0'
prior_integrated='d5cdefe53fc24f34114292b7d19563e73afea293'
assert git('show',prior_integrated+':'+failure)==git('show',d['head']+':'+failure)
(ROOT/'failure-only-runner-source-audit.json').write_text(json.dumps({'head':d['head'],'failure_only_runner_unchanged_from_prior_integrated_source':True,'failure_module_SHA256':sha(git('show',d['head']+':'+failure)),'successful_workload_scorer_and_pricing_unchanged':True,'prior_source_comparison_only':prior_integrated,'old_samples_reports_scores_used':False},indent=2)+'\n')
print(json.dumps({'provider_native_source_file_counts':{p:len(v['every_native_source_file_SHA256']) for p,v in providers.items()},'common_Worker_modules':len(worker),'head_only_reviewed_diagnostic_files':changed,'provider_change_files':native_changed}))
