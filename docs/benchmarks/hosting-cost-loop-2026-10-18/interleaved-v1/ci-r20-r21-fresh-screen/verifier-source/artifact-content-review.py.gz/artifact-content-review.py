"""Inspect every original archive member/type/signature and all payload caps."""
import json,hashlib,tarfile,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189')
artifacts=[]
for a in json.loads((ROOT/'artifact-index.json').read_text())['artifacts']:
 folder=ROOT/'downloads'/a['name'];archive=next(folder.glob('*.tar.gz'));zpath=next(folder.glob('*.zip'));members=[];seen=set();total=0
 assert archive.stat().st_size<=4194304 and zpath.stat().st_size<=4194304
 with zipfile.ZipFile(zpath) as z:
  assert len(z.infolist())==1 and z.read(z.infolist()[0])==archive.read_bytes()
 with tarfile.open(archive) as tar:
  for m in tar.getmembers():
   p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and '\\' not in m.name
   name=m.name.removeprefix('./').rstrip('/');assert not name or name not in seen;seen.add(name)
   assert m.isdir() or m.isfile();assert not m.issym() and not m.islnk() and not m.sparse
   if not m.isfile():members.append({'path':m.name,'type':'directory'});continue
   b=tar.extractfile(m).read();assert len(b)==m.size;total+=len(b)
   assert not b.startswith((b'\x7fELF',b'SQLite format 3\0',b'PACK',b'\xfftOc')),(a['name'],name)
   assert not any(v in p.parts for v in ['.git','node_modules','.wrangler','state','fixtures','target'])
   assert not name.endswith(('.sqlite','.sqlite3','.db','.pack','.idx','.wasm','.so','.o','.a','.zip','.tar','.tar.gz'))
   if a['name'].startswith('hosting-scores-'):assert name in ['SHA256SUMS','provenance.txt','providers.tsv','r20-score.json','r21-score.json','r21-vs-r20.json'],name
   else:assert name=='SHA256SUMS' or name.startswith(('provenance/','r20/','r21/')),name
   members.append({'path':m.name,'type':'regular','bytes':len(b),'SHA256':hashlib.sha256(b).hexdigest(),'ELF_SQLite_PACK_index_signature':False})
 assert total<=512*1024*1024
 artifacts.append({'artifact_id':a['id'],'artifact_name':a['name'],'original_tar_bytes':archive.stat().st_size,'original_ZIP_bytes':zpath.stat().st_size,'uncompressed_regular_bytes':total,'regular_members':sum(v['type']=='regular' for v in members),'directory_headers':sum(v['type']=='directory' for v in members),'members':members})
assert len(artifacts)==5 and sum(v['original_tar_bytes'] for v in artifacts)<=20971520 and sum(v['original_ZIP_bytes'] for v in artifacts)<=20971520
out={'run_id':39145424189,'artifacts':artifacts,'original_tar_bytes':sum(v['original_tar_bytes'] for v in artifacts),'original_ZIP_bytes':sum(v['original_ZIP_bytes'] for v in artifacts),'original_payload_count':5,'no_native_ELF_large_fixture_or_R2_SQLite_state_in_payload':True,'scope':'Every exact original tar/ZIP remains local; only exact five tar originals are staged for publication. Tar member/signature inspection supplements complete checksums. Hash/provenance records naming an excluded binary or state path are metadata, not that payload. No script executed from an archive.'}
(ROOT/'original-archive-payload-content-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='artifacts'}))
