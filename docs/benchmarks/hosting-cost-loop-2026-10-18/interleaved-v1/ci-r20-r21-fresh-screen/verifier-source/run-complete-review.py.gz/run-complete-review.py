"""Run only offline current-run verification; no benchmark/service/build/network."""
import json,subprocess,shutil
from pathlib import Path
BASE=Path(__file__).parent;ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189')
assert json.loads((ROOT/'run.json').read_text())['conclusion']=='success'
assert json.loads((ROOT/'artifact-index.json').read_text())['total_count']==5
steps=['artifact-content-review.py','source-policy-review.py','source-build-input-review.py','validate-profiles.py','workflow-runtime-review.py','score-offline.py','binary-and-order-audit.py','receipt-review.py','detailed-metrics.py','summarize-resources.py','distribution-review.py','lifecycle-review.py','transport-activation-review.py','service-and-physical-closure-review.py','protected-chunk-review.py','cache-joint-review.py','fit-retention-review.py','separate-phase-pricing-review.py','failure-log-review.py','failed-latency-pair-review.py','tail-completeness-review.py']
logs=[]
for name in steps:
 r=subprocess.run(['python3',str(BASE/name)],capture_output=True,text=True)
 logs.append({'script':name,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 (ROOT/'offline-proof-execution.json').write_text(json.dumps(logs,indent=2)+'\n')
 print(name,r.returncode,r.stdout.strip(),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
frozen=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/evaluators/zero-get-fix')
for name in ['SHA256SUMS','built-source-commit.txt']:shutil.copyfile(frozen/name,ROOT/'offline'/('frozen-evaluator-original-'+name))
for name in ['evaluator-source-provenance.py','finalize-evidence.py']:
 r=subprocess.run(['python3',str(BASE/name)],capture_output=True,text=True)
 logs.append({'script':name,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(ROOT/'offline-proof-execution.json').write_text(json.dumps(logs,indent=2)+'\n');print(name,r.returncode,r.stdout.strip(),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
