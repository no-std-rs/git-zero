"""Hash the complete tracked Rust/Cargo and six-Worker build source, read only."""
import json,hashlib,subprocess
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189');SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
d=json.loads((ROOT/'prospective-source-identities.json').read_text())
def git(*args,**kw):return subprocess.check_output(['git','-C',str(SOURCE),*args],**kw)
commits={'common':d['head'],'r20':d['sources']['r20']['commit'],'r21':d['sources']['r21']['commit'],'reference':d['baseline_reference']};records={}
for label,commit in commits.items():
 rows=[]
 for line in git('ls-tree','-r','-z',commit).split(b'\0'):
  if not line:continue
  left,path=line.split(b'\t',1);mode,kind,oid=left.decode().split();name=path.decode()
  if name.endswith(('.rs','.toml')) or name in ['Cargo.lock','.github/workflows/hosting-isolated.yml','examples/repository-host/cloudflare/package.json','examples/repository-host/cloudflare/package-lock.json'] or name.startswith('examples/repository-host/cloudflare/src/'):
   assert kind=='blob' and mode in ['100644','100755'],(name,mode,kind)
   rows.append({'path':name,'mode':mode,'Git_blob':oid})
 proc=subprocess.run(['git','-C',str(SOURCE),'cat-file','--batch'],input=('\n'.join(v['Git_blob'] for v in rows)+'\n').encode(),capture_output=True,check=True)
 data=proc.stdout;offset=0
 for row in rows:
  end=data.index(b'\n',offset);oid,kind,n=data[offset:end].decode().split();n=int(n);offset=end+1;content=data[offset:offset+n];offset+=n;assert data[offset:offset+1]==b'\n';offset+=1
  assert oid==row['Git_blob'] and kind=='blob' and len(content)==n
  assert hashlib.sha1(b'blob '+str(n).encode()+b'\0'+content).hexdigest()==oid
  row.update(bytes=n,SHA256=hashlib.sha256(content).hexdigest())
 assert offset==len(data)
 records[label]={'commit':commit,'full_Git_tree':git('rev-parse',commit+'^{tree}').decode().strip(),'build_source_files':rows,'tracked_build_source_bytes':sum(v['bytes'] for v in rows)}
assert records['r20']['full_Git_tree']!=records['r21']['full_Git_tree']
out={'run_id':39145424189,'head':d['head'],'sources':records,'scope':'All tracked Rust sources and Cargo TOML/lockfiles across each complete commit, six tracked Worker modules/package/config and workflow. Git blob SHA1 plus decoded SHA256/byte size independently checked. Public commit/tree plus clean build provenance binds full source; actual CI source SHA manifests before and verified again after are separately retained. No historical sample or ELF reused.'}
(ROOT/'complete-tracked-build-source-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'source_commits':len(records),'tracked_build_files_by_source':{k:len(v['build_source_files']) for k,v in records.items()},'tracked_build_bytes_by_source':{k:v['tracked_build_source_bytes'] for k,v in records.items()}}))
