"""Seal every local and Git-decoded review input identity before final output."""
import json,hashlib
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189');BASE=Path(__file__).parent;SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
inputs={}
def take(p,kind):
 p=p.resolve();assert p.is_file() and not p.is_symlink();b=p.read_bytes()
 inputs[str(p)]={'local_path':str(p),'kind':kind,'bytes':len(b),'SHA256':hashlib.sha256(b).hexdigest()}
for folder in ['profiles','scores','downloads','progress']:
 for p in sorted((ROOT/folder).rglob('*')):
  if p.is_file() and p.name!='checksum-verification.txt':take(p,'current-run original artifact or parsed API snapshot' if folder!='progress' else 'local parsed API snapshot bytes; not raw HTTP response bytes')
for name in ['run.json','jobs.json','artifact-index.json','prospective-source-identities.json','expected-source-identities.json','transport-archive-index.json','complete-tracked-build-source-review.json']:
 take(ROOT/name,'current-run declaration, parsed API metadata or source manifest')
for p in sorted(BASE.iterdir()):
 if p.is_file() and p.suffix in ['.py','.json']:take(p,'independent verifier source/tooling provenance')
take(Path('/tmp/prepare-r20-r21-independent-audit.py'),'independent preparation source')
take(ROOT/'summarize-chain.py','derived guard proof source; Rust scoring remains sole scorer')
for p in sorted(Path('/tmp/git-zero-r19-r20-run-39128927970-audit').glob('*.py')):take(p,'historical audit code only; no historical sample or output reused')
for name in ['expected-source-identities.json','summarize-chain.py']:
 take(Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970')/name,'prior source hash declaration or audit code only; no historical samples or scores')
take(Path('/tmp/git-zero-r20-r21-screen-source-identities.json'),'exact prospective declaration original')
frozen=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/evaluators/zero-get-fix')
for name in ['hosting-cost','SHA256SUMS','built-source-commit.txt']:take(frozen/name,'frozen offline Rust evaluator input; ELF local-only')
for p in sorted((SOURCE/'docs/benchmarks/hosting-cost-loop-2026-10-18/interleaved-v1/r21-fit-response-root-review').rglob('*')):
 if p.is_file():take(p,'published exact root R21 integration SOURCE/ledger authority input; source bytes remain in repository')
for name in ['examples/repository-host/src/native.rs','examples/repository-host/src/bin/repository-host.rs','examples/repository-host/src/bin/hosting-cost.rs','examples/repository-host/src/benchmark_cost.rs','examples/repository-host/src/cost.rs','.github/workflows/hosting-isolated.yml']:
 take(SOURCE/name,'current integrated source inspected; pinned provider full-source manifests separate')
build=json.loads((ROOT/'complete-tracked-build-source-review.json').read_text())
virtual=[{'kind':'Git-decoded source','commit':v['commit'],**row} for v in build['sources'].values() for row in v['build_source_files']]
values=sorted(inputs.values(),key=lambda r:r['local_path'])
out={'run_id':39145424189,'attempt':1,'scope':'Complete consumed local input bytes plus complete Git-decoded tracked Rust/Cargo/Worker/workflow source inputs. Derived outputs and this inventory are excluded to avoid circular identity. Original API ZIPs and evaluator ELF stay local-only; exact embedded tar originals, metadata and all virtual source hashes are published. No historical sample/report/score enters this inventory. Reused audit code is identified in ADAPTATION_PROVENANCE, not historical outputs. API snapshots are parsed/reserialized local records, not claimed raw HTTP bytes.','local_inputs':values,'local_input_files':len(values),'local_input_bytes':sum(v['bytes'] for v in values),'Git_decoded_source_inputs':virtual,'Git_decoded_source_input_files':len(virtual),'Git_decoded_source_input_bytes':sum(v['bytes'] for v in virtual)}
(ROOT/'INPUT_SHA256_INVENTORY.json').write_text(json.dumps(out,indent=2)+'\n')
(ROOT/'INPUT_SHA256SUMS').write_text(''.join(f"{v['SHA256']}  {v['local_path']}\n" for v in values))
for v in values:assert hashlib.sha256(Path(v['local_path']).read_bytes()).hexdigest()==v['SHA256']
print(json.dumps({k:out[k] for k in ['local_input_files','local_input_bytes','Git_decoded_source_input_files','Git_decoded_source_input_bytes']}))
