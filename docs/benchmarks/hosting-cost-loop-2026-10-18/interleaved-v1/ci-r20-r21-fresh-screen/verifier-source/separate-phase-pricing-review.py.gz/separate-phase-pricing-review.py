"""Offline arithmetic proof of all actual phase usage at already-frozen rates.

This does not score a suite or replace the frozen Rust evaluator.
"""
import json,math
from decimal import Decimal
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189')
rates={'r2_class_a':Decimal('0.0000045'),'r2_class_b':Decimal('0.00000036'),'worker_requests':Decimal('0.00000030'),'do_requests':Decimal('0.00000015'),'do_rows_read':Decimal('0.000000001'),'do_rows_written':Decimal('0.000001')}
def price(v):
 values={k:None if v.get(k) is None else str(Decimal(v[k])*rate) for k,rate in rates.items()}
 return {'resource_known_traffic_USD':values,'known_traffic_USD':None if any(x is None for x in values.values()) else str(sum(Decimal(x) for x in values.values())),'full_bill_USD':None}
out=[]
for profile in ['16mib-cold','16mib-warm','64mib-cold','64mib-warm']:
 for provider in ['r20','r21']:
  r=json.loads((ROOT/'profiles'/profile/provider/f'{profile}.json').read_text())
  for sample in [-1,0,1]:
   rs=[v for v in r['raw'] if v['backend']=='cloudflare-local' and v['sample']==sample];run=next(v for v in r['cloudflare_runs'] if v['sample']==sample);s=run['final_object_stats']['cloudflare_services']
   assert s['accounting_complete'] and not s['accounting_errors'] and all(v['failures']==0 for v in s['operations'].values())
   fixed={k:None if rs[0]['cloudflare_workload_delta'][k] is None else sum(v['cloudflare_workload_delta'][k] for v in rs) for k in rs[0]['cloudflare_workload_delta']}
   phases={name:{'exact_actual_counters':v,'once_observed_known_traffic':price(v),'1000_replay_traffic_only':price({k:None if v.get(k) is None else v[k]*1000 for k in rates})} for name,v in s['by_phase'].items()}
   total=price(s);subtotal=sum(Decimal(v['once_observed_known_traffic']['known_traffic_USD']) for v in phases.values());assert subtotal==Decimal(total['known_traffic_USD'])
   once_peak=Decimal(s['r2_peak_bytes'])/Decimal(1_000_000_000)*Decimal('0.015')
   fixed_cost=Decimal(price(fixed)['known_traffic_USD'])*1000+once_peak
   if sample>=0:
    score=json.loads((ROOT/'offline'/f'{provider}-score.json').read_text());trial=next(v for v in score['profiles'][profile]['trials'] if v['sample']==sample)
    assert math.isclose(float(fixed_cost),trial['known_monthly_fixed_workload_usd'],abs_tol=1e-12)
   out.append({'profile':profile,'provider':provider,'sample':sample,'warmup':sample<0,'warmup_excluded_from_fixed_objective':sample<0,'all_actual_phases':phases,'all_observed_known_traffic_once':total,'fixed_32push_56fetch_actual':fixed,'fixed_traffic_once':price(fixed),'fixed_1000_replay_plus_actual_peak_once30d_known_USD':str(fixed_cost),'actual_R2_peak_bytes':s['r2_peak_bytes'],'R2_peak_once30d_known_USD':str(once_peak),'R2_storage_scope':'Actual peak retained once per repository30d, never multiplied by1000 traffic repeats or added again for each phase.','actual_startup_separately_known_traffic_once':phases.get('startup'),'actual_observer_separately_known_traffic_once':phases.get('stats'),'unknown_dimensions':['Worker CPU','DO duration','monthly SQLite storage','Native compute'],'full_bill_USD':None})
result={'run_id':39145424189,'trials':out,'frozen_rate_date':'2026-10-17','linear_resource_rates_USD_per_count':{k:str(v) for k,v in rates.items()},'zero_price_scope':'Actual deletes and R2 transfer/read/write bytes remain measured. Frozen R2 deletion/transfer tariffs add no per-byte charge here; class requests and single actual storage peak are charged separately. No vanished attempt or missing receipt is zero-filled.','scope':'Independent Decimal arithmetic proof of complete receipts for all24 trials including8 warmups. No new benchmark or suite score; Rust evaluator alone produces and compares scores. Startup and observer known traffic are explicitly retained separately, not treated as free. Unknown compute/duration/monthlySQLite/fullbill stay NULL.'}
(ROOT/'separate-startup-observer-warmup-traffic-pricing.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_trial_phase_prices':len(out),'warmups_separately_retained':sum(v['warmup'] for v in out),'fixed_scores_reconciled':sum(not v['warmup'] for v in out)}))
