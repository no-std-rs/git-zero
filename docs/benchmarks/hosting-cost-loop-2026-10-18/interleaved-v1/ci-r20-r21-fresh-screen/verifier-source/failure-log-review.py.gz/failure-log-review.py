"""Audit bounded exported stderr only; never starts services or benchmarks."""
import hashlib,json,re
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189')
records=[]
for manifest in sorted((ROOT/'profiles').rglob('*.failure-logs/manifest.json')):
 data=json.loads(manifest.read_text());assert data['version']==1
 assert data['per_file_budget_bytes']==65536 and data['total_log_budget_bytes']==524288
 assert manifest.stat().st_size<=524288
 total=0;entries=[]
 for e in data['files']:
  keep=e['retained_path'];record={'manifest_entry':e,'independently_verified_retained_bytes_and_hash':False,'full_original_file_hash_independently_reproduced':False}
  if keep is not None:
   assert Path(keep).name==keep and keep.endswith('.host.log')
   p=manifest.parent/keep;actual=p.read_bytes();assert len(actual)==e['retained_bytes']<=65536
   assert hashlib.sha256(actual).hexdigest()==e['retained_sha256']
   assert isinstance(e['original_bytes'],int) and e['original_bytes']>=len(actual)
   assert re.fullmatch('[0-9a-f]{64}',e['original_sha256'])
   assert e['truncated']==(e['original_bytes']>len(actual))
   if not e['truncated']:
    assert e['original_bytes']==len(actual) and e['original_sha256']==e['retained_sha256']
    record['full_original_file_hash_independently_reproduced']=True
   total+=len(actual);record['independently_verified_retained_bytes_and_hash']=True
  else:
   assert e['missing_reason'] is not None
  entries.append(record)
 assert total==data['retained_log_bytes']<=524288
 records.append({'manifest':str(manifest.relative_to(ROOT)),'retained_total_bytes':total,'entries':entries,'limit':'Truncated or missing original bytes are unavailable, never treated as empty. Only complete retained logs permit independent full-original hash reproduction.'})
result={'run_id':39145424189,'attempt':1,'exported_failure_manifests':records,'exporter_source':json.loads((ROOT/'failure-only-runner-source-audit.json').read_text()),'absence_limit':'Exporter executes only on runner error. Absence on completed successful reports is expected and supplies no fault-injection sample.'}
(ROOT/'failure-log-export-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'failure_manifests':len(records),'retained_bytes':sum(r['retained_total_bytes'] for r in records)}))
