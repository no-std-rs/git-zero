"""Retain actual Fit-response activation and all counters; no modeled saving."""
import json,collections,math
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189')
events=['upload_response_retention_skips','upload_response_retention_admissions','upload_response_retention_allocation_failures']
trials=[];operations=[];checks=[]
def check(ok,why,where):checks.append({'passed':bool(ok),'check':why,**where})
for profile in ['16mib-cold','16mib-warm','64mib-cold','64mib-warm']:
 for p in ['r20','r21']:
  r=json.loads((ROOT/'profiles'/profile/p/f'{profile}.json').read_text())
  for sample in [-1,0,1]:
   where={'profile':profile,'provider':p,'sample':sample}
   rs=[v for v in r['raw'] if v['backend']=='cloudflare-local' and v['sample']==sample]
   final=next(v for v in r['cloudflare_runs'] if v['sample']==sample)['final_object_stats']
   available={k:k in final for k in events};sums={k:sum(v['service_metrics_delta'].get(k,0) for v in rs) for k in events}
   phase=collections.defaultdict(collections.Counter)
   if p=='r21':
    check(all(available.values()),'R21 actual Fit retention metrics exported',where)
    check(final.get('response_cache_admission')=='fit','R21 source default Fit appears in final actual metrics',where)
   for v in rs:
    op=v['operation'];md=v['service_metrics_delta'];ev={k:md.get(k,0) for k in events}
    phase[op['kind']].update(ev)
    if p=='r21':
     check(all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and 0<=x<=9007199254740991 and float(x).is_integer() for x in ev.values()),'Actual numeric event deltas are finite nonnegative exactly represented whole counts',where|{'operation':op['key']})
     check(ev[events[2]]<=ev[events[0]],'Actual reserve failures are counted skips',where|{'operation':op['key']})
     if profile.endswith('warm') or op['kind']=='push':check(all(x==0 for x in ev.values()),'Warm/push path has no Fit optional-upload insertion event',where|{'operation':op['key']})
    operations.append(where|{'warmup':sample<0,'operation':op,'actual_retention_delta':ev,'metrics_available':{k:k in md for k in events},'actual_cache_delta':{k:md.get(k) for k in ['cache_bytes','cache_entries','cache_evictions','cache_retained_bytes','protected_chunk_bytes','protected_chunk_owning_bytes','protected_chunk_entries','protected_chunk_pressure_evictions','joint_cache_retained_peak_bytes']},'actual_workload_receipt':v['cloudflare_workload_delta']})
   outside={k:final[k]-sums[k] if available[k] else None for k in events}
   if p=='r21':check(all(v==0 for v in outside.values()),'No observed Fit event outside timed ordinary rows',where)
   trials.append(where|{'warmup':sample<0,'actual_final_policy':final.get('response_cache_admission'),'metrics_available':available,'actual_timed_events':sums,'actual_by_operation_kind':{k:dict(v) for k,v in phase.items()},'actual_final_events':{k:final.get(k) for k in events},'actual_final_minus_timed_events':outside,'actual_final_cache_gauges':{k:final.get(k) for k in ['cache_bytes','cache_entries','cache_evictions','cache_retained_bytes','protected_chunk_bytes','protected_chunk_owning_bytes','protected_chunk_entries','joint_cache_entries','joint_cache_retained_peak_bytes']}})
result={'run_id':39145424189,'trials':trials,'operations':len(operations),'checks_inspected':len(checks),'diagnostic_failures':[c for c in checks if not c['passed']],'scope':'R20 missing Fit metric keys are explicitly unavailable, not invented zero. Event sums use absent per-operation keys only as serde numeric delta zero where appropriate. R21 Fit event presence/phase/closure is diagnosed, never used to discard a sample. Same-operation mandatory metadata/discovery pressure is possible, so a Fit skip does not prove zero total pressure for that operation. No retained-pool superset, per-key timeline, allocation-trace, no-later-callback, causal savings or full-bill claim.'}
(ROOT/'fit-response-activation-review.json').write_text(json.dumps(result,indent=2)+'\n')
(ROOT/'fit-response-every-operation-receipts.json').write_text(json.dumps(operations,indent=2)+'\n')
print(json.dumps({'fit_review_trials':len(trials),'operation_receipts':len(operations),'checks':len(checks),'diagnostic_failures':len(result['diagnostic_failures'])}))
