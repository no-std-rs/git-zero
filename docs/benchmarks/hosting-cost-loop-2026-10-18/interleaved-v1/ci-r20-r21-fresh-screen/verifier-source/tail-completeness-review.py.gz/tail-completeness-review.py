"""Reconstruct all 1408 pair ratios, 48 group maxima and 64 top-8 raw tails; preserve failed groups dynamically."""
import collections,csv,json,math
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189');PROVIDERS=['r20','r21'];PROFILES=['16mib-cold','16mib-warm','64mib-cold','64mib-warm']
actual=list(csv.DictReader((ROOT/'operation-row-ratios.tsv').open(),delimiter='\t'));selected=json.loads((ROOT/'retained-tail-summary.json').read_text())['tails'];guards=json.loads((ROOT/'guard-report.json').read_text());details=json.loads((ROOT/'latency-failure-pair-details.json').read_text());groups=collections.defaultdict(list);rows=[];top=[]
for p in PROVIDERS:
 for profile in PROFILES:
  report=json.loads((ROOT/'profiles'/profile/p/f'{profile}.json').read_text())
  profile_rows=[]
  for r in report['raw']:
   if r['backend']!='cloudflare-local' or r['warmup']:continue
   o=r['operation'];g=next(g for g in report['raw'] if g['backend']=='git' and g['sample']==r['sample'] and g.get('operation')==o)
   hm=r['ready_wall_ms'] if o['kind']=='push' else r['wall_ms'];gm=g['ready_wall_ms'] if o['kind']=='push' else g['wall_ms'];ratio=hm/gm
   matching=[v for v in actual if (v['provider'],v['profile'],int(v['sample']),v['operation'])==(p,profile,r['sample'],o['key'])];assert len(matching)==1
   v=matching[0];assert float(v['host_ready_or_fetch_ms'])==hm and float(v['paired_git_ready_or_fetch_ms'])==gm and float(v['host_to_git_ratio'])==ratio
   item={'provider':p,'profile':profile,'sample':r['sample'],'operation':o,'host_ms':hm,'paired_Git_ms':gm,'ratio':ratio,'actual_fixed_receipt':r['cloudflare_workload_delta'],'full_original_report':str((ROOT/'profiles'/profile/p/f'{profile}.json').relative_to(ROOT))}
   rows.append(item);profile_rows.append(item);groups[(p,profile,o['group'])].append(item)
  top8=sorted(profile_rows,key=lambda x:x['host_ms'],reverse=True)[:8];existing=[x for x in selected if x['provider']==p and x['profile']==profile];assert len(existing)==8
  assert [(x['sample'],x['operation'],x['host_ms'],x['paired_Git_ms'],x['ratio']) for x in top8]==[(x['sample'],x['operation'],x['ready_wall_ms'] if x['operation']['kind']=='push' else x['wall_ms'],x['paired_git_ready_or_fetch_ms'],x['paired_host_to_git_ratio']) for x in existing]
  top.extend(top8)
maxima=[]
for (p,profile,g),rs in groups.items():maxima.append({'provider':p,'profile':profile,'group':g,'measured_operation_count':len(rs),'maximum_host_latency':max(rs,key=lambda r:r['host_ms']),'maximum_Git_latency':max(rs,key=lambda r:r['paired_Git_ms']),'maximum_individual_ratio':max(rs,key=lambda r:r['ratio'])})
failed=[(c['name'],c['baseline'],c['candidate'],r['profile'],r['workload']) for c in guards['comparisons'] for r in c['failed_latency_guards']]
assert len(failed)==len(details)
for name,bp,cp,profile,group in failed:
 ds=[d for d in details if (d['comparison'],d['profile'],d['group'])==(name,profile,group)];assert len(ds)==1
 want=[r for r in rows if r['provider'] in [bp,cp] and r['profile']==profile and r['operation']['group']==group]
 got=ds[0]['all_baseline_and_candidate_pairs'];assert len(want)==len(got)
 assert {(r['provider'],r['sample'],r['operation']['key'],r['host_ms'],r['paired_Git_ms'],r['ratio']) for r in want}=={(r['provider'],r['sample'],r['operation']['key'],r['host_ms'],r['git_ms'],r['ratio']) for r in got}
assert len(rows)==1408 and len(groups)==48 and len(top)==64
result={'run_id':39145424189,'all_individual_ratios_reconstructed':len(rows),'all_provider_profile_latency_group_maxima':len(maxima),'all_selected_top8_tails_reconstructed':len(top),'dynamic_failed_latency_groups':len(failed),'all_pairs_in_every_failed_group_retained':True,'all_original_raw_tails_and_warmups_retained':True,'global_largest_host_latency':max(rows,key=lambda r:r['host_ms']),'global_largest_individual_ratio':max(rows,key=lambda r:r['ratio']),'no_samples_discarded':True,'timing_is_CPU_or_speed_claim':False}
for n,data in [('tail-completeness-review.json',result),('all-48-latency-group-maxima.json',maxima),('reconstructed-64-published-top8-tails.json',top)]: (ROOT/n).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if not isinstance(v,dict)}))
