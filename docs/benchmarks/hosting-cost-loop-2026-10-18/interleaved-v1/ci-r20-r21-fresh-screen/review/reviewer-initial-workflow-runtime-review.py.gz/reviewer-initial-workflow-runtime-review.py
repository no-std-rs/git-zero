"""Frozen workflow syntax/source binding plus actual runtime/dependency provenance."""
import json,hashlib,subprocess,re
from pathlib import Path
import yaml
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r20-r21-screen/run-39145424189');SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
d=json.loads((ROOT/'prospective-source-identities.json').read_text())
p=SOURCE/'.github/workflows/hosting-isolated.yml';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==d['workflow_sha256'];y=yaml.safe_load(b)
env=y['env'];assert env['SCREEN_PROVIDERS']=='r20 r21' and env['BENCH_STAGE']=="${{ inputs.stage || 'screen' }}"
for label in ['r20','r21']:assert env['SCREEN_'+label.upper()+'_COMMIT']==d['sources'][label]['commit']
assert env['REFERENCE_COMMIT']==env['BASELINE_COMMIT']==d['baseline_reference']
assert env['EXPECTED_WORKER_SOURCE_TREE']==d['sources']['r21']['WorkerSRC']
assert env['EXPECTED_WORKER_SHA256']==d['sources']['r21']['modules']['examples/repository-host/cloudflare/src/index.js']
prior=subprocess.check_output(['git','-C',str(SOURCE),'show','d5cdefe53fc24f34114292b7d19563e73afea293:.github/workflows/hosting-isolated.yml'])
old=yaml.safe_load(prior);assert old['jobs']==y['jobs'];shells=[]
for job,v in y['jobs'].items():
 for i,s in enumerate(v['steps']):
  if 'run' in s:
   # GitHub interpolates matrix literals and env statements before bash.
   code=re.sub(r'\$\{\{[^}]+\}\}','16',s['run'])
   subprocess.run(['bash','-n'],input=code.encode(),check=True)
   shells.append({'job':job,'step':i,'name':s.get('name'),'source_SHA256':hashlib.sha256(s['run'].encode()).hexdigest(),'bash_n_passed':True})
assert len(shells)==8
runtime=[]
for profile in ['16mib-cold','16mib-warm','64mib-cold','64mib-warm']:
 prov=ROOT/'profiles'/profile/'provenance'
 if not prov.exists():continue
 raw=(prov/'runtime.txt').read_text();lines=raw.splitlines()
 tools={k:[v for v in lines if v.startswith(prefix)] for k,prefix in [('rustc','rustc '),('cargo','cargo '),('rustc_release','release: '),('rustc_commit','commit-hash: '),('rustc_host','host: '),('LLVM','LLVM version: ')]}
 assert all(len(v)==1 for v in tools.values()),tools
 tools['version_only_lines']=[s for s in lines if re.fullmatch(r'v?\d+\.\d+\.\d+(?:[^ ]*)?',s)]
 for k in ['worker_cpu','do_duration','sqlite_monthly_storage','native_compute']:assert k+'=unknown' in lines
 assert all(v in lines for v in ['GIT_CONFIG_COUNT=0','GIT_CONFIG_NOSYSTEM=1','GIT_CONFIG_GLOBAL=/dev/null'])
 deps=json.loads((prov/'npm-dependencies.json').read_text());assert not deps.get('problems'),deps.get('problems')
 runtime.append({'profile':profile,'toolchain_lines':tools,'runtime_file_SHA256':hashlib.sha256((prov/'runtime.txt').read_bytes()).hexdigest(),'actual_workerd_binary_provenance':(prov/'workerd.txt').read_text(),'dependency_tree_SHA256':hashlib.sha256((prov/'npm-dependencies.json').read_bytes()).hexdigest(),'complete_dependency_tree':deps})
if len(runtime)==4:
 assert all(v['toolchain_lines']==runtime[0]['toolchain_lines'] for v in runtime)
 assert len({v['dependency_tree_SHA256'] for v in runtime})==1
out={'run_id':39145424189,'attempt':1,'head':d['head'],'workflow_SHA256':hashlib.sha256(b).hexdigest(),'all_job_bodies_identical_to_previous_reviewed_run':True,'all_eight_shell_blocks_syntax_pass':shells,'profiles':runtime,'scope':'Read-only workflow validation and frozen premeasurement runtime snapshots; four actual fresh VM receipts. No source edit, build, service, new run, deployment or historical binary identity constraint.'}
(ROOT/'workflow-toolchain-and-dependencies-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'workflow_SHA256':out['workflow_SHA256'],'unchanged_job_bodies':True,'shell_blocks':len(shells),'actual_profiles':len(runtime)}))
