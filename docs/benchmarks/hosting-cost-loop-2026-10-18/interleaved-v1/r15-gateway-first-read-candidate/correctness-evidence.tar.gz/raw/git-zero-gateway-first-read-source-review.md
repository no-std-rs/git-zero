# R15 gateway first read: independent source preparation review

Disposition: **STOP READY, awaiting corrected clean code SHA and actual final controls. No final approval or measured cost/speed claim.** Read-only source inspection in `/tmp/git-zero-hosting-gateway-first-read`, based on independently reviewed R14 commit `5759726b0a4545f6613553e1f2303f303eb65384`. The candidate was uncommitted and deliberately frozen for an actual immediate-retirement gate during this inspection. No edit to candidate/source, runtime, build, probe, CI action or benchmark was performed. Only this standalone review was written.

## Exact inspected source snapshot

SHA-256 recorded during inspection (these identify the audited intermediate files, not a future commit):

| File | SHA-256 |
| --- | --- |
| cloudflare/src/index.js | ba8343a608ac3455a459352ce46c16601036906e949c394c371d0ce61b5fc82c |
| cloudflare/src/first-read.js | 0a30a75c9a5519f24760f52311873d24f2c650d48d6f85e6d6ab1b4fd5126141 |
| src/first_read.rs | 2594c195ba14240a0a1407afc8b412432a7a46790bbeb1bc66ea429cae6f7dda |
| src/cloudflare.rs | 17b02c044ddf2e51d0fbc58bdadeaae0aa163a024cbb3f1816a21e831d454ea8 |
| src/native.rs | 702dba825782ef3aef91a633f12d24b27de4a1c6b489273d9fb35483667e3295 |
| src/native/history.rs | b30f3432e3d6b09d872fd0d10271c90b9398d75a335bb1a1775a1c7449e66d93 |
| src/lib.rs | e6a3db9353ee0ed6505bd8abd7adf74eee87330d55a4823578df9aa871c8071b |
| src/bin/repository-host.rs | d432cb6cf0a8d8ae4e00e9516248f4f020e00f13146c1e3955b0020514a06f1f |
| tests/first_read_cloudflare.rs | ff2c3e270f2dbd2f8ebdff6e99c5eebfdd1f256440558631e9a535ec73d5cce6 |
| cloudflare/test/first-read-worker.js | 0be7d5e17cd0faab3f4f291b72bf2ba4516f2ae4effbfc7506838856615615e8 |

Paths in the table are relative to `examples/repository-host/`. Source may move after the current gate stops, so these hashes must not be presented as approval of any later source.

## Proven blocker in this snapshot

**Registration can acknowledge a Worker-enabled capability while silently leaving Native unable to serve it.** `Key::from_registration` returns `Option<Key>` and `HttpServices::register` installs that option without distinguishing a genuinely absent legacy capability from a present invalid capability. Bad version/body/frame limits, malformed key/session, missing fields or missing usable generation-witness dependency therefore silently become `None`, even though the registering Worker can already have enabled first-read routing. Eligible fetches then reach private planning and fail instead of rejecting registration. The parser also does not reject unknown capability fields. This is the previously identified issue, independently confirmed in source; the implementer/root already plan the correction.

Required correction: absent capability retains legacy behavior; present malformed/unsolicited/incompatible capability returns `InvalidData`; strict exact fields/limits/key/session/dependencies; validate before installing any session capability; registration failure retains the existing reset-before-I/O behavior for first-read, generation witness and retirement/upload proofs. Duplicate-field rejection needs to happen before a generic JSON Value has discarded duplicates. Preserve old witness semantics when first-read is absent. Worker currently creates the two private sessions independently: atomic valid pairing is required; literal session equality is appropriate only if Worker is deliberately changed to share one session.

No additional proven blocker was found in this bounded inspection. This is not a claim that unfinished fault gates passed.

## Source conclusions to preserve in the correction

- The new topology is the reviewed one: a signed stateless Native preflight, direct internal `dispatchService` to one DO authority/read callback, then signed Native continuation. Neither preflight nor first batch issues a second external service Worker callback. Later batches use ordinary services. No request/session/blob stash or held Native lock was introduced.
- Private request/response/continuation HMAC domains are distinct; the entire continuation frame is authenticated. Public repository routing cannot target private endpoints, and existing private header stripping removes public spoofed authenticators. Session/repository/nonce, exact logical body/target/headers and signed ordered chunk selection are bound. Stateless nonces are not replay protection against someone holding the trusted registration key.
- Native planning uses the same history parser, descriptor validation, selected pack order and `bulk_batch_len` as ordinary reads. The repository consumes an owning verified exact first prefix once and reads only the suffix; all selected bytes remain verified before native files are installed. No new suffix/history closure claim is made.
- DO validates complete first-batch count/key/length/payload limits before binding I/O, reads authority under the existing service gate, checks generation and full manifest fingerprint before any GET, and reuses actual ordered read accounting. Generation mismatch has zero GETs. Same-generation fingerprint mismatch errors rather than accepting unproven bytes.
- Gateway accepts the actual required DO receipt once through the existing validator, strips its transport header and never asks Native to echo it. Error/missing receipt/body failure paths retain existing incomplete-accounting rules. Invalid/corrupt/truncated paid bytes do not silently cause a duplicate first-batch read. Genuine state/cache changes can discard authenticated verified paid bytes and use ordinary dispatch, retaining prior cost.
- Full manifest digest includes generation, ordered full pack descriptors/chunks, UTF-8-byte-ordered refs and ordered garbage. The root-confirmed same-generation retirement bug was correctly addressed structurally by `AuthorityFingerprint { generation, published, local }`: invalidate before publication I/O; preserve the full published next digest; install the local post-cleanup digest only after publication success; refresh from exactly loaded recovery state; require current local digest/generation when planning. Garbage is not silently excluded. The actual corrected driver log ended PASS in 25.67 seconds; this reviewer did not run it or yet independently reconcile all its artifacts/source ledger.
- Cache normalization excludes only the named framing/connection/transport fields. In this implementation Git CGI only receives content type, Git protocol and content encoding; excluded accept-encoding/host/connection/Cloudflare transport headers are not forwarded as Git behavior. Authorization, cookies, content type/encoding, Git protocol, Accept, user agent and arbitrary custom headers remain in request identity/cache keys. Normal HTTP framing/parser validation was not removed. Regression evidence still needs to cover ordinary versus reconstructed keys with real requests.
- New fixed key/flag and the entire owning `Option<AuthorityFingerprint>` are charged in the joint Native metadata budget. Framing stays under the existing 64 MiB incoming limit; original request is bounded to 128 KiB, metadata to 1.5 MB, first payload to 16 MiB with the existing framing overhead and 256 keys. No retained first-batch cache was added. The unknown native HTTP/CPU cost is not zero.

## Gates required before focused final approval

1. Exact clean source commit, complete changed/untracked source and driver provenance, source-identified actual final registration strictness controls (absent versus invalid, unknown/duplicate fields, disabled/unsolicited capability, dependencies, failed re-registration/unregister/reset), fmt/Clippy and meaningful existing correctness checks.
2. Same-binary deterministic actual on/off production Worker controls, with negotiation disabled before the initial off handshake, proving fewer Worker and DO callbacks with identical ordered GET keys/bytes, authoritative manifest/refs, storage/no writes and strict fsck/archive. Require both one-batch and multi-batch/full/prefix reads and unchanged warm/discovery/receive behavior. No old-trace hypothetical saving can substitute for these receipts.
3. Actual final-source interleavings: plan then publication before DO (zero prefetch GET), paid DO then successful local publication before continuation (discard paid bytes), exact post-retirement immediate fetch, partial/ambiguous publication and recovery, changed cache/view/lineage, registry replace/unregister/reopen. All service work and discarded bytes must remain counted.
4. Actual final-source wrong/spoofed private routes/auth/domain/body/target/repo/session/selection, duplicate/unknown schema and malformed/oversized frames, Unicode canonical cross-language fingerprint, exact batch/body boundaries, missing/failing/corrupt/truncated GET, unknown SQL/missing receipt/dropped continuation; no hidden retry or observer repair. Nested chunk strictness must be considered too: ordinary storage Chunk deserialization allows unknown fields, while the gateway first-batch validator is exact.
5. Artifact ledger must distinguish intermediate failures/corrections and final controls, hash all referenced raw artifacts and source, and leave native compute, Worker CPU, DO duration and the complete bill UNKNOWN. This source review grants no screen acceptance, cost floor, production deployment or speed claim. Fresh screen and mandatory original-R1/final five-pair validation remain the root task.

Read/preparation review complete. STOP READY for exact corrected committed code and final evidence.
