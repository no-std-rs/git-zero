"""Retain and audit a failed fresh attempt without manufacturing scores or guards."""
import collections,csv,hashlib,json,math
from pathlib import Path
ROOT=Path(__file__).parent/'run-39104016332'
EXPECTED=json.loads((ROOT/'expected-source-identities.json').read_text())
PROVIDERS=list(EXPECTED['providers']);PROFILES=['16mib-cold','16mib-warm','64mib-cold','64mib-warm']
def save(n,v):(ROOT/n).write_text(json.dumps(v,indent=2)+'\n')
def pairs(path):return dict(line.split('=',1) for line in path.read_text().splitlines() if '=' in line)
def hashes(path):return {name:digest for digest,name in (line.split('  ',1) for line in path.read_text().splitlines())}
def counters(rows):
 if not rows:return {}
 return {k:None if v is None else sum(r['cloudflare_workload_delta'][k] for r in rows) for k,v in rows[0]['cloudflare_workload_delta'].items()}
def diff(a,b):
 return {k:None if v is None or b.get(k) is None else v-b.get(k,0) for k,v in a.items() if v is None or isinstance(v,(int,float))}
reports=[];failures=[];provenance=[];ratios=[];scopes=[];all_operations=[];partial_rows=[];tails=[];first_pushes=[];activation=[]
common=None;native={};raw_files=[]
for profile in PROFILES:
 d=ROOT/'profiles'/profile
 if not (d/'checksum-verification.txt').exists():continue
 prov=d/'provenance';runtime=pairs(prov/'runtime.txt')
 for k,v in {'candidate_commit':EXPECTED['head'],'run_id':'39104016332','run_attempt':'1','stage':'screen','profile':profile,'reference_commit':EXPECTED['reference_commit'],'worker_source_tree':EXPECTED['worker_source_tree']}.items():assert runtime[k]==v
 source=hashes(prov/'source-binary-sha256.txt');current=hashes(prov/'common-sha256.txt')
 if common is None:common=current
 assert current==common
 assert hashes(prov/'worker-source-sha256.txt')=={k:v['current_sha256'] for k,v in EXPECTED['sources'].items() if '/cloudflare/src/' in k}
 for k,v in EXPECTED['sources'].items():assert source[k]==v['current_sha256']
 assert (prov/'screen-native-source-trees.txt').read_text().splitlines()==[EXPECTED['providers'][p]['native_source_tree'] for p in PROVIDERS]
 assert [(p,r) for p,r,*_ in (line.split('\t') for line in (prov/'providers.tsv').read_text().splitlines())]==[(p,v['commit']) for p,v in EXPECTED['providers'].items()]
 status_after={p:(prov/f'{p}-source-status-after.txt').read_text() if (prov/f'{p}-source-status-after.txt').exists() else None for p in PROVIDERS}
 for p,v in EXPECTED['providers'].items():
  ident=pairs(prov/f'{p}-source.txt');assert ident['commit']==v['commit'] and ident['tree']==v['tree']
  sha=source[next(k for k in source if k.endswith(f'/bin/{p}/repository-host'))]
  assert native.setdefault(p,sha)==sha
 provenance.append({'profile':profile,'runtime':runtime,'fresh_complete_common_sha256':current,'worker_manifest':hashes(prov/'worker-source-sha256.txt'),'post_run_source_status_by_provider':status_after,'post_run_reference_source_status':(prov/'reference-source-status-after.txt').read_text() if (prov/'reference-source-status-after.txt').exists() else None,'post_run_cleanliness_limit':'Absent post-run records on failed jobs remain unknown; initial frozen source/binary records are verified but do not substitute for missing after checks.'})
 for p in PROVIDERS:
  directory=d/p
  if not directory.exists():continue
  regular=directory/f'{profile}.json';incomplete=list(directory.glob('*.incomplete.json'))
  for rawpath in ([regular] if regular.exists() else [])+incomplete:
   raw_files.append(rawpath);report=json.loads(rawpath.read_text());complete=report['complete'];raw=report['raw'];by=collections.Counter((r['backend'],r['sample']) for r in raw if 'operation' in r)
   reports.append({'provider':p,'profile':profile,'original_path':str(rawpath.relative_to(ROOT)),'original_file_SHA256':hashlib.sha256(rawpath.read_bytes()).hexdigest(),'complete':complete,'raw_rows':len(raw),'operation_rows_by_backend_sample':[{ 'backend':b,'sample':s,'rows':n} for (b,s),n in by.items()],'backend_fully_validated':complete,'progress_journal':report.get('journal'),'error':report.get('error'),'native_binary_SHA256':native[p]})
   if not complete:
    for f in report.get('failed_operations',[]):
     b=f.get('before',{});a=f.get('after',{});bs=b.get('cloudflare_services',{});ass=a.get('cloudflare_services',{})
     failures.append({'profile':profile,'provider':p,'raw_report':str(rawpath.relative_to(ROOT)),'failure':f,'actual_failure_window_service_counter_delta_including_observer':diff(ass,bs),'actual_failure_window_push_phase_counter_delta':diff(ass.get('by_phase',{}).get('push',{}),bs.get('by_phase',{}).get('push',{})),'manifest_generation_before_after':[bs.get('manifest_generation'),ass.get('manifest_generation')],'observed_DO_epoch_before_after':[bs.get('do_instance_epoch'),ass.get('do_instance_epoch')],'observability_limit':'Recorded HTTP failure is retained even if binding operation counters have zero failures. Snapshot inventory and native state are observations after failure, not an attributed root cause or a successful trial.'})
    for r in raw:partial_rows.append({'provider':p,'profile':profile,'incomplete_report':str(rawpath.relative_to(ROOT)),'raw':r})
    continue
   assert report['schema_version']==4 and report['config']['samples']==2
   assert report['config']['host_binary_sha256']==native[p]
   assert len(raw)==624
   for sample in [-1,0,1]:
    host=[r for r in raw if r['backend']=='cloudflare-local' and r['sample']==sample]
    git={r['operation']['key']:r for r in raw if r['backend']=='git' and r['sample']==sample and 'operation' in r}
    assert len(host)==len(git)==88
    assert sum(r['operation']['kind']=='push' for r in host)==32
    assert sum(r['operation']['kind']=='fetch' for r in host)==56
    assert all(r['backend_validation_complete'] for r in host+list(git.values()))
    run=next(v for v in report['cloudflare_runs'] if v['sample']==sample);final=run['final_object_stats'];s=final['cloudflare_services'];last=host[-1]['cloudflare_services_after']
    fixed=counters(host)
    events={k:sum(r['service_metrics_delta'].get(k,0) for r in host) for k in final if k.startswith('gateway_read_') or k in ['cloud_view_rehydrates','history_projections','history_full_restores','generation_witness_hits','generation_witness_fallbacks']}
    scopes.append({'provider':p,'profile':profile,'sample':sample,'warmup':sample<0,'fixed_32push_56fetch_receipt':fixed,'whole_trace_observer_excluded':run['estimated_service_costs']['observed_workload'],'startup_separate':s['by_phase']['startup'],'excluded_observer_usage':run['estimated_service_costs']['excluded_observer_usage'],'actual_final_observer_counter_delta':diff(s,last),'actual_final_observer_native_event_difference':{k:final[k]-v for k,v in events.items()},'actual_final_SQLite_bytes':s['do_sqlite_bytes'],'actual_final_R2_live_bytes':s['r2_live_bytes'],'actual_final_R2_peak_bytes':s['r2_peak_bytes'],'actual_final_native_inventory':final['objects'],'actual_final_manifest_debt':final['manifest'].get('garbage',[]),'actual_retired_chunk_deletes':final['retired_chunk_deletes'],'unknown_full_bill_usd':None})
    first_pushes.append({'provider':p,'profile':profile,'sample':sample,'warmup':sample<0,'first_timed_push_receipt':host[0]['cloudflare_workload_delta'],'startup_separate':s['by_phase']['startup'],'first_push_SQLite_before_after':[host[0]['cloudflare_services_before']['do_sqlite_bytes'],host[0]['cloudflare_services_after']['do_sqlite_bytes']],'all_push_SQL_written':sum(r['cloudflare_workload_delta']['do_rows_written'] for r in host if r['operation']['kind']=='push'),'actual_final_SQLite_bytes':s['do_sqlite_bytes']})
    activation.append({'provider':p,'profile':profile,'sample':sample,'warmup':sample<0,'actual_timed_native_events':events,'observed_DO_epoch_sequence':list(dict.fromkeys(r[f'cloudflare_services_{phase}']['do_instance_epoch'] for r in host for phase in ['before','after'])),'actual_final_DO_epoch':s['do_instance_epoch'],'activation_limit':'Counts describe completed reports in a failed attempt. They establish neither all-profile comparison nor permanence of proof validity.'})
    for r in host:
     op=r['operation'];delta=r['cloudflare_workload_delta'];before=r['cloudflare_services_before'];after=r['cloudflare_services_after']
     assert r['counter_integrity'] and before['accounting_complete'] and after['accounting_complete']
     assert before['accounting_errors']==after['accounting_errors']==[]
     assert all(v['failures']==0 for v in after['operations'].values())
     if op['kind']=='fetch':
      assert r['strict_fsck'] and r['archive_verified'] and r['client_received_pack_bytes']>0 and r['read_authority_unchanged']
      assert all(delta[k]==0 for k in ['r2_class_a','r2_deletes','r2_written_bytes','do_rows_written'])
      if profile.endswith('warm'):assert delta['r2_class_b']==delta['r2_read_bytes']==0
      if profile.endswith('cold') and op['group']=='latest_fetch':assert delta['r2_class_b']>0 and delta['r2_read_bytes']>0
     all_operations.append({'provider':p,'profile':profile,'sample':sample,'warmup':sample<0,'operation':op,'fixed_receipt':delta,'native_metrics':r['service_metrics_delta'],'cache_after':r.get('server_cache_after_fetch',r.get('server_cache_after_push'))})
     if sample>=0:
      g=git[op['key']];hms=r.get('ready_wall_ms',r['wall_ms']);gms=g.get('ready_wall_ms',g['wall_ms']);assert gms>0
      ratio={'provider':p,'profile':profile,'sample':sample,'operation':op['key'],'group':op['group'],'host_ready_or_fetch_ms':hms,'git_ready_or_fetch_ms':gms,'ratio':hms/gms};ratios.append(ratio)
      tails.append({**ratio,'host_raw_row':r,'Git_raw_row':g})
# Missing providers and reports remain absent. Never substitute another attempt.
save('failed-attempt-report-inventory.json',reports);save('failed-attempt-source-runtime-provenance.json',provenance)
save('failed-attempt-actual-failure-receipts.json',failures);save('failed-attempt-partial-operation-rows.json',partial_rows)
save('failed-attempt-complete-trial-counter-scopes.json',scopes);save('failed-attempt-first-push-SQL.json',first_pushes)
save('failed-attempt-native-activation-and-DO-epochs.json',activation);save('failed-attempt-every-complete-operation-receipt.json',all_operations)
save('failed-attempt-all-measured-operation-pairs.json',tails)
with (ROOT/'failed-attempt-all-measured-host-Git-ratios.tsv').open('w') as f:
 if ratios:
  w=csv.DictWriter(f,fieldnames=list(ratios[0]),delimiter='\t');w.writeheader();w.writerows(ratios)
review={'run':39104016332,'attempt':1,'head':EXPECTED['head'],'formal_result':'failed/incomplete and ineligible for comparison, provisional selection or plateau','complete_reports':sum(r['complete'] for r in reports),'incomplete_reports':sum(not r['complete'] for r in reports),'failed_operations_retained':len(failures),'actually_available_measured_host_Git_ratios':len(ratios),'expected_complete_matrix_ratios':len(PROFILES)*len(PROVIDERS)*2*88,'CI_scores_reproduced':0,'CI_comparisons_reproduced':0,'all_profile_guard_review_complete':False,'complete_three_score_three_comparison_reproduction':'Unavailable: failed profile prevents a matching provider matrix and CI score job. No earlier samples or scores are substituted.','full_bill_usd':None,'unknown_billing_dimensions':['Worker CPU','DO duration','monthly SQLite storage','native compute'],'mandatory_five_fresh_original_R1_final_all_four_profiles':'NOT DONE','no_speed_acceptance_or_stop_claim':True,'native_binary_SHA256_by_provider':native,'fresh_common_manifests_match_all_available_profiles':True}
save('FAILED_ATTEMPT_REVIEW.json',review)
(ROOT/'RAW_SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}\n' for p in sorted(raw_files)))
print(json.dumps(review))
