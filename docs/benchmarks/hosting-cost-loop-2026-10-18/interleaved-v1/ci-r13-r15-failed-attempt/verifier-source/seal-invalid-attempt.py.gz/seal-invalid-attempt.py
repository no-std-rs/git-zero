"""Seal exact fresh failed-attempt evidence; no benchmark, repair, trigger or scoring."""
import gzip,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
BASE=Path(__file__).parent;ROOT=BASE/'run-39104016332';PUB=ROOT/'publication'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(ROOT/n).write_text(json.dumps(v,indent=2)+'\n')
def pairs(p):return dict(x.split('=',1) for x in p.read_text().splitlines() if '=' in x)
def hashes(p):return {n:h for h,n in (x.split('  ',1) for x in p.read_text().splitlines())}
run=json.loads((ROOT/'run.json').read_text());jobs=json.loads((ROOT/'jobs.json').read_text())['jobs'];idx=json.loads((ROOT/'artifact-index.json').read_text())
assert run['id']==39104016332 and run['head_sha']=='82b64319bf9d39958c861b6fb7a9a6bae25fda9b' and run['run_attempt']==1
assert run['status']=='completed' and run['conclusion']=='failure'
assert len(jobs)==5 and next(j for j in jobs if j['name']=='score')['conclusion']=='skipped'
assert sorted(j['conclusion'] for j in jobs if j['name']!='score')==['failure','success','success','success']
assert idx['total_count']==4
frozen=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/evaluators/zero-get-fix/hosting-cost')
assert sha(frozen)=='01b36df2f5f2019eeb09ebe79eb8ae80e9f86d0cdf39667c9fec9b0584e61fb8'
assert subprocess.check_output(['git','-C','/tmp/git-zero-hosting-cost-loop','rev-parse','HEAD'],text=True).strip()==run['head_sha']
assert subprocess.check_output(['git','-C','/tmp/git-zero-hosting-cost-loop','status','--porcelain'],text=True)==''
artifacts=[];original_checks=0;boots=[];chronology=[];common=None
for a in idx['artifacts']:
 assert a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==run['head_sha'] and a['name'].endswith('-1')
 path=next((ROOT/'downloads'/a['name']).glob('*.tar.gz'));assert path.stat().st_size<=4194304
 profile=a['name'].removeprefix('hosting-screen-').removesuffix('-1');d=ROOT/'profiles'/profile
 for line in (d/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);p=(d/n).resolve();assert p.is_relative_to(d.resolve()) and sha(p)==h
  original_checks+=1
 assert not any(p.name=='host.log' for p in d.rglob('*') if p.is_file())
 runtime=pairs(d/'provenance/runtime.txt');boots.append(runtime['vm_boot_id']);cur=hashes(d/'provenance/common-sha256.txt')
 if common is None:common=cur
 assert common==cur
 steps=[];last_end=None
 for provider in ['r13','r14','r15']:
  sd=d/provider
  if not (sd/'start.txt').exists():steps.append({'provider':provider,'started':False});continue
  start=(sd/'start.txt').read_text().strip();end=(sd/'end.txt').read_text().strip();assert start<=end and (last_end is None or last_end<=start);last_end=end
  svc=pairs(sd/'service.txt');assert svc['vm_boot_id']==runtime['vm_boot_id']
  steps.append({'provider':provider,'started':True,'start':start,'end':end,'status':pairs(sd/'status.txt'),'Worker_PID':svc['worker_pid'],'state':svc['state'],'boot_id':svc['vm_boot_id']})
 chronology.append({'profile':profile,'actual_provider_order_and_status':steps,'vm_boot_id':runtime['vm_boot_id']})
 artifacts.append({'id':a['id'],'name':a['name'],'original_path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'SHA256':sha(path),'expires_at':a['expires_at'],'attempt':1,'run_id':run['id']})
assert len(set(boots))==4
assert sum(a['bytes'] for a in artifacts)==4086342 and sum(a['bytes'] for a in artifacts)<=20971520
save('archive-validation.json',{'original_archives':artifacts,'actual_archives':4,'expected_score_archive':'absent: score job skipped','total_original_archive_bytes':sum(a['bytes'] for a in artifacts),'per_archive_cap':4194304,'total_cap':20971520})
save('all-four-outcomes.json',{'run_id':run['id'],'attempt':1,'head':run['head_sha'],'conclusion':run['conclusion'],'score_job':'skipped','jobs':[{'name':j['name'],'conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at']} for j in jobs],'four_original_archives_saved':True,'all_fresh_common_hashes_match_across_four_profiles':True,'provider_chronology':chronology})
save('original-artifact-final-reverification.json',{'original_files_independently_rehashed_after_all_analysis':original_checks,'original_archives_independently_rehashed':4,'original_reports_mutated':False,'native_VM_host_log_uploaded':False})
review=json.loads((ROOT/'FAILED_ATTEMPT_REVIEW.json').read_text())
review.update({'all_four_jobs_terminal':True,'score_job':'skipped','source_runtime_VM_and_order_review':'All four fresh common manifests and all five Worker modules match; all three provider refs/native source trees/binaries are pinned. Three successful profile jobs include post-run clean-source checks. Failed warm64 does not have after-clean records, which remains unknown.','all_original_archives':artifacts,'original_internal_hashes_reverified':original_checks,'destroyed_VM_evidence_gap':'The old Rust runner left native host.log files in temporary fixture directories on the GitHub VM and did not export them. They are absent from all four original archives; the completed VM cannot be inspected or reconstructed by this audit.','outer_attempted_callback_billing':'Unknown. The retained ProxyWorker log reports one upload-retire attempt and Network connection lost. Before/after Worker/DO binding receipts show no corresponding dispatched upload or R2 PUT increment, but those snapshots do not prove that no unobserved or inflight callback work occurred. Scoped accounting_complete=true is not proof of complete failed HTTP-attempt billing.','no_unobserved_billing_zero_inference':True,'observer_and_epoch_limit':'Actual final full-inventory work is reconciled to excluded stats-phase receipts. Actual DO epoch changes and zero observed HEAD attempts describe these traces only; no permanent-proof, free-future-recovery or observer-repair saving is inferred.','frozen_Rust_evaluator_SHA256':sha(frozen),'Rust_evaluator_execution':'Not invoked for invalid/missing four-profile provider suites. No fake score or comparison exists.','root_primary_preserved_at_seal':{'head':run['head_sha'],'clean':True},'benchmark_services_probes_or_CI_mutations_by_auditor':False})
save('INDEPENDENT_REVIEW.json',review)
save('FAILED_ATTEMPT_REVIEW.json',review)
partial=json.loads((ROOT/'failed-attempt-partial-diagnostic-guards.json').read_text())
cache=json.loads((ROOT/'failed-attempt-available-joint-cache-review.json').read_text())
save('analysis.json',{'formal_status':'INVALID / INCOMPLETE ATTEMPT','suite_cost_and_all_profile_guards':'UNAVAILABLE','complete_reports':10,'incomplete_reports':1,'available_measured_ratios':1760,'declared_complete_matrix_ratios':2112,'diagnostic_resource_guards':partial['profile_resource_guards'],'diagnostic_resource_failures':partial['failed_resource_guards'],'diagnostic_latency_groups':partial['profile_latency_groups'],'diagnostic_latency_failed_groups':partial['failed_latency_groups'],'all_failed_latency_group_pairs_retained':True,'joint_retained_cache_peak_bytes':max(t['maximum_observed_joint_retained_bytes'] for t in cache['trials']),'native_host_log_gap':review['destroyed_VM_evidence_gap'],'failed_callback_billing_unknown':review['outer_attempted_callback_billing'],'full_bill_usd':None,'original_R1_final_five_pair_validation':'NOT DONE','selection_acceptance_speed_plateau_or_stopping_claim':False})
# Include exact executed analysis source, never downloaded binaries or extracted originals.
vs=ROOT/'verifier-source';vs.mkdir(exist_ok=True)
executed=['monitor-once.py','validate-completed-profiles.py','failed-attempt-review.py','failed-attempt-partial-guards.py','completed-profiles-r14-r15-activation-review.py','receipt-review-available.py','lifecycle-review-available.py','detailed-metrics-available.py','cache-joint-review-available.py','seal-invalid-attempt.py']
for n in executed:shutil.copyfile(BASE/n,vs/n)
(vs/'LOCATION.json').write_text(json.dumps({'executed_script_directory':str(BASE),'raw_evidence_root':str(ROOT),'scope':'Read-only GitHub artifact monitoring and offline hash/math/packaging only. No benchmark, service/probe, source change, push, trigger, cancellation or repair performed by this auditor.'},indent=2)+'\n')
PUB.mkdir(exist_ok=True);mapping=[]
def copy_payload(src,rel,compress):
 dst=PUB/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 if compress:
  with dst.open('wb') as f:
   with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:z.write(src.read_bytes())
  assert gzip.decompress(dst.read_bytes())==src.read_bytes()
 else:shutil.copyfile(src,dst)
 mapping.append({'published_path':rel,'source_path':str(src.relative_to(ROOT)),'source_exact_bytes':src.stat().st_size,'source_exact_SHA256':sha(src),'published_bytes':dst.stat().st_size,'published_SHA256':sha(dst),'encoding':'deterministic gzip of exact source bytes' if compress else 'original bytes'})
for a in artifacts:copy_payload(ROOT/a['original_path'],'original-archives/'+Path(a['original_path']).name,False)
for p in sorted(ROOT.iterdir()):
 if p.is_file() and (p.suffix in {'.json','.tsv'} or p.name=='RAW_SHA256SUMS'):
  copy_payload(p,'review/'+p.name+'.gz',True)
for p in sorted(vs.iterdir()):
 if p.is_file():copy_payload(p,'verifier-source/'+p.name+'.gz',True)
readme='''# R13–R15 screen: invalid attempt\n\nRun 39104016332, attempt 1, at `82b64319bf9d39958c861b6fb7a9a6bae25fda9b` failed. The 16 MiB cold/warm and 64 MiB cold jobs completed. R14 failed during the excluded 64 MiB warm warmup at push 13 with HTTP 503; its ProxyWorker upload-retire log reports “Network connection lost.” R15 never started on that profile. The score job was skipped.\n\nAll four original archives are preserved without alteration. Ten complete reports and one incomplete report retain every operation and failure receipt. The diagnostic tables contain all 1,760 available measured host/Git ratios, all available counter scopes, all 81 resource and 54 latency diagnostics, and every pair in the 13 failed latency groups. They cannot establish the missing four-profile comparison. No score, selection, acceptance, speed win, plateau or stopping claim is made. Full hosting cost remains unknown, and five fresh original-R1/final pairs on all four profiles remain not done.\n\nNative host.log files were not exported by the old runner and are unavailable from the destroyed VM. Actual outer attempted-callback billing remains unknown: zero observed binding deltas do not establish zero unobserved or inflight work. Observer inventory work is retained separately; observed DO epochs and HEAD counts do not prove permanent proof validity.\n\n`ARTIFACT_MAP.json` records every payload’s original path, exact uncompressed SHA256 and published SHA256. JSON/TSV/source files use deterministic gzip of their exact bytes. `SHA256SUMS` checks every published payload. Extracted originals are deliberately omitted; use the four original archives. No earlier attempt’s reports, samples, scores or comparisons were reused.\n'''
(PUB/'README.md').write_text(readme)
(PUB/'ARTIFACT_MAP.json').write_text(json.dumps(mapping,indent=2)+'\n')
payloads=sorted(p for p in PUB.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(PUB/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(PUB)}\n' for p in payloads))
for line in (PUB/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(PUB/n)==h
bundle=ROOT/'failed-attempt-evidence.tar.gz'
with bundle.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for p in sorted(p for p in PUB.rglob('*') if p.is_file()):
    info=tar.gettarinfo(str(p),arcname='failed-attempt-evidence/'+str(p.relative_to(PUB)));info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
    with p.open('rb') as stream:tar.addfile(info,stream)
assert bundle.stat().st_size<10*1024*1024
# Read the capsule back and check each exact archived byte against publication.
with tarfile.open(bundle) as tar:
 for member in tar.getmembers():
  rel=member.name.removeprefix('failed-attempt-evidence/');assert tar.extractfile(member).read()==(PUB/rel).read_bytes()
all_files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'SHA256SUMS')
(ROOT/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT)}\n' for p in all_files))
for line in (ROOT/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(ROOT/n)==h
print(json.dumps({'status':'SEALED INVALID ATTEMPT','capsule':str(bundle),'capsule_bytes':bundle.stat().st_size,'capsule_SHA256':sha(bundle),'publication':str(PUB),'publication_manifest_SHA256':sha(PUB/'SHA256SUMS'),'whole_evidence_manifest_SHA256':sha(ROOT/'SHA256SUMS'),'all_hashed_files_reverified':len(all_files),'original_internal_hashes_reverified':original_checks,'original_archive_bytes':sum(a['bytes'] for a in artifacts),'complete_reports':10,'incomplete_reports':1,'measured_ratios':1760,'no_all_profile_comparison_selection_or_plateau':True}))
