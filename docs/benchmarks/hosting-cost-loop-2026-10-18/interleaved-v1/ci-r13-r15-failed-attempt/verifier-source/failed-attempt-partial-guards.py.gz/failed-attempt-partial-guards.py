"""Diagnostic distributions/guards for available complete reports; never a suite score."""
import collections,json,math
from pathlib import Path
ROOT=Path(__file__).parent/'run-39104016332'
PROVIDERS=['r13','r14','r15'];PROFILES=['16mib-cold','16mib-warm','64mib-cold','64mib-warm']
def distribution(v):
 v=sorted(v);n=len(v);assert n
 return {'mean':sum(v)/n,'min':v[0],'max':v[-1],'median':(v[n//2-1]+v[n//2])/2 if n%2==0 else v[n//2],'p95':v[math.ceil(.95*n)-1]}
profiles={};comparisons=[];failure_details=[];deltas=[]
for profile in PROFILES:
 by={}
 for p in PROVIDERS:
  path=ROOT/'profiles'/profile/p/f'{profile}.json'
  if not path.exists():continue
  report=json.loads(path.read_text());assert report['complete']
  groups=collections.defaultdict(lambda:collections.defaultdict(list));resources=collections.defaultdict(list);pairs=[]
  for sample in [0,1]:
   rows=[r for r in report['raw'] if r['backend']=='cloudflare-local' and r['sample']==sample]
   git={r['operation']['key']:r for r in report['raw'] if r['backend']=='git' and r['sample']==sample and 'operation' in r}
   stats=next(r for r in report['cloudflare_runs'] if r['sample']==sample)['final_object_stats']['cloudflare_services']
   fixed={k:None if v is None else sum(r['cloudflare_workload_delta'][k] for r in rows) for k,v in rows[0]['cloudflare_workload_delta'].items()}
   fetches=[r for r in rows if r['operation']['kind']=='fetch'];read=sum(r['cloudflare_workload_delta']['r2_read_bytes'] for r in fetches);http=sum(r['http_response_body_bytes'] for r in fetches)
   for k,v in {'r2_peak_bytes':stats['r2_peak_bytes'],'r2_live_bytes':stats['r2_live_bytes'],'do_sqlite_bytes':stats['do_sqlite_bytes'],'fixed_r2_read_bytes':fixed['r2_read_bytes'],'fixed_r2_written_bytes':fixed['r2_written_bytes'],'varied_fetch_r2_read_bytes':read,'varied_fetch_http_response_bytes':http,'varied_fetch_client_pack_bytes':sum(r['client_received_pack_bytes'] for r in fetches),'varied_fetch_read_amplification':read/http}.items():resources[k].append(v)
   for r in rows:
    g=git[r['operation']['key']];host=r.get('ready_wall_ms',r['wall_ms']);ref=g.get('ready_wall_ms',g['wall_ms']);group=r['operation']['group']
    for k,v in {'host_ms':host,'git_ms':ref,'paired_host_to_git':host/ref}.items():groups[group][k].append(v)
    pairs.append({'provider':p,'sample':sample,'operation':r['operation'],'host_ms':host,'git_ms':ref,'ratio':host/ref,'host_raw_row':r,'Git_raw_row':g})
  by[p]={'resources':{k:distribution(v) for k,v in resources.items()},'latency':{g:{k:distribution(v) for k,v in m.items()} for g,m in groups.items()},'pairs':pairs}
 profiles[profile]={p:{k:v for k,v in x.items() if k!='pairs'} for p,x in by.items()}
 for later in range(1,len(PROVIDERS)):
  for earlier in range(later):
   bp,cp=PROVIDERS[earlier],PROVIDERS[later]
   if bp not in by or cp not in by:continue
   old,new=by[bp],by[cp];name=f'{cp}-vs-{bp}'
   resource=[{'resource':k,'baseline':v,'candidate':new['resources'][k],'passed':new['resources'][k]['mean']<=v['mean']*1.01+1e-12} for k,v in old['resources'].items()]
   latency=[]
   for group,ov in old['latency'].items():
    nv=new['latency'][group];median=nv['paired_host_to_git']['median']<=ov['paired_host_to_git']['median']*1.10;p95=nv['paired_host_to_git']['p95']<=ov['paired_host_to_git']['p95']*1.25
    guard={'group':group,'baseline':ov,'candidate':nv,'median_passed':median,'p95_passed':p95};latency.append(guard)
    if not (median and p95):failure_details.append({'comparison':name,'profile':profile,'diagnostic_guard':guard,'every_baseline_and_candidate_pair_in_group':[r for x in [old,new] for r in x['pairs'] if r['operation']['group']==group]})
   comparisons.append({'comparison':name,'profile':profile,'partial_diagnostic_only':True,'formal_all_four_profile_guard_status':'UNAVAILABLE','resources':resource,'latency':latency})
   for a,b in zip(old['pairs'],new['pairs']):
    assert a['sample']==b['sample'] and a['operation']==b['operation']
    av=a['host_raw_row']['cloudflare_workload_delta'];bv=b['host_raw_row']['cloudflare_workload_delta']
    deltas.append({'comparison':name,'profile':profile,'sample':a['sample'],'operation':a['operation'],'candidate_minus_baseline_actual_receipt':{k:None if v is None or av[k] is None else v-av[k] for k,v in bv.items()},'candidate_native_events':{k:v for k,v in b['host_raw_row']['service_metrics_delta'].items() if k.startswith('gateway_read_')}})
(ROOT/'failed-attempt-rebuilt-available-distributions.json').write_text(json.dumps(profiles,indent=2)+'\n')
(ROOT/'failed-attempt-partial-diagnostic-guards.json').write_text(json.dumps({'scope':'All available complete reports from this failed attempt only. Missing 64 MiB warm R14/R15 makes suite cost and guard conclusions unavailable. These observations cannot authorize provisional selection, acceptance, plateau or stopping.','comparisons':comparisons,'profile_resource_guards':sum(len(c['resources']) for c in comparisons),'profile_latency_groups':sum(len(c['latency']) for c in comparisons),'failed_resource_guards':sum(not r['passed'] for c in comparisons for r in c['resources']),'failed_latency_groups':sum(not (r['median_passed'] and r['p95_passed']) for c in comparisons for r in c['latency'])},indent=2)+'\n')
(ROOT/'failed-attempt-every-failed-diagnostic-workload-pair.json').write_text(json.dumps(failure_details,indent=2)+'\n')
(ROOT/'failed-attempt-every-available-comparison-operation-delta.json').write_text(json.dumps(deltas,indent=2)+'\n')
print(json.dumps({'available_complete_reports':sum(len(p) for p in profiles.values()),'available_profile_comparisons':len(comparisons),'retained_failed_workload_groups':len(failure_details),'all_four_profiles_comparable':False}))
