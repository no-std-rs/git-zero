"""Independent validation and derived counters; raw CI evidence is read only."""
import collections
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r18-r19-screen/run-39118509165')
EXPECTED = json.loads((ROOT / "expected-source-identities.json").read_text())
PROVIDERS = list(EXPECTED["providers"])
PROFILES = ["16mib-cold", "16mib-warm", "64mib-cold", "64mib-warm"]
OBJECTIVE = "interleaved-v1:16,64mib:cold,warm:32push,56fetch:1000repeats:peak30d:ready-latency:midx-bitmap-graph-v1:v2"

def pairs(path):
    return dict(line.split("=", 1) for line in path.read_text().splitlines() if "=" in line)

def hashes(path):
    return {name: digest for digest, name in (line.split("  ", 1) for line in path.read_text().splitlines())}

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n")

results, freshness, hardware, scopes, metrics, row_ratios = [], [], {}, [], [], []
common_hashes = None
common_runtime_hashes = None
common_workerd_provenance = None
native_hashes = {}
for profile in PROFILES:
    directory = ROOT / "profiles" / profile
    if not (directory / "checksum-verification.txt").exists():
        continue
    prov = directory / "provenance"
    assert not any("incomplete" in p.name or "journal" in p.name for p in directory.rglob("*") if p.is_file()), profile
    runtime = pairs(prov / "runtime.txt")
    for key, value in {"candidate_commit": EXPECTED["head"], "reference_commit": EXPECTED["reference_commit"], "reference_tree": EXPECTED["reference_tree"], "run_id": "39118509165", "run_attempt": "1", "stage": "screen", "profile": profile, "ref": "refs/heads/perf/hosting-isolated-ci-20261018"}.items():
        assert runtime[key] == value, (profile, key, runtime.get(key))
    assert runtime["worker_source_tree"] == EXPECTED["worker_source_tree"]
    worker_manifest = hashes(prov / "worker-source-sha256.txt")
    expected_modules = {k:v["current_sha256"] for k,v in EXPECTED["sources"].items() if k.startswith("examples/repository-host/cloudflare/src/")}
    assert len(expected_modules) == 6
    assert worker_manifest == expected_modules, (profile, worker_manifest)
    assert runtime["candidate_tree"] == EXPECTED["head_tree"]
    assert runtime["candidate_parent"] == EXPECTED["head_parent"]
    assert runtime["remote_branch_head"].split()[0] == EXPECTED["head"]
    assert runtime["image_os"] == "ubuntu24"
    assert runtime["runner_os"] == "Linux" and runtime["runner_arch"] == "X64"
    assert "git version 2.53.0" in (prov / "runtime.txt").read_text()
    provider_rows = [line.split("\t") for line in (prov / "providers.tsv").read_text().splitlines()]
    assert [(p, ref) for p, ref, *_ in provider_rows] == [(p, EXPECTED["providers"][p]["commit"]) for p in PROVIDERS]
    source_hashes = hashes(prov / "source-binary-sha256.txt")
    runtime_hashes = {k:v for k,v in source_hashes.items() if any(k.endswith(suffix) for suffix in ["/bin/git","/git-http-backend","/git-remote-http","/bin/node","/usr/bin/time"])}
    assert len(runtime_hashes) == 5
    if common_runtime_hashes is None:
        common_runtime_hashes = runtime_hashes
    assert common_runtime_hashes == runtime_hashes
    for path, identity in EXPECTED["sources"].items():
        assert source_hashes[path] == identity["current_sha256"], (profile, path)
    common = hashes(prov / "common-sha256.txt")
    if common_hashes is None:
        common_hashes = common
    assert common == common_hashes, profile
    assert all(common[path] == digest for path,digest in expected_modules.items())
    assert (prov / "reference-source-status-after.txt").read_text() == ""
    reference_source = str(Path(runtime["reference_workspace_manifest"]).parent)
    for rel,digest in EXPECTED["reference_manifest_sha256"].items():
        assert source_hashes[reference_source+"/"+rel] == digest
    assert (prov / "git-source-commit.txt").read_text().strip() == "67ad42147a7acc2af6074753ebd03d904476118f"
    assert (prov / "workerd.txt").stat().st_size > 0
    workerd_provenance = (prov / "workerd.txt").read_text()
    if common_workerd_provenance is None:
        common_workerd_provenance = workerd_provenance
    assert common_workerd_provenance == workerd_provenance
    trees = (prov / "screen-native-source-trees.txt").read_text().splitlines()
    assert trees == [EXPECTED["providers"][p]["native_source_tree"] for p in PROVIDERS]
    assert len(set(trees)) == len(PROVIDERS)
    report_ids, states, pids, provider_results, schedule_sha = [], [], [], [], None
    profile_machine = None
    cpu_fields = {r["field"].rstrip(":"):r["data"] for r in json.loads((prov / "cpu.json").read_text())["lscpu"]}
    for p, ref, source, target in provider_rows:
        identity = pairs(prov / f"{p}-source.txt")
        assert identity["label"] == p and identity["commit"] == ref
        assert identity["tree"] == EXPECTED["providers"][p]["tree"]
        assert identity["source"] == source and identity["target"] == target
        for rel,digest in EXPECTED["providers"][p]["manifest_sha256"].items():
            assert source_hashes[source+"/"+rel] == digest
        assert (prov / f"{p}-source-status-after.txt").read_text() == ""
        assert pairs(directory / p / "status.txt") == {"benchmark_exit": "0"}
        health = json.loads((directory / p / "health.json").read_text())
        assert health == {"ready": True, "runtime": "workerd", "local_only": True}
        service = pairs(directory / p / "service.txt")
        for key in ["run_id", "run_attempt", "vm_boot_id"]:
            assert service[key] == runtime[key], (profile, p, key)
        assert service["state"].endswith(f"/state-{p}")
        states.append(service["state"]); pids.append(service["worker_pid"])
        raw_path = directory / p / f"{profile}.json"
        report = json.loads(raw_path.read_text())
        assert report["complete"] is True and report["schema_version"] == 4
        machine = {k:v for k,v in report["machine"].items() if k != "contention_at_report"}
        if profile_machine is None:
            profile_machine = machine
        assert machine == profile_machine
        assert machine["logical_cpus"] == int(cpu_fields["CPU(s)"]) == 4
        assert machine["cpu"] == cpu_fields["Model name"]
        assert machine["memory"] == (prov / "memory.txt").read_text().splitlines()[0]
        assert machine["git"] == "git version 2.53.0"
        config = report["config"]
        assert config["flow"] == "interleaved-v1" and config["stage"] == "screen"
        assert config["debug_assertions"] is False
        assert config["order"] == "AB BA alternating paired samples; fresh repositories each run"
        assert config["samples"] == 2 and config["warmups_per_backend"] == 1
        assert config["push_generations_per_run"] == 32 and config["random_fetches_per_run"] == 56
        assert config["objective_identity"] == OBJECTIVE
        assert config["reference_push_maintenance"] == "midx-bitmap-graph-v1"
        assert config["fetch_unpack_limit"] == 1
        assert config["response_cache_max_response_bytes"] == 16777216
        assert config["fixture_mib"] == int(profile.split("mib-")[0])
        cf = config["cloudflare_local"]
        assert cf["view_cache"] == profile.split("-")[1]
        assert cf["monthly_workload_repetitions"] == 1000
        assert cf["repository_prefix"] == f"ci-{p}-{profile}"
        assert cf["endpoint"] == "http://127.0.0.1:8808"
        worker_sha = EXPECTED["sources"]["examples/repository-host/cloudflare/src/index.js"]["current_sha256"]
        assert cf["worker_source"]["sha256"] == worker_sha
        native_sha = source_hashes[next(k for k in source_hashes if k.endswith(f"/bin/{p}/repository-host"))]
        assert config["host_binary_sha256"] == native_sha
        assert native_hashes.setdefault(p, native_sha) == native_sha
        reference_sha = common[next(k for k in common if k.endswith("/bin/common/reference-host"))]
        assert config["reference_binary_sha256"] == reference_sha
        for binary in ["hosting-bench", "hosting-cost"]:
            assert source_hashes[next(k for k in source_hashes if k.endswith(f"/bin/{p}/{binary}"))] == common[next(k for k in common if k.endswith(f"/bin/common/{binary}"))]
        report_ids.append(cf["run_id"])
        fixture = report["fixture"]
        assert fixture["objective_identity"] == OBJECTIVE
        assert len(fixture["generations"]) == 32 and len(fixture["schedule"]) == 88
        assert sum(g["large_push"] for g in fixture["generations"]) == 8
        if schedule_sha is None:
            schedule_sha = fixture["schedule_sha256"]
        assert schedule_sha == fixture["schedule_sha256"]
        expected_ops = {o["key"]: o for o in fixture["schedule"]}
        generations = {g["tip"]: g for g in fixture["generations"]}
        raw = report["raw"]
        assert len(raw) == 624
        assert len(report["cloudflare_runs"]) == 3
        for sample in [-1, 0, 1]:
            blocks = []
            for row in raw:
                if row["sample"] == sample and "operation" in row and (not blocks or blocks[-1] != row["backend"]):
                    blocks.append(row["backend"])
            assert blocks == (["git","cloudflare-local"] if sample == 1 else ["cloudflare-local","git"])
            by_backend = {}
            for backend in ["cloudflare-local", "git"]:
                rows = [r for r in raw if r["backend"] == backend and r["sample"] == sample and "operation" in r]
                assert len(rows) == 88
                assert len({r["operation"]["key"] for r in rows}) == 88
                assert sum(r["operation"]["kind"] == "push" for r in rows) == 32
                assert sum(r["operation"]["kind"] == "fetch" for r in rows) == 56
                by_backend[backend] = {r["operation"]["key"]: r for r in rows}
                for row in rows:
                    op = row["operation"]
                    assert op == expected_ops[op["key"]]
                    assert row["warmup"] == (sample == -1)
                    assert row["backend_validation_complete"] is True
                    if op["kind"] == "push":
                        assert abs(row["ready_wall_ms"] - row["wall_ms"] - row["maintenance_wall_ms"]) < 1e-8
                        if backend == "git" and op["generation"] == 1:
                            assert row["reference_effective_config"] == config["reference"]
                    if op["kind"] == "fetch":
                        assert row["strict_fsck"] is True and row["archive_verified"] is True
                        assert row["verified_want"] == op["want"]
                        assert row["verified_tree"] == generations[op["want"]]["tree"]
                        assert row["client_received_pack_bytes"] > 0
                    if backend == "cloudflare-local":
                        assert row["counter_integrity"] is True
                        if op["kind"] == "fetch":
                            assert row["read_authority_unchanged"] is True
                        expected_namespace = f"ci-{p}-{profile}-{cf['run_id']}-{'warmup' if sample == -1 else sample}"
                        assert row["cloudflare_repo"] == expected_namespace
                        for phase in ["cloudflare_services_before", "cloudflare_services_after"]:
                            receipt = row[phase]
                            assert receipt["accounting_complete"] is True and receipt["accounting_errors"] == []
                            assert all(x["failures"] == 0 for x in receipt["operations"].values())
                            assert receipt["repository"] == expected_namespace and receipt["local_only"] is True
                        if op["kind"] == "push":
                            cache = row["server_cache_after_push"]
                            assert cache["entries"] == 0 and cache["resident_bytes"] == 0
                            assert row["manifest_generation_before"] == op["generation"] - 1
                            if op["generation"] == 1:
                                assert all(row["cloudflare_services_before"][k] == 0 for k in ["manifest_generation","r2_live_objects","r2_live_bytes","r2_peak_bytes"])
                            assert row["manifest_generation_after"] == op["generation"]
                        else:
                            assert row["manifest_generation"] == op["generation"]
                            delta = row["cloudflare_workload_delta"]
                            assert all(delta[k] == 0 for k in ["r2_class_a", "r2_deletes", "r2_written_bytes", "do_rows_written"])
                            cache = row["server_cache_after_fetch"]
                            if cf["view_cache"] == "cold" and op["group"] == "latest_fetch":
                                assert delta["r2_class_b"] > 0 and delta["r2_read_bytes"] > 0
                                assert row["service_metrics_delta"]["cloudflare_services"]["operations"]["r2_get"]["attempts"] > 0
                        assert cache["budget_bytes"] == 33554432 and cache["entry_limit"] == 256
                        assert cache["entries"] <= 256 and cache["resident_bytes"] <= 33554432
            maintenance = [r for r in raw if r["backend"] == "git" and r["sample"] == sample and "operation" not in r]
            assert len(maintenance) == 32
            if sample >= 0:
                cf_rows = list(by_backend["cloudflare-local"].values())
                fixed = {k: (None if value is None else sum(row["cloudflare_workload_delta"][k] for row in cf_rows)) for k, value in cf_rows[0]["cloudflare_workload_delta"].items()}
                run = next(r for r in report["cloudflare_runs"] if r["sample"] == sample)
                cost = run["estimated_service_costs"]
                assert cost["observed_binding_failures"] == 0
                for scenario in ["unused_allowances_new_paid_account", "exhausted_allowances_existing_paid_account"]:
                    assert cost[scenario]["total_estimate_usd"] is None
                inv = {k:cost[k] for k in ["r2_current_objects", "r2_current_bytes", "r2_observed_peak_bytes"]}
                outside_fixed = {k:None if v is None else cost["observed_workload"][k]-v for k,v in fixed.items()}
                startup = run["final_object_stats"]["cloudflare_services"]["by_phase"]["startup"]
                assert all(v == startup.get(k,0) for k,v in outside_fixed.items() if v is not None)
                scopes.append({"profile":profile,"provider":p,"sample":sample,"fixed_workload":fixed,"whole_trace_observer_excluded":cost["observed_workload"],"startup_only_outside_fixed":outside_fixed,"actual_startup_phase_counters":startup,"inventory":inv})
                stats = run["final_object_stats"]
                assert stats["objects"]["unreachable_objects"] == 0
                assert stats["compactions"] > 0
                assert sum(r["compaction_delta"]["count"] for r in cf_rows if r["operation"]["kind"] == "push") == stats["compactions"]
                assert stats["cache_retained_bytes"] <= 33554432
                assert stats["objects"]["reachable_objects"] == stats["objects"]["unique_objects"]
                metric = {k:v for k,v in stats.items() if not isinstance(v,(list,dict))}
                metric |= {"profile":profile,"provider":p,"sample":sample,"push_wire_bytes":sum(r["push_wire_bytes"] for r in cf_rows if r["operation"]["kind"]=="push"),"fetch_client_pack_bytes":sum(r["client_received_pack_bytes"] for r in cf_rows if r["operation"]["kind"]=="fetch"),"fetch_http_response_bytes":sum(r["http_response_body_bytes"] for r in cf_rows if r["operation"]["kind"]=="fetch"),"do_sqlite_bytes":stats["cloudflare_services"]["do_sqlite_bytes"],"r2_live_bytes":stats["cloudflare_services"]["r2_live_bytes"],"r2_peak_bytes":stats["cloudflare_services"]["r2_peak_bytes"]}
                metrics.append(metric)
                for key, host in by_backend["cloudflare-local"].items():
                    git = by_backend["git"][key]
                    push = host["operation"]["kind"] == "push"
                    host_ms = host["ready_wall_ms"] if push else host["wall_ms"]
                    git_ms = git["ready_wall_ms"] if push else git["wall_ms"]
                    row_ratios.append([profile,p,sample,key,host["operation"]["group"],host_ms,git_ms,host_ms/git_ms])
        provider_results.append({"provider":p,"source_commit":ref,"source_tree":identity["tree"],"native_sha":native_sha,"raw_sha256":hashlib.sha256(raw_path.read_bytes()).hexdigest(),"complete_validated_32push_56fetch_both_samples_backends":True,"warmup_validated":True,"full_cost_null":True})
        hardware[f"{profile}/{p}"] = report["machine"]
    assert len(set(states)) == len(PROVIDERS) and len(set(pids)) == len(PROVIDERS) and len(set(report_ids)) == len(PROVIDERS)
    assert len({native_hashes[p] for p in PROVIDERS}) == len(PROVIDERS)
    freshness.append({"profile":profile,"distinct_state_directories":states,"distinct_worker_pids":pids,"distinct_report_run_ids":report_ids,"all_provider_cloudflare_initial_pushes_start_generation_zero":True})
    results.append({"profile":profile,"run_id":runtime["run_id"],"attempt":runtime["run_attempt"],"boot_id":runtime["vm_boot_id"],"same_vm_all_providers":True,"providers":provider_results})
save("independent-validation.json", {"run_url":"https://github.com/no-std-rs/git-zero/actions/runs/39118509165","head":EXPECTED["head"],"profiles":results,"native_sha_by_provider":native_hashes,"common_hashes":common_hashes,"common_runtime_hashes":common_runtime_hashes,"common_workerd_provenance":common_workerd_provenance})
save("fresh-state-validation.json",freshness)
save("hardware-by-profile.json",hardware)
save("counter-scopes.json",scopes)
save("operation-metrics.json",metrics)
with (ROOT / "operation-row-ratios.tsv").open("w") as stream:
    writer=csv.writer(stream,delimiter="\t")
    writer.writerow(["profile","provider","sample","operation","group","host_ready_or_fetch_ms","paired_git_ready_or_fetch_ms","host_to_git_ratio"])
    writer.writerows(row_ratios)
print(json.dumps({"profiles_validated":[r["profile"] for r in results],"reports":sum(len(r["providers"]) for r in results),"fixed_counter_trials":len(scopes),"measured_operation_ratios":len(row_ratios)}))
