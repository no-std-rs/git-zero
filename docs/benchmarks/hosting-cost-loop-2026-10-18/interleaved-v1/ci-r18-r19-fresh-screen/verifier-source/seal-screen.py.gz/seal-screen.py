"""Seal fresh screen originals, exact derived tables and independent review."""
import csv,gzip,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
BASE=Path(__file__).parent;ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r18-r19-screen/run-39118509165');PUB=ROOT/'publication'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(ROOT/n).write_text(json.dumps(v,indent=2)+'\n')
run=json.loads((ROOT/'run.json').read_text());jobs=json.loads((ROOT/'jobs.json').read_text())['jobs'];inventory=json.loads((ROOT/'artifact-index.json').read_text())
assert run['id']==39118509165 and run['head_sha']=='622b3482b8f460c2e9b24bedf1ccc5735634aab8' and run['run_attempt']==1 and run['conclusion']=='success'
assert len(jobs)==5 and all(j['conclusion']=='success' for j in jobs)
assert inventory['total_count']==5
archives=[];checks=0
for a in inventory['artifacts']:
 assert a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==run['head_sha'] and a['name'].endswith('-1')
 original=next((ROOT/'downloads'/a['name']).glob('*.tar.gz'));assert original.stat().st_size<=4194304
 directory=ROOT/'scores' if a['name'].startswith('hosting-scores-') else ROOT/'profiles'/a['name'].removeprefix('hosting-screen-').removesuffix('-1')
 for line in (directory/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);p=(directory/n).resolve();assert p.is_relative_to(directory.resolve()) and sha(p)==h
  checks+=1
 archives.append({'artifact_id':a['id'],'name':a['name'],'path':str(original.relative_to(ROOT)),'bytes':original.stat().st_size,'SHA256':sha(original),'run_id':run['id'],'attempt':1,'expires_at':a['expires_at']})
assert sum(a['bytes'] for a in archives)<=20971520 and checks>0
raw=list((ROOT/'profiles').glob('*/*/*mib-*.json'));assert len(raw)==8
assert not any('incomplete' in p.name or 'progress.jsonl' in p.name for p in (ROOT/'profiles').rglob('*') if p.is_file())
summary=json.loads((ROOT/'summary.json').read_text());guards=json.loads((ROOT/'guard-report.json').read_text());distribution=json.loads((ROOT/'distribution-review.json').read_text())
ratios=list(csv.DictReader((ROOT/'operation-row-ratios.tsv').open(),delimiter='\t'));assert len(ratios)==1408
repro=json.loads((ROOT/'offline/evaluator-provenance.json').read_text());assert len(repro['identical_files'])==3
assert all(c['comparison']['decision']=='inconclusive' and not c['comparison']['eligible_rejected_candidate_for_plateau'] for c in guards['comparisons'])
assert subprocess.check_output(['git','-C','/tmp/git-zero-hosting-cost-loop','rev-parse','HEAD'],text=True).strip()==run['head_sha']
assert subprocess.check_output(['git','-C','/tmp/git-zero-hosting-cost-loop','status','--porcelain'],text=True)==''
limits=sum(not row[k] for c in guards['comparisons'] for p in c['profiles'] for row in p['latency_guards'] for k in ['median_passed','p95_passed'])
failed_groups=sum(len(c['failed_latency_guards']) for c in guards['comparisons'])
save('all-four-outcomes.json',{'run_id':run['id'],'attempt':1,'head':run['head_sha'],'jobs':[{'name':j['name'],'conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at']} for j in jobs],'all_five_original_archives':archives,'original_total_bytes':sum(a['bytes'] for a in archives),'raw_reports':8,'old_attempt_samples_scores_or_reports_reused':False})
save('original-artifact-final-reverification.json',{'all_original_internal_hashes_reverified_after_all_analysis':True,'original_file_checksums':checks,'original_archives':5,'raw_reports':8,'original_reports_mutated':False})
review=json.loads((ROOT/'INDEPENDENT_REVIEW.json').read_text());review.update({'all_four_resource_and_latency_guard_review_complete':True,'resource_guards':36,'profile_cost_guards':4,'latency_groups':24,'latency_median_p95_limits':48,'failed_latency_groups':failed_groups,'failed_latency_limits':limits,'individual_measured_ratios':len(ratios),'all_failure_group_pairs_retained':True,'retained_selected_tails':64,'conservative_at_least_1pct_separated_cost_envelopes':[{'comparison':c['name'],'passed':c['conservative_dollar_threshold_passed']} for c in summary['comparisons']],'formal_acceptance_speed_or_plateau_established':False,'provisional_selection':'Coordinator only after independent all-guard/tail review; no selection made by measurement auditor.','mandatory_original_R1_final_five_fresh_pairs_each_of_all_four_profiles':'NOT DONE','runner_amendment':'The unchanged reviewed common runner includes only the earlier error-only stderr exporter. This fresh batch pins R18/R19 and the common six-module Worker; fresh common binary hashes are independently recorded and compared; no historical binary is substituted.','binary_identity_limit':'Current common binary identities are recorded in binary-and-order-provenance-review.json; the frozen evaluator is 01b36df2f5f2019eeb09ebe79eb8ae80e9f86d0cdf39667c9fec9b0584e61fb8. Unchanged scorer/pricing source and exact reproduction are checked separately. No historical binary or report is substituted.','fault_log_export':'All 8 provider/profile reports completed; no failure-log exporter manifest exists, as expected for error-only code. This is not a new fault-injection sample.','observer_scope_limit':'Actual final full-view restoration receipts and observed DO epoch transitions are retained separately. Zero observed HEADs and no binding failures do not establish permanent proof validity or free future recovery; no observer repair saving is credited.','primary_at_seal':{'head':run['head_sha'],'clean':True}})
cache_review=json.loads((ROOT/'joint-cache-review.json').read_text())
cache_activation=json.loads((ROOT/'protected-chunk-activation-and-scope-review.json').read_text())
assert cache_review['measured_R19_host_rows']==704
review.update({'R19_measured_host_rows_individually_audited':704,'raw_host_operation_rows_including_both_providers_and_warmups':cache_review['observed_operations'],'secondary_heuristic':cache_activation['source_secondary_heuristic'],'all_704_R19_rows_within_actual_joint_caps_and_pool_event_balances':cache_review['every_observed_joint_gauge_within_cap'],'maximum_observed_joint_retained_bytes':max(r['maximum_observed_joint_retained_bytes'] for r in cache_review['trials']),'maximum_source_exported_joint_peak_bytes':max(r['actual_final_cache_gauges']['joint_cache_retained_peak_bytes'] for r in cache_activation['trials']),'protected_chunk_diagnostic_checks':cache_activation['diagnostic_checks_inspected'],'protected_chunk_diagnostic_failures':cache_activation['diagnostic_failures'],'per_key_membership_or_attempt_timeline_exported':False,'scope_limit':'Actual per-operation pool events, verified GET/bytes, selected-view gauges, transport, startup and observer receipts are retained. No per-key internal timeline, modeled338 count, allocated15MiB reserve, shadow scope or free future GC is inferred.'})
save('INDEPENDENT_REVIEW.json',review)
max_latency=max(ratios,key=lambda r:float(r['host_ready_or_fetch_ms']));max_ratio=max(ratios,key=lambda r:float(r['host_to_git_ratio']))
comparison_findings=[{'comparison':c['name'],'baseline_known_usd':c['baseline_known_usd'],'candidate_known_usd':c['candidate_known_usd'],'known_reduction_fraction':c['comparison']['known_cost_reduction_fraction'],'resource_failures':c['resource_guard_failures'],'profile_cost_failures':c['failed_profile_cost_guards'],'failed_latency_groups':len(c['latency_guard_failures']),'decision':c['comparison']['decision'],'plateau_eligible':c['comparison']['eligible_rejected_candidate_for_plateau']} for c in summary['comparisons']]
save('analysis.json',{'run_id':run['id'],'attempt':1,'head':run['head_sha'],'stage':'two-pair screen','fresh_scores':summary['scores'],'comparisons':comparison_findings,'all_resource_and_profile_cost_and_conservative_cost_guards_pass':all(c['resource_guard_failures']==0 and not c['failed_profile_cost_guards'] and c['conservative_dollar_threshold_passed'] for c in summary['comparisons']),'all_24_latency_groups_and_48_limits_inspected':True,'failed_latency_groups':failed_groups,'failed_latency_limits':limits,'all_1408_individual_ratios_retained':True,'all_failed_workload_pairs_and_all_raw_tails_retained':True,'largest_host_latency':max_latency,'largest_individual_ratio':max_ratio,'full_bill_usd':None,'unknown':['Worker CPU','DO duration','monthly SQLite storage','native compute'],'formal_result':'INCONCLUSIVE; plateau-ineligible; no speed or acceptance claim','final_five_pair_original_R1_vs_final_all_profiles':'NOT DONE'})
vs=ROOT/'verifier-source';vs.mkdir(exist_ok=True)
executed=['source-policy-review.py','protected-chunk-review.py','monitor-once.py','validate-profiles.py','binary-and-order-audit.py','transport-activation-review.py','failed-latency-pair-review.py','receipt-review.py','lifecycle-review.py','cache-joint-review.py','failure-log-review.py','score-offline.py','distribution-review.py','detailed-metrics.py','summarize-resources.py','finalize-evidence.py','seal-screen.py']
for name in executed:shutil.copyfile(BASE/name,vs/name)
shutil.copyfile(ROOT/'summarize-chain.py',vs/'summarize-chain.py')
(vs/'LOCATION.json').write_text(json.dumps({'executed_script_directory':str(BASE),'raw_evidence_root':str(ROOT),'scope':'Read-only GitHub monitoring; offline Python hash/math/packaging and pre-existing frozen Rust evaluator only. No independent benchmark, service/probe, source mutation, push, trigger, deployment, retry or cancellation.'},indent=2)+'\n')
PUB.mkdir(exist_ok=True);mapping=[]
def payload(src,name,compress):
 dst=PUB/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if compress:
  with dst.open('wb') as f:
   with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:z.write(src.read_bytes())
  assert gzip.decompress(dst.read_bytes())==src.read_bytes()
 else:shutil.copyfile(src,dst)
 mapping.append({'published_path':name,'source_path':str(src.relative_to(ROOT)),'source_bytes':src.stat().st_size,'source_exact_SHA256':sha(src),'published_bytes':dst.stat().st_size,'published_SHA256':sha(dst),'encoding':'deterministic gzip of exact source bytes' if compress else 'original bytes'})
for a in archives:payload(ROOT/a['path'],'original-archives/'+Path(a['path']).name,False)
for p in sorted(ROOT.iterdir()):
 if p.is_file() and (p.suffix in {'.json','.tsv'} or p.name=='RAW_SHA256SUMS'):payload(p,'review/'+p.name+'.gz',True)
for directory,label in [(ROOT/'offline','offline'),(vs,'verifier-source')]:
 for p in sorted(directory.iterdir()):
  if p.is_file():payload(p,label+'/'+p.name+'.gz',True)
score_lines='\n'.join(f"- {p.upper()}: ${v['known_fixed_usd']:.11f}" for p,v in summary['scores'].items())
resource_failures=sum(c['resource_guard_failures'] for c in summary['comparisons'])
profile_cost_failures=sum(len(c['failed_profile_cost_guards']) for c in summary['comparisons'])
envelope_results=', '.join(c['name']+': '+('pass' if c['conservative_dollar_threshold_passed'] else 'FAIL') for c in summary['comparisons'])
scopes=json.loads((ROOT/'counter-scopes.json').read_text())
physical_lines=[]
for profile in ['16mib-cold','64mib-cold']:
 for provider in ['r18','r19']:
  rs=[r['fixed_workload'] for r in scopes if r['profile']==profile and r['provider']==provider]
  physical_lines.append('| '+profile+' | '+provider+' | '+' | '.join(f"{sum(r[k] for r in rs)/len(rs):,.0f}" for k in ['r2_class_b','r2_read_bytes','worker_requests','do_requests'])+' |')
physical_table='\n'.join(physical_lines)
known_reduction=summary['comparisons'][0]['comparison']['known_cost_reduction_fraction']*100
(PUB/'README.md').write_text(f'''# Fresh R18–R19 two-pair screen

Run 39118509165, attempt 1, at `622b3482b8f460c2e9b24bedf1ccc5735634aab8` completed all four profile jobs and scoring. All 8 reports and five original archives come from this fresh attempt. No earlier sample, report, score or comparison was reused.

The frozen Rust evaluator independently reproduced both scores and the comparison byte for byte. Known fixed objectives are:

{score_lines}

R19’s measured known fixed subtotal is {known_reduction:.9f}% below R18. Full hosting cost stays unknown. All 36 resource guards and 4 profile-cost guards were inspected: {resource_failures} resource failures and {profile_cost_failures} profile-cost failures. Conservative separated >=1% known-cost envelopes: {envelope_results}. All 24 latency groups and 48 median/p95 limits were inspected; {failed_groups} groups fail {limits} limits. Every failed-workload pair, all 1,408 individual ratios, 64 selected tails and every original raw tail remain retained. Largest measured host latency is {float(max_latency['host_ready_or_fetch_ms'])/1000:.3f} seconds against paired Git {float(max_latency['paired_git_ready_or_fetch_ms'])/1000:.3f} seconds. No sample was discarded.

The following are actual fixed-window per-trial means across the two measured samples; all individual SQL-read variations stay in the original receipts. All actual HEAD counts are zero, so Class B equals GET attempts here.

| Profile | Provider | GETs | Read bytes | Worker requests | DO requests |
| --- | --- | ---: | ---: | ---: | ---: |
{physical_table}

R19's Multi production path can retain at most 32 verified chunks and considers every already-required verified miss in selection order. The 17 MiB secondary owning admission preference leaves 15 MiB unallocated; it is not owned memory, reserved capacity, a separate cache, or a 14 MiB response cap. Actual joint 32 MiB/256-entry gauges include pool backing/growth, complete payload ownership, keys, headers, response ring, actual/pending certificates/history/proofs and the 262,144-byte socket reservation. Individual responses up to 16 MiB stay eligible. Actual required pressure evicts newest secondary chunks then anchor before response LRU entries. All 704 measured R19 host rows and their gauges are reviewed, plus all warmups. Logical pruning, pressure/reset eviction and physical R2 retirement stay distinct. Pruning requires confirmed current Full authority or ordinary authoritative recovery; observers neither admit nor logically prune. Actual startup GETs remain paid and separate.

Actual GETs, read/written bytes, Worker/ordinary DO/SQL counts, selected-view gauges, response deltas, admission/hit/rejection/prune/pressure events and every operation difference are retained without forcing parity or a 338-GET source model. Per-key membership and internal attempt timelines are not exported by the frozen runner and are not invented. New published chunks still need positive naturally required cold GETs, while warm ordinary payload GET remains zero. Both providers count actual Upgrades as Worker requests and each application RPC as one ordinary DO HTTP dispatch. No 20:1 ratio, frame multiplier or elapsed-CPU estimate applies. Startup and final-observer full restoration, phase-shifting Upgrades/RPCs and observed epochs remain separate actual receipts; no permanent proof or future-free recovery credit is inferred.

The comparison remains INCONCLUSIVE and plateau-ineligible. No formal acceptance, speed improvement, provisional selection or stopping condition is declared by this auditor. Five fresh original-R1/final pairs on every profile remain NOT DONE. Worker CPU, DO duration, monthly SQLite storage and Native compute remain unknown. Final observer restoration is physically retained and excluded from the fixed objective; observed epochs or zero HEAD counts do not prove permanent proof validity or free future GC. Final snapshots do not certify absence of later ACK, close or teardown traffic.

ARTIFACT_MAP.json records original paths and exact uncompressed/published SHA256 identities. JSON/TSV/source payloads use deterministic gzip of their exact bytes. SHA256SUMS covers every published payload. The five original archives appear once; extracted originals are omitted. Earlier completed and failed attempts remain separate and unchanged. Separate joint-only admission and fresh-schema bootstrap proposals are not enabled by these source pins.
''')
(PUB/'ARTIFACT_MAP.json').write_text(json.dumps(mapping,indent=2)+'\n')
files=sorted(p for p in PUB.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(PUB/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(PUB)}\n' for p in files))
for line in (PUB/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(PUB/n)==h
bundle=ROOT/'fresh-screen-evidence.tar.gz'
with bundle.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for p in sorted(p for p in PUB.rglob('*') if p.is_file()):
    info=tar.gettarinfo(str(p),arcname='fresh-screen-evidence/'+str(p.relative_to(PUB)));info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
    with p.open('rb') as stream:tar.addfile(info,stream)
assert bundle.stat().st_size<10*1024*1024,bundle.stat().st_size
with tarfile.open(bundle) as tar:
 for member in tar.getmembers():assert tar.extractfile(member).read()==(PUB/member.name.removeprefix('fresh-screen-evidence/')).read_bytes()
all_files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'SHA256SUMS');(ROOT/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT)}\n' for p in all_files))
for line in (ROOT/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(ROOT/n)==h
print(json.dumps({'status':'SEALED INCONCLUSIVE FRESH SCREEN','capsule':str(bundle),'capsule_bytes':bundle.stat().st_size,'capsule_SHA256':sha(bundle),'publication_manifest_SHA256':sha(PUB/'SHA256SUMS'),'whole_evidence_manifest_SHA256':sha(ROOT/'SHA256SUMS'),'all_hashed_files_reverified':len(all_files),'original_internal_hashes_reverified':checks,'original_archive_bytes':sum(a['bytes'] for a in archives),'mapped_payloads':len(mapping),'both_scores_and_comparison_byte_exact':True,'ratios':len(ratios),'resource_guards':36,'profile_cost_guards':4,'latency_groups':24,'failed_groups':failed_groups,'failed_limits':limits,'no_selection_acceptance_speed_or_plateau_claim':True}))
