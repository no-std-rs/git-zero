"""Read-only complete source identities and cache ownership policy receipts."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r17-r18-screen/run-39113545149')
SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
decl=json.loads((ROOT/'prospective-source-identities.json').read_text())
expected=json.loads((ROOT/'expected-source-identities.json').read_text())
def git(*args):return subprocess.check_output(['git','-C',str(SOURCE),*args])
def sha(b):return hashlib.sha256(b).hexdigest()
def manifest(commit,prefix):
    result={}
    for path in git('ls-tree','-r','--name-only',commit,'--',prefix).decode().splitlines():
        result[path]=sha(git('show',commit+':'+path))
    return result
providers={}
for label,commit in decl['provider_commits'].items():
    providers[label]={'commit':commit,'native_source_tree':git('rev-parse',commit+':examples/repository-host/src').decode().strip(),'every_native_source_file_SHA256':manifest(commit,'examples/repository-host/src')}
    assert providers[label]['native_source_tree']==decl['provider_native_source_trees'][label]
actual=manifest(decl['head'],'examples/repository-host/src')
r18=providers['r18']['every_native_source_file_SHA256']
changed=[p for p in sorted(actual.keys()|r18.keys()) if actual.get(p)!=r18.get(p)]
assert changed==['examples/repository-host/src/bin/hosting-bench.rs','examples/repository-host/src/bin/hosting-bench/failure_logs.rs'],changed
worker=manifest(decl['head'],'examples/repository-host/cloudflare/src')
assert worker==decl['common_worker_modules']
unchanged={p:v for p,v in expected['sources'].items() if p.endswith(('hosting-bench.rs','hosting-cost.rs','benchmark_cost.rs'))}
assert all(v['current_sha256']==v['prior_sha256'] for v in unchanged.values())
assert expected['pricing_source']['current_sha256']==expected['pricing_source']['prior_sha256']
review={'run_id':39113545149,'attempt':1,'head':decl['head'],'providers':providers,'common_head_native_source_manifest':actual,'head_native_differences_from_pinned_R18':changed,'difference_scope':'The independently reviewed prior 5901 error-only benchmark failure-log exporter; no successful workload, scorer or pricing change.','common_six_Worker_modules':worker,'runner_scorer_entries_unchanged':unchanged,'pricing_source':expected['pricing_source'],'ownership_source_policy':{'default':'One generic protected chunk enabled for Cloudflare; repository-host CLI defaults true, with no benchmark-specific key or workload switch.','admission':'materialize_view_prefetched requests a verified candidate only for an ordinary request when the protected slot is empty; admit_protected_chunk requires the same ordinary gate and verified bytes <=16 MiB.','no_implicit_admission':'recover temporarily clears ordinary admission; construction begins false; PUT and final object observer do not populate the slot. Warm persistent materialization does not invent a GET.','selection':'Exact ordered selected descriptors are resolved from one retained verified chunk plus all missing chunks; cached descriptor identity participates in signed first-read selection.','fallback':'Invalid/stale prepared selection is counted as a paid discard and uses ordinary safe reconstruction; all-cache Unsupported uses ordinary dispatch. No GET, byte, DO or preparation parity is presumed.','ownership':'metadata_bytes includes protected handle ownership, response keys/headers/ring, current and pending certificates/history, retirement proof and socket reservation. trim_joint enforces one 32 MiB/256-entry budget and can evict the protected slot after responses. Response-only gauges remain distinct.','freshness':'GET-only admission leaves newly PUT published chunks uncached; each cold latest-after-push operation must retain actual positive GET+bytes.','runtime_limit':'Source controls are not measurements. Raw per-operation receipts record actual aggregate attempts and selected-view/cache diagnostics, not every internal descriptor key or unobserved future callback.'}}
(ROOT/'whole-source-and-cache-policy-review.json').write_text(json.dumps(review,indent=2)+'\n')
prior_head='becec3f57b74ae19c9251ad3ddea25e62de07c84'
failure_module='examples/repository-host/src/bin/hosting-bench/failure_logs.rs'
assert git('show',prior_head+':'+failure_module)==git('show',decl['head']+':'+failure_module)
(ROOT/'failure-only-runner-source-audit.json').write_text(json.dumps({'head':decl['head'],'failure_only_runner_unchanged_from_prior_source':True,'new_failure_module_SHA256':sha(git('show',decl['head']+':'+failure_module)),'successful_workload_scorer_and_pricing_unchanged':True,'prior_source_comparison_only':prior_head,'old_samples_reports_scores_used':False},indent=2)+'\n')
print(json.dumps({'provider_native_source_file_counts':{p:len(v['every_native_source_file_SHA256']) for p,v in providers.items()},'common_Worker_modules':len(worker),'head_only_reviewed_diagnostic_files':changed}))
