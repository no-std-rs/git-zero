"""Rebuild every scored latency/resource distribution from unchanged raw bytes."""
import collections
import csv
import json
import math
from pathlib import Path

ROOT = Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r17-r18-screen/run-39113545149')
PROVIDERS = ["r17", "r18"]
PROFILES = ["16mib-cold", "16mib-warm", "64mib-cold", "64mib-warm"]


def distribution(values):
    values = sorted(values)
    n = len(values)
    assert n and all(math.isfinite(x) and x >= 0 for x in values)
    return {"mean":sum(values)/n,"min":values[0],"max":values[-1],
            "median":(values[n//2-1]+values[n//2])/2 if n%2==0 else values[n//2],
            "p95":values[math.ceil(n*.95)-1]}


def equal(actual, expected):
    assert actual.keys() == expected.keys()
    for k,v in actual.items():
        assert math.isclose(v,expected[k],rel_tol=1e-12,abs_tol=1e-12),(k,v,expected[k])


latency_groups, resources, extremes, comparison_rows = [], [], [], []
for provider in PROVIDERS:
    score = json.loads((ROOT/"offline"/f"{provider}-score.json").read_text())
    for profile in PROFILES:
        ps = score["profiles"][profile]
        report = json.loads((ROOT/"profiles"/profile/provider/f"{profile}.json").read_text())
        latency = collections.defaultdict(lambda:collections.defaultdict(list))
        guards = collections.defaultdict(list)
        rows = [r for r in report["raw"] if not r["warmup"] and "operation" in r]
        ratio_rows = []
        for sample in [0,1]:
            cf = [r for r in rows if r["sample"] == sample and r["backend"] == "cloudflare-local"]
            git = {r["operation"]["key"]:r for r in rows if r["sample"] == sample and r["backend"] == "git"}
            fixed = {k:None if v is None else sum(r["cloudflare_workload_delta"][k] for r in cf)
                     for k,v in cf[0]["cloudflare_workload_delta"].items()}
            fetches = [r for r in cf if r["operation"]["kind"] == "fetch"]
            stats = next(r for r in report["cloudflare_runs"] if r["sample"] == sample)["final_object_stats"]["cloudflare_services"]
            read = sum(r["cloudflare_workload_delta"]["r2_read_bytes"] for r in fetches)
            http = sum(r["http_response_body_bytes"] for r in fetches)
            for k,v in {"r2_peak_bytes":stats["r2_peak_bytes"],"r2_live_bytes":stats["r2_live_bytes"],
                "do_sqlite_bytes":stats["do_sqlite_bytes"],"fixed_r2_read_bytes":fixed["r2_read_bytes"],
                "fixed_r2_written_bytes":fixed["r2_written_bytes"],"varied_fetch_r2_read_bytes":read,
                "varied_fetch_http_response_bytes":http,"varied_fetch_client_pack_bytes":sum(r["client_received_pack_bytes"] for r in fetches),
                "varied_fetch_read_amplification":read/http}.items():
                guards[k].append(v)
            for row in cf:
                op = row["operation"]
                host = row["ready_wall_ms"] if op["kind"] == "push" else row["wall_ms"]
                paired = git[op["key"]]
                reference = paired["ready_wall_ms"] if op["kind"] == "push" else paired["wall_ms"]
                assert reference > 0
                ratio = host/reference
                for k,v in {"host_ms":host,"git_ms":reference,"paired_host_to_git":ratio}.items():
                    latency[op["group"]][k].append(v)
                ratio_rows.append({"provider":provider,"profile":profile,"sample":sample,"operation":op["key"],
                                   "group":op["group"],"host_ready_or_fetch_ms":host,"paired_git_ready_or_fetch_ms":reference,"ratio":ratio})
        assert guards.keys() == ps["guards"].keys() and len(guards) == 9
        assert latency.keys() == ps["latency"].keys() and len(latency) == 6
        for group, metrics in latency.items():
            dists = {k:distribution(v) for k,v in metrics.items()}
            for k,v in dists.items():
                equal(v,ps["latency"][group][k])
            latency_groups.append({"provider":provider,"profile":profile,"group":group,"operations":len(metrics["host_ms"]),"distributions":dists})
        for key,values in guards.items():
            dist = distribution(values)
            equal(dist,ps["guards"][key])
            resources.append({"provider":provider,"profile":profile,"resource":key,"trial_values":values,"distribution":dist})
        extremes.append({"provider":provider,"profile":profile,"scope":"All 176 measured operations per report inspected; extrema retained without pruning.",
            "largest_host_to_git_ratios":sorted(ratio_rows,key=lambda r:r["ratio"],reverse=True)[:8],
            "smallest_host_to_git_ratios":sorted(ratio_rows,key=lambda r:r["ratio"])[:8],
            "largest_host_latencies":sorted(ratio_rows,key=lambda r:r["host_ready_or_fetch_ms"],reverse=True)[:8]})

summary = json.loads((ROOT/"summary.json").read_text())
for comparison in summary["comparisons"]:
    comparison_rows.append({"comparison":comparison["name"],"baseline_known_usd":comparison["baseline_known_usd"],
        "candidate_known_usd":comparison["candidate_known_usd"],
        "known_reduction_fraction":comparison["comparison"]["known_cost_reduction_fraction"],
        "separated_at_least_1pct_dollar_reduction":comparison["conservative_dollar_threshold_passed"],
        "resource_failures":comparison["resource_guard_failures"],"profile_cost_failures":len(comparison["failed_profile_cost_guards"]),
        "latency_group_failures":len(comparison["latency_guard_failures"]),
        "decision":comparison["comparison"]["decision"],"plateau_eligible":comparison["comparison"]["eligible_rejected_candidate_for_plateau"]})
assert len(latency_groups) == 48 and len(resources) == 72
assert len(comparison_rows) == 1
guards = json.loads((ROOT/"guard-report.json").read_text())
assert sum(len(p["resource_guards"]) for c in guards["comparisons"] for p in c["profiles"]) == 36
assert sum(len(p["latency_guards"]) for c in guards["comparisons"] for p in c["profiles"]) == 24
assert sum(len(c["profiles"]) for c in guards["comparisons"]) == 4
for name,data in [("rebuilt-latency-distributions.json",latency_groups),("rebuilt-resource-distributions.json",resources),("all-individual-ratio-extremes.json",extremes)]:
    (ROOT/name).write_text(json.dumps(data,indent=2)+"\n")
with (ROOT/"comparison-summary.tsv").open("w") as stream:
    writer=csv.DictWriter(stream,fieldnames=list(comparison_rows[0]),delimiter="\t")
    writer.writeheader();writer.writerows(comparison_rows)
(ROOT/"distribution-review.json").write_text(json.dumps({"independently_rebuilt_report_latency_groups":48,
    "independently_rebuilt_report_resource_groups":72,"all_measured_individual_ratios":1408,
    "comparison_resource_groups":36,"comparison_cost_groups":4,"comparison_latency_groups":24,
    "all_screen_inconclusive":all(c["decision"]=="inconclusive" for c in comparison_rows),
    "all_plateau_ineligible":all(c["plateau_eligible"] is False for c in comparison_rows)},indent=2)+"\n")
print(json.dumps({"comparisons":comparison_rows,"individual_ratios":1408,"rebuilt_latency_groups":48,"rebuilt_resource_groups":72}))
