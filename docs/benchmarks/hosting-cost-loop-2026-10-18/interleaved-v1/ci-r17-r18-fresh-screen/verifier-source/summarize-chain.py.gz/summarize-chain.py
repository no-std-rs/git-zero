"""Derived evidence only; never writes raw reports or changes scorer decisions."""
import csv
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
offline = root / "offline"
providers = ["r17", "r18"]
scores = {p: json.loads((offline / f"{p}-score.json").read_text()) for p in providers}

def change(new, old):
    return new / old - 1 if old else (0 if not new else None)

comparisons = []
latency_rows = []
resource_rows = []
for later in range(1, len(providers)):
    for earlier in range(later):
        bp, cp = providers[earlier], providers[later]
        name = f"{cp}-vs-{bp}"
        b, c = scores[bp], scores[cp]
        evaluated = json.loads((offline / f"{name}.json").read_text())
        assert evaluated["score"] == c
        assert evaluated["comparison"]["decision"] == "inconclusive"
        assert not evaluated["comparison"]["eligible_rejected_candidate_for_plateau"]
        profiles = []
        for profile, old in b["profiles"].items():
            new = c["profiles"][profile]
            resources = []
            for resource, old_stats in old["guards"].items():
                new_stats = new["guards"][resource]
                row = dict(resource=resource, baseline=old_stats, candidate=new_stats,
                           change_fraction=change(new_stats["mean"], old_stats["mean"]),
                           passed=new_stats["mean"] <= old_stats["mean"] * 1.01 + 1e-12)
                resources.append(row)
                resource_rows.append([name, profile, resource, old_stats["mean"],
                                      new_stats["mean"], row["change_fraction"], row["passed"]])
            latencies = []
            for workload, old_latency in old["latency"].items():
                new_latency = new["latency"][workload]
                old_ratios, new_ratios = old_latency["paired_host_to_git"], new_latency["paired_host_to_git"]
                median_pass = new_ratios["median"] <= old_ratios["median"] * 1.10
                p95_pass = new_ratios["p95"] <= old_ratios["p95"] * 1.25
                row = dict(workload=workload, baseline=old_latency, candidate=new_latency,
                           median_change_fraction=change(new_ratios["median"], old_ratios["median"]),
                           p95_change_fraction=change(new_ratios["p95"], old_ratios["p95"]),
                           median_passed=median_pass, p95_passed=p95_pass)
                latencies.append(row)
                latency_rows.append([name, profile, workload,
                                     old_latency["host_ms"]["median"], new_latency["host_ms"]["median"],
                                     old_latency["host_ms"]["p95"], new_latency["host_ms"]["p95"],
                                     old_latency["git_ms"]["median"], new_latency["git_ms"]["median"],
                                     old_latency["git_ms"]["p95"], new_latency["git_ms"]["p95"],
                                     old_ratios["median"], new_ratios["median"],
                                     old_ratios["p95"], new_ratios["p95"],
                                     row["median_change_fraction"], row["p95_change_fraction"],
                                     median_pass, p95_pass])
            old_cost, new_cost = old["known_monthly_fixed_workload_usd"], new["known_monthly_fixed_workload_usd"]
            profiles.append(dict(profile=profile, baseline_cost=old_cost, candidate_cost=new_cost,
                                 cost_change_fraction=change(new_cost["mean"], old_cost["mean"]),
                                 profile_cost_guard_passed=new_cost["mean"] <= old_cost["mean"] * 1.01,
                                 baseline_fixed_workload_trials=old["trials"],
                                 candidate_fixed_workload_trials=new["trials"],
                                 unmeasured_billing_dimensions=new["unmeasured_billing_dimensions"],
                                 resource_guards=resources, latency_guards=latencies))
        comparison = dict(name=name, baseline=bp, candidate=cp,
                          baseline_known_usd=b["known_monthly_fixed_workload_usd"],
                          candidate_known_usd=c["known_monthly_fixed_workload_usd"],
                          baseline_envelope=[b["conservative_trial_min_usd"], b["conservative_trial_max_usd"]],
                          candidate_envelope=[c["conservative_trial_min_usd"], c["conservative_trial_max_usd"]],
                          conservative_dollar_threshold_passed=c["conservative_trial_max_usd"] <= b["conservative_trial_min_usd"] * .99 + 1e-12,
                          comparison=evaluated["comparison"], profiles=profiles)
        comparison["failed_resource_guards"] = [dict(profile=p["profile"], **r) for p in profiles for r in p["resource_guards"] if not r["passed"]]
        comparison["failed_profile_cost_guards"] = [p["profile"] for p in profiles if not p["profile_cost_guard_passed"]]
        comparison["failed_latency_guards"] = [dict(profile=p["profile"], **r) for p in profiles for r in p["latency_guards"] if not (r["median_passed"] and r["p95_passed"])]
        comparisons.append(comparison)

summary = dict(run_id=39113545149, attempt=1, head="556fa3bcacb46bf7cf1f7a3c04c6b3db77c54667",
               stage="screen", samples_per_profile=2, providers=providers,
               objective=scores["r17"]["objective"],
               counters_scope="Fixed counters include exactly scheduled 32 pushes and 56 fetches; whole observer-excluded traces separately include startup. No raw report mutation.",
               correlated_reuse="Each of two prospectively pinned suites was freshly measured once per profile. No earlier run samples or scores enter this comparison.",
               full_total_estimate_usd=None,
               unknown=["Worker CPU-ms", "Durable Object GB-seconds", "Durable Object SQLite GB-month", "native codec compute"],
               scores={p: dict(known_fixed_usd=s["known_monthly_fixed_workload_usd"],
                               envelope=[s["conservative_trial_min_usd"], s["conservative_trial_max_usd"]],
                               total_estimate_usd=s["total_estimate_usd"])
                       for p, s in scores.items()}, comparisons=comparisons)
assert all(s["total_estimate_usd"] is None for s in scores.values())
(root / "guard-report.json").write_text(json.dumps(summary, indent=2) + "\n")
compact = {k: v for k, v in summary.items() if k != "comparisons"}
compact["comparisons"] = [{k: v for k, v in c.items() if k not in ["profiles", "failed_resource_guards", "failed_latency_guards"]} | {
    "resource_guard_failures": len(c["failed_resource_guards"]),
    "latency_guard_failures": [dict(profile=r["profile"], workload=r["workload"], median_change_fraction=r["median_change_fraction"], p95_change_fraction=r["p95_change_fraction"], median_passed=r["median_passed"], p95_passed=r["p95_passed"]) for r in c["failed_latency_guards"]]
} for c in comparisons]
(root / "summary.json").write_text(json.dumps(compact, indent=2) + "\n")
with (root / "latency-ratios.tsv").open("w") as stream:
    writer = csv.writer(stream, delimiter="\t")
    writer.writerow(["comparison", "profile", "workload", "old_host_median_ms", "new_host_median_ms", "old_host_p95_ms", "new_host_p95_ms", "old_git_median_ms", "new_git_median_ms", "old_git_p95_ms", "new_git_p95_ms", "old_paired_median", "new_paired_median", "old_paired_p95", "new_paired_p95", "median_change_fraction", "p95_change_fraction", "median_passed", "p95_passed"])
    writer.writerows(latency_rows)
with (root / "resource-guards.tsv").open("w") as stream:
    writer = csv.writer(stream, delimiter="\t")
    writer.writerow(["comparison", "profile", "resource", "old_mean", "new_mean", "change_fraction", "passed"])
    writer.writerows(resource_rows)
print(json.dumps({"scores": compact["scores"], "comparisons": [{k:v for k,v in c.items() if k in ["name", "comparison", "resource_guard_failures", "failed_profile_cost_guards", "latency_guard_failures"]} for c in compact["comparisons"]]}, indent=2))
