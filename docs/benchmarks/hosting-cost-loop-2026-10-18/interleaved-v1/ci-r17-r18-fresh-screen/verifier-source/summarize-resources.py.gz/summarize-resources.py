"""Tabulate actual resources, scopes and tails without inferring billed CPU."""
import csv
import json
from pathlib import Path
import statistics

ROOT = Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r17-r18-screen/run-39113545149')
PROVIDERS = ["r17","r18"]
PROFILES = ["16mib-cold","16mib-warm","64mib-cold","64mib-warm"]
scopes = json.loads((ROOT / "counter-scopes.json").read_text())
metrics = json.loads((ROOT / "operation-metrics.json").read_text())
table, tails, discoveries = [], [], []
for p in PROVIDERS:
    score = json.loads((ROOT / "offline" / f"{p}-score.json").read_text())
    for profile in PROFILES:
        ps = score["profiles"][profile]
        cs = [r for r in scopes if r["provider"]==p and r["profile"]==profile]
        ms = [r for r in metrics if r["provider"]==p and r["profile"]==profile]
        row = {"provider":p,"profile":profile,"fixed_known_monthly_usd":ps["known_monthly_fixed_workload_usd"]["mean"],"fixed_known_trial_min_usd":ps["known_monthly_fixed_workload_usd"]["min"],"fixed_known_trial_max_usd":ps["known_monthly_fixed_workload_usd"]["max"],"whole_trace_known_monthly_usd":ps["known_monthly_whole_trace_usd"]["mean"],"full_total_estimate_usd":None}
        for key in ["known_usd_per_1000_pushes","known_usd_per_1000_varied_fetches"]:
            row[key] = statistics.mean(t[key] for t in ps["trials"])
        row |= {"fixed_resource_monthly_usd_"+k:statistics.mean(t["resource_monthly_usd"][k] for t in ps["trials"]) for k in ps["trials"][0]["resource_monthly_usd"]}
        row |= {"fixed_"+k: statistics.mean(t["fixed_workload"][k] for t in cs) for k,v in cs[0]["fixed_workload"].items() if v is not None}
        row |= {"whole_"+k: statistics.mean(t["whole_trace_observer_excluded"][k] for t in cs) for k,v in cs[0]["whole_trace_observer_excluded"].items() if v is not None}
        row |= {"guard_"+k:v["mean"] for k,v in ps["guards"].items()}
        for key in ["push_wire_bytes","fetch_client_pack_bytes","fetch_http_response_bytes","cloud_view_rehydrates","discovery_cache_hits","generation_witness_hits","generation_witness_fallbacks"]:
            if key in ms[0]:row[key]=statistics.mean(t[key] for t in ms)
        table.append(row)
        report = json.loads((ROOT / "profiles" / profile / p / f"{profile}.json").read_text())
        cf = [r for r in report["raw"] if not r["warmup"] and r["backend"]=="cloudflare-local"]
        for raw in sorted(cf,key=lambda r:r.get("ready_wall_ms",r["wall_ms"]),reverse=True)[:8]:
            item={"profile":profile,"provider":p,"sample":raw["sample"],"workload":raw["workload"],"operation":raw["operation"],"wall_ms":raw["wall_ms"],"ready_wall_ms":raw.get("ready_wall_ms"),"client_resources":raw.get("client_resources"),"service_metrics_delta":{k:v for k,v in raw["service_metrics_delta"].items() if not isinstance(v,(list,dict))},"fixed_workload_receipt":raw["cloudflare_workload_delta"],"push_wire_bytes":raw.get("push_wire_bytes"),"client_received_pack_bytes":raw.get("client_received_pack_bytes"),"http_response_body_bytes":raw.get("http_response_body_bytes"),"run_contention_before":raw["run_contention_before"],"run_contention_after":raw["run_contention_after"]}
            paired = next(r for r in report["raw"] if r["backend"] == "git" and r["sample"] == raw["sample"] and r.get("operation", {}).get("key") == raw["operation"]["key"])
            host_ms = raw.get("ready_wall_ms", raw["wall_ms"])
            git_ms = paired.get("ready_wall_ms", paired["wall_ms"])
            item["paired_git_ready_or_fetch_ms"] = git_ms
            item["paired_host_to_git_ratio"] = host_ms / git_ms
            item["paired_git_client_resources"] = paired["client_resources"]
            tails.append(item)
        for sample in [0,1]:
            initial = next(r for r in cf if r["sample"]==sample and r["operation"]["key"]=="push_01")
            final = next(r for r in cf if r["sample"]==sample and r["operation"]["key"]=="latest_recheck_32")
            selected=[r for r in cf if r["sample"]==sample]
            discoveries.append({"profile":profile,"provider":p,"sample":sample,"actual_native_metric_sums":{k:sum(r["service_metrics_delta"].get(k,0) for r in selected) for k in sorted(set().union(*(r["service_metrics_delta"].keys() for r in selected))) if not isinstance(initial["service_metrics_delta"].get(k),(dict,list)) and any(term in k for term in ["discovery","rehydrate","witness","eligible","shortcut"])},"first_push_metric_keys":list(initial["service_metrics_delta"]),"final_cache":final.get("server_cache_after_fetch")})
(ROOT / "provider-profile-resources.json").write_text(json.dumps(table,indent=2)+"\n")
with (ROOT / "provider-profile-resources.tsv").open("w") as stream:
    writer=csv.DictWriter(stream,fieldnames=list(dict.fromkeys(k for row in table for k in row)),delimiter="\t");writer.writeheader();writer.writerows(table)
(ROOT / "retained-tail-summary.json").write_text(json.dumps({"scope":"Eight largest measured operation latencies per provider/profile; full unchanged raw reports retain every operation and warmup.","warning":"Service or workerd header timing does not measure full HTTP completion. Client elapsed time is never substituted for billed CPU.","tails":tails},indent=2)+"\n")
(ROOT / "discovery-shortcut-metrics.json").write_text(json.dumps(discoveries,indent=2)+"\n")
print(json.dumps({"provider_profile_rows":len(table),"retained_top_tail_rows":len(tails),"discovery_trials":len(discoveries),"fixed_workload_scope":"Exactly 32 pushes and 56 fetches per measured trial; whole trace includes startup and is separate."}))
