"""Fresh R16 receiving / R17 socket accounting; no hypothetical billing discount."""
import collections, json, math
from pathlib import Path
ROOT = Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r15-r17-screen/run-39109536794')
PROVIDERS = ['r15', 'r16', 'r17']
PROFILES = ['16mib-cold', '16mib-warm', '64mib-cold', '64mib-warm']

def save(n, v):
    (ROOT / n).write_text(json.dumps(v, indent=2) + '\n')

def fixed(rows):
    return {k: None if v is None else sum((r['cloudflare_workload_delta'][k] for r in rows)) for k, v in rows[0]['cloudflare_workload_delta'].items()}

def difference(a, b):
    return {k: None if v is None or b.get(k) is None else v - b.get(k, 0) for k, v in a.items()}

def diagdelta(a, b):
    return {k: v - b.get(k, 0) for k, v in a.items() if isinstance(v, (int, float)) and (not isinstance(v, bool))}

def socket(row, when):
    return row[f'cloudflare_services_{when}'].get('socket_rpc', {})
AUDIT_CHECK_COUNT=0
AUDIT_CHECK_FAILURES=[]
def audit_check(condition, expression, detail=None):
    global AUDIT_CHECK_COUNT
    AUDIT_CHECK_COUNT+=1
    if not condition:
        AUDIT_CHECK_FAILURES.append({'expression':expression,'detail':detail,'profile':globals().get('profile'),'sample':globals().get('sample'),'provider':globals().get('p'),'baseline':globals().get('bp'),'candidate':globals().get('cp')})

trials = []
operations = []
comparisons = []
socket_trials = []
for profile in PROFILES:
    directory = ROOT / 'profiles' / profile
    if not (directory / 'checksum-verification.txt').exists():
        continue
    if not all(((directory / p / f'{profile}.json').exists() for p in PROVIDERS)):
        continue
    reports = {p: json.loads((directory / p / f'{profile}.json').read_text()) for p in PROVIDERS}
    for sample in [-1, 0, 1]:
        rows = {p: [r for r in d['raw'] if r['backend'] == 'cloudflare-local' and r['sample'] == sample] for p, d in reports.items()}
        for p, rs in rows.items():
            final = next((r for r in reports[p]['cloudflare_runs'] if r['sample'] == sample))['final_object_stats']
            services = final['cloudflare_services']
            events = {k: sum((r['service_metrics_delta'].get(k, 0) for r in rs)) for k in final if k.startswith(('gateway_read_', 'gateway_receive_'))}
            audit_check(final['manifest'].get('garbage', []) == [] and final['retired_chunk_deletes'] > 0, "final['manifest'].get('garbage', []) == [] and final['retired_chunk_deletes'] > 0", None)
            audit_check(services['do_sqlite_bytes'] == 24576, "services['do_sqlite_bytes'] == 24576", None)
            if profile.endswith('cold'):
                audit_check(events.get('gateway_read_consumed', 0) > 0, "events.get('gateway_read_consumed', 0) > 0", None)
                audit_check(events.get('gateway_receive_consumed', 0) > 0 if p != 'r15' else events.get('gateway_receive_consumed', 0) == 0, "events.get('gateway_receive_consumed', 0) > 0 if p != 'r15' else events.get('gateway_receive_consumed', 0) == 0", None)
            else:
                audit_check(events.get('gateway_read_consumed', 0) == events.get('gateway_receive_consumed', 0) == 0, "events.get('gateway_read_consumed', 0) == events.get('gateway_receive_consumed', 0) == 0", None)
            for k in ['gateway_read_errors', 'gateway_read_generation_changed', 'gateway_read_paid_discards']:
                audit_check(events.get(k, 0) == 0, 'events.get(k, 0) == 0', None)
            trials.append({'provider': p, 'profile': profile, 'sample': sample, 'warmup': sample < 0, 'actual_timed_gateway_events': events, 'fixed_workload_receipt': fixed(rs), 'first_push_receipt': rs[0]['cloudflare_workload_delta'], 'first_push_SQLite_before_after': [rs[0]['cloudflare_services_before']['do_sqlite_bytes'], rs[0]['cloudflare_services_after']['do_sqlite_bytes']], 'startup_receipt': services['by_phase']['startup'], 'all_phase_receipts': services['by_phase'], 'actual_retired_chunk_deletes': final['retired_chunk_deletes'], 'actual_final_manifest_debt': final['manifest'].get('garbage', []), 'actual_final_SQLite_bytes': services['do_sqlite_bytes'], 'actual_final_R2_live_bytes': services['r2_live_bytes'], 'actual_final_R2_peak_bytes': services['r2_peak_bytes'], 'actual_native_socket_diagnostics': final.get('native_socket_rpc'), 'actual_Worker_socket_diagnostics': services.get('socket_rpc', {})})
            if p == 'r17':
                native = final['native_socket_rpc']
                worker = services.get('socket_rpc', {})
                initial = socket(rs[0], 'before')
                last = socket(rs[-1], 'after')
                timed = collections.Counter()
                phase = collections.defaultdict(collections.Counter)
                for r in rs:
                    delta = diagdelta(socket(r, 'after'), socket(r, 'before'))
                    timed.update(delta)
                    phase[r['operation']['kind']].update(delta)
                observer = diagdelta(worker, last)
                audit_check(native['retained_reservation_bytes'] == 262144 and native['failures'] == native['unsupported_upgrades'] == 0, "native['retained_reservation_bytes'] == 262144 and native['failures'] == native['unsupported_upgrades'] == 0", None)
                audit_check(native['rpcs_completed'] == worker.get('completed_rpcs', 0) == worker.get('dispatched_rpcs', 0), "native['rpcs_completed'] == worker.get('completed_rpcs', 0) == worker.get('dispatched_rpcs', 0)", None)
                audit_check(native['upgrades_attempted'] == worker.get('upgrade_attempts', 0) == worker.get('upgrades_accepted', 0), "native['upgrades_attempted'] == worker.get('upgrade_attempts', 0) == worker.get('upgrades_accepted', 0)", None)
                audit_check(native['upgrades_attempted'] == math.ceil(native['rpcs_completed'] / 16), "native['upgrades_attempted'] == math.ceil(native['rpcs_completed'] / 16)", None)
                audit_check(native['rotations'] == native['rpcs_completed'] // 16, "native['rotations'] == native['rpcs_completed'] // 16", None)
                audit_check(native['request_rfc_frame_attempts'] == native['request_rfc_frames_written'], "native['request_rfc_frame_attempts'] == native['request_rfc_frames_written']", None)
                audit_check(native['ack_frame_attempts'] == native['ack_frames_written'] == native['rpcs_completed'], "native['ack_frame_attempts'] == native['ack_frames_written'] == native['rpcs_completed']", None)
                audit_check(native['response_binary_messages_read'] == worker.get('outgoing_messages', 0), "native['response_binary_messages_read'] == worker.get('outgoing_messages', 0)", None)
                for k in ['failed_messages', 'protocol_errors', 'transport_errors', 'stale_sessions', 'invalid_messages', 'pipelined_messages', 'error_status_rpcs', 'auth_rejected']:
                    audit_check(worker.get(k, 0) == 0, 'worker.get(k, 0) == 0', None)
                for k, v in timed.items():
                    audit_check(worker.get(k, 0) == initial.get(k, 0) + v + observer.get(k, 0), 'worker.get(k, 0) == initial.get(k, 0) + v + observer.get(k, 0)', None)
                owned_initial = final['cache_retained_bytes'] - sum((r['service_metrics_delta'].get('cache_retained_bytes', 0) for r in rs))
                audit_check(owned_initial >= 262144 and final['cache_retained_bytes'] <= 33554432, "owned_initial >= 262144 and final['cache_retained_bytes'] <= 33554432", None)
                socket_trials.append({'provider': p, 'profile': profile, 'sample': sample, 'warmup': sample < 0, 'actual_native_final': native, 'actual_Worker_final': worker, 'actual_Worker_before_first_timed_row': initial, 'actual_Worker_fixed_window_sum': dict(timed), 'actual_Worker_by_timed_kind': {k: dict(v) for k, v in phase.items()}, 'actual_Worker_after_last_timed_row_to_final_observer': observer, 'startup_phase_receipt': services['by_phase']['startup'], 'stats_phase_receipt': services['by_phase']['stats'], 'fixed_phase_receipts': {k: services['by_phase'].get(k, {}) for k in ['push', 'fetch']}, 'owning_cache_initial_gauge_from_final_anchor_and_deltas': owned_initial, 'socket_retained_reservation_bytes': 262144, 'joint_cache_cap_bytes': 33554432, 'entry_cap': 256, 'configured_frame_bounds_note': 'Native maximum_rfc_fragment_payload/maximum_response_message are configured bounds, not observed peak payload measurements. Actual frame/message/byte counters remain separate and unpriced.', 'final_snapshot_limit': 'The final receipts/diagnostics end at the runner snapshot; no absence of later ACK, close or teardown traffic is inferred.', 'billing_limit': 'Only actual Upgrades count as service Worker fetches; complete application messages dispatch one ordinary DO HTTP request each. No DO-socket ratio, frame billing multiplier or CPU estimate is applied. Final observer socket work is separate; no future-proof/GC permanence is inferred.'})
        for bp, cp in [('r15', 'r16'), ('r16', 'r17')]:
            pair_summary = []
            for a, b in zip(rows[bp], rows[cp]):
                audit_check(a['operation'] == b['operation'], "a['operation'] == b['operation']", None)
                ad = a['cloudflare_workload_delta']
                bd = b['cloudflare_workload_delta']
                delta = difference(bd, ad)
                for k in ['r2_class_a', 'r2_class_b', 'r2_deletes', 'r2_read_bytes', 'r2_written_bytes', 'do_rows_written', 'worker_gateway_requests']:
                    audit_check(delta[k] == 0, 'delta[k] == 0', (profile, sample, bp, cp, b['operation']['key'], k, delta[k]))
                if cp == 'r16':
                    consumed = b['service_metrics_delta'].get('gateway_receive_consumed', 0)
                    audit_check(delta['worker_requests'] == delta['worker_service_requests'] == delta['do_requests'] == -consumed, "delta['worker_requests'] == delta['worker_service_requests'] == delta['do_requests'] == -consumed", None)
                    diagnostics = {'gateway_receive_consumed': consumed}
                else:
                    d = diagdelta(socket(b, 'after'), socket(b, 'before'))
                    rpcs = d.get('dispatched_rpcs', 0)
                    upgrades = d.get('upgrade_attempts', 0)
                    audit_check(delta['do_requests'] == 0, "delta['do_requests'] == 0", None)
                    audit_check(delta['worker_requests'] == delta['worker_service_requests'] == upgrades - rpcs, "delta['worker_requests'] == delta['worker_service_requests'] == upgrades - rpcs", (profile, sample, b['operation']['key'], delta, d))
                    diagnostics = {'actual_Worker_socket_delta': d, 'actual_native_socket_metric_delta': b['service_metrics_delta'].get('native_socket_rpc')}
                record = {'profile': profile, 'sample': sample, 'warmup': sample < 0, 'baseline': bp, 'candidate': cp, 'operation': b['operation'], 'candidate_minus_baseline_actual_receipt': delta, 'candidate_transport_diagnostics': diagnostics, 'baseline_full_receipt': ad, 'candidate_full_receipt': bd}
                operations.append(record)
            comparisons.append({'profile': profile, 'sample': sample, 'warmup': sample < 0, 'baseline': bp, 'candidate': cp, 'baseline_fixed_receipt': fixed(rows[bp]), 'candidate_fixed_receipt': fixed(rows[cp]), 'candidate_minus_baseline_fixed_receipt': difference(fixed(rows[cp]), fixed(rows[bp]))})
save('r16-r17-trial-activation-physical-SQL-receipts.json', trials)
save('r16-r17-every-operation-physical-transport-differences.json', operations)
save('r16-r17-fixed-workload-transport-differences.json', comparisons)
save('r17-socket-upgrade-rotation-frames-cache-and-scopes.json', socket_trials)
print(json.dumps({'trial_records': len(trials), 'adjacent_operation_comparison_receipts': len(operations), 'socket_trials': len(socket_trials)}))
save('transport-activation-checks.json',{'checks_inspected':AUDIT_CHECK_COUNT,'failed_checks':AUDIT_CHECK_FAILURES,'scope':'Topology/physical-parity diagnostics only. Deviations are retained, never used to discard valid raw reports or force a cost-envelope result.'})
print(json.dumps({'transport_checks_inspected':AUDIT_CHECK_COUNT,'transport_check_failures':len(AUDIT_CHECK_FAILURES)}))
