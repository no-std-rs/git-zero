# R19 docs-only ledger continuity review

**NOT APPROVED:** ledger `d5653fc9854aad600aba6b1b6a125f7ccd0d69fe`. One blocking inventory-scope finding remains. Exact SOURCE `f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5` keeps its prior approval; this finding does not concern production source or runtime correctness.

The clean ledger has the exact approved SOURCE as parent and changes nine files only under the R19 candidate documentation folder. Native tree `521d427a056711a58b757c9e52f3d5e047937f92` and Worker tree `7f41db4407963ed04e6cbe19556b1416633caf18` remain unchanged. I performed offline reads/hashing/source-blob comparison only, with no builds, runtimes, tests, benchmarks, delegates, source/docs edits, pushes, CI, deployment or primary-worktree work. Only these review artifacts were written in `/tmp`.

## Blocking finding

The full-local inventory and published ledger explicitly claim that actual named ELFs/runtimes are included. **None of the seven actual file paths from `git-zero-multi-chunk-runtime-files.json` occurs among the5,128 full-inventory file records.** Only the JSON inventory-of-runtime-identities is included. The absent records total350,554,053B. All seven actual files exist, and I independently streamed each and verified its current SHA/size against the runtime identity record:

| Missing actual file | Bytes | SHA256 |
| --- | ---: | --- |
| /tmp/git-zero-multi-chunk-target-j2/debug/repository-host | 33988800 | `c6cd4d907f2614f0113eb805a9a0001f57e7e71dd057eb29b61eaf25c19b6e73` |
| /tmp/git-zero-multi-chunk-target-j2/debug/deps/multi_chunk_cloudflare-dcddae24be8f3d8c | 37207296 | `41e0f2d4f8695250a5824e61d1f313a1d43d84bfc9e90256a297c0e9ab999b4d` |
| /home/pawel/.local/bin/node | 129491456 | `141542ec0c8f73b568cd774ea8df43f23768cb086eb5bf21d2dea33072fb2f56` |
| /tmp/git-zero-hosting-fused-retirement/examples/repository-host/cloudflare/node_modules/wrangler/bin/wrangler.js | 3088 | `780661a508810f3b65786895b1ca9aacbc4f55d329ae6b8c1e49ec8433569f77` |
| /tmp/git-zero-hosting-fused-retirement/examples/repository-host/cloudflare/node_modules/wrangler/wrangler-dist/cli.js | 15017387 | `31866b9a3686777254819158e60ebe4920d1d91141cde68846c62b52f75d7a66` |
| /tmp/git-zero-hosting-fused-retirement/examples/repository-host/cloudflare/node_modules/workerd/bin/workerd | 5770 | `373ae419539ba6ea40e5d89aec00a6b33ea6894e37e50ed3ff55c281602bde64` |
| /tmp/git-zero-hosting-fused-retirement/examples/repository-host/cloudflare/node_modules/@cloudflare/workerd-linux-64/bin/workerd | 134840256 | `3ee1cc5b09497de8f47f513b5c5c485da99a9fc8b188b5618cb05de63f3b4b64` |

The ledger/handoff statement “actual named ELFs/runtimes are included” and the requested full scope therefore fail. Add the seven actual identities to the full inventory, retain their binary payloads locally, regenerate the capsule/ledger/checksums/publication identities, and seal a new clean docs-only commit with exact SOURCE parent f124. The original source review and its signed-by-SHA scoped inventory must remain byte-exact. If no other scope changes, the corrected inventory would have5,135 files/6,817,612,457 logical B; any added historical-publication artifacts must be counted explicitly. No binary-payload publication is required by this fix.

ROOT accepted this finding and will perform the docs-only correction. This report and verifier are preserved as historical blocked d565 artifacts. No R19 integration/new cloud screen is approved by this review.

## Checks that pass at d565

I freshly streamed **all5,128 listed actual files/6,467,058,404 logical B**, with before/after stat fencing, no author/prior digest reuse and no hardlink reuse. All listed SHA/size records match. Including the separately streamed seven missing runtime files, this review read5,135 actual files/6,817,612,457 logical B. The inventory SHA remains `d3e4fbdcbd7720e5165599832d3ac2cad32d9316e00ad31b0e4b7f8188fbbcdd`; the error is omitted scope, not a mismatch in a listed file.

All15 attempt roots have exact recursive coverage of all5,034 retained root files/6,463,918,272 logical B, including generated Git/source/client/native/R2/SQLite children. The other94 listed files total3,140,132B and contain source/review/helper artifacts, not the seven actual runtime payload files. Compiler intermediates and unrelated tool installations remain outside scope; the named runtimes are explicitly required within it.

All nine public files equal their committed Git blobs; total1,846,714B. All eight payload checksums pass. The1,784,117B capsule SHA is `b3d6c13147672b06fabb8b6daadc73274d0c46c3783d8b08474d7b3650e52ad3`. I reread/hash-verified every one of its2,238 unique safe regular members, checked exact manifest membership (2,237 records plus the manifest), compared each member with the original actual bytes/identity, and matched all28 approved source blobs against f124 Git blobs. No absolute/traversal/duplicate/link/special members occur. All2,300 gate-root regular files/recursive logs are accounted for by2,149 archived files plus151 explicitly local-only large payload identities. Large generated Git/state/ELF raw payloads are not claimed inside this compact capsule.

The original source-review Markdown SHA `f9d63594e4ae26e97afcfdbbde7ffac0b1138b591563cf258ad1352b9212fb1a` and scoped-inventory SHA `b17e31d26393aef40e9db3f0f04126470b0a8e1484bc4faf4fd13ce5895c92cc` are unchanged locally and in their capsule copies. All2,388 original scoped records remain exact. Ten accepted before/after source/binary maps and all four first-pair maps match; Native executable prefix/full-file reconstruction continuity is unchanged. One earlier exploratory R19 observer-purpose production bug is excluded before the four accepted pairs, separately from four later driver-only failures. No after map or PASS is synthesized for the failed drivers.

The ledger's46-row/31-identical-body-pair results per profile reproduce actual ONE/MULTI GET131->47 and223->119, with mutation/storage/SQL-write parity and naturally positive latest GETs. Unknown SQL remains NULL and missing receipts remain incomplete. The38 fault rows preserve14 single-logical publication attempts/at-most-one-CAS and13 SAME-Native following pushes, required GC-before-PUT, confirmed-prune versus ambiguous-CAS/physical-debt distinction, and logical output once. Held-plan paid discard/pressure/admission changes remain1/15/8 with all paid work charged. Warm records actual startup8GET/29,619,316B and ordinary delta0. HTTP has no actual socket RPC/Upgrade/preparation or262,144B reserved transport allocation; its diagnostic advertised bound is distinct. Same-root restart starts empty, then actual8GET/29,619,316B admit6 and consume one Full token before verified reads. These claims remain byte-continuous with the approved source evidence.

The actual32MiB/256-entry owning budget includes the pool and required control state. The17MiB later-chunk admission ceiling/15MiB unallocated heuristic is explicit and does not become an owned reservation or14MiB response cap. The147,872,971B global transient/test-harness peak is not relabeled as a32MiB process/RSS bound. The$0.12168 model stays conditional, unconditional net lower bound remains0 and full bill remains NULL. No priced benchmark, speed/resource acceptance, plateau or stopping claim is made. Fresh independent measurement and final five original/final pairs remain separate.

Verification data, independently computed per-file/member identities, exact scope counts and limits are in `/tmp/git-zero-multi-chunk-ledger-verification.json`. Immutable historical copies use suffix `-d5653fc9854a`.
