"""Offline raw-file/counter review only; never starts or changes a workload."""
from pathlib import Path
import hashlib,json,sys
size,attempt=sys.argv[1:]
roots=[Path(f'/tmp/git-zero-multi-first{size}-{mode}-{attempt}') for mode in ['one','multi']]
contracts=[json.loads((root/'contract.json').read_text()) for root in roots]
source=[json.loads((root/'source-before.json').read_text()) for root in roots]
assert source[0]==source[1]
for root,expected in zip(roots,source): assert expected==json.loads((root/'source-after.json').read_text())
assert len(contracts[0]['rows'])==len(contracts[1]['rows'])
checks=[];responses=[]
for index,(a,b) in enumerate(zip(contracts[0]['rows'],contracts[1]['rows'])):
 name=a.get('name',a.get('kind'));assert name==b.get('name',b.get('kind'))
 for phase in ['before','after']:
  aa=a[phase]['cloudflare_services'];bb=b[phase]['cloudflare_services']
  for key in ['r2_written_bytes','r2_deletes','r2_live_objects','r2_live_bytes','r2_peak_bytes','do_rows_written','do_sqlite_bytes','manifest_generation','manifest_bytes']:
   assert aa[key]==bb[key],(index,phase,key,aa[key],bb[key])
  for operation in ['r2_put','r2_delete','r2_list','r2_head','manifest_cas']:
   assert aa['operations'].get(operation)==bb['operations'].get(operation),(index,phase,operation)
  for v in [a[phase],b[phase]]:
   assert v['cloudflare_services']['accounting_complete'] is True
   assert v['cloudflare_services']['accounting_errors']==[]
   assert v['cache_retained_bytes']<=33554432 and v['joint_cache_retained_peak_bytes']<=33554432 and v['joint_cache_entries']<=256
   assert v['protected_chunk_entries']<=32
 if 'response_sha256' in a:
  path_name=a.get('name','thin-receive')+'.body';raw=[(root/path_name).read_bytes() for root in roots]
  assert raw[0]==raw[1]
  digest=hashlib.sha256(raw[0]).hexdigest();assert digest==a['response_sha256']==b['response_sha256']
  if 'response_bytes' in a:assert len(raw[0])==a['response_bytes']==b['response_bytes']
  responses.append({'row':index,'name':path_name,'bytes':len(raw[0]),'sha256':digest})
 if name and str(name).startswith('latest-') and str(name)[7:].isdigit():
  assert a['gets']>0 and b['gets']>0,(index,'natural latest misses')
 checks.append({'row':index,'name':name,'storage_and_mutation_operation_parity':True})
totals=[]
for c in contracts:
 f=c['final'];u=f['cloudflare_services'];totals.append({'mode':c['mode'],'GET':u['r2_class_b'],'read_bytes':u['r2_read_bytes'],'Worker':u['worker_requests'],'DO':u['do_requests'],'SQLread':u['do_rows_read'],'SQLwrite':u['do_rows_written'],'admit':f['protected_chunk_admissions'],'prune':f['protected_chunk_prunes'],'reject':f['protected_chunk_rejections'],'hits':f['protected_chunk_hits'],'entries':f['protected_chunk_entries'],'owning':f['protected_chunk_owning_bytes'],'jointpeak':f['joint_cache_retained_peak_bytes']})
out=Path(f'/tmp/git-zero-multi-first{size}-paired-complete-review.json')
assert not out.exists()
out.write_text(json.dumps({'kind':'offline verification of same-source local correctness pair, not benchmark','roots':[str(root) for root in roots],'matched_rows':checks,'actual_response_files_verified':responses,'same_before_after_and_cross_mode_source_binary_maps':True,'totals':totals,'full_bill_usd':None},indent=2)+'\n')
print(json.dumps({'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'rows':len(checks),'responses':len(responses),'totals':totals},indent=2))
