"""Offline replay of archived R15 selected reads; not an execution runner."""
import pathlib,json,hashlib,collections
ROOT=pathlib.Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r13-r15-screen/run-39106495382')
CAP=16*1024*1024
def batches(xs):
    n=used=count=0
    for k,size in xs:
        if not count or used+size>CAP or count==256:n+=1;used=count=0
        used+=size;count+=1
    return n
def chunks(ps):return [(f'{p["created"]}:{i//CAP}',min(CAP,p['bytes']-i)) for p in ps for i in range(0,p['bytes'],CAP)]
class Cache:
    def __init__(self,extra):self.extra=extra;self.anchor=None;self.members={};self.stats=collections.Counter();self.history=[]
    def live(self,keys):
        for k in list(self.members):
            if k not in keys: self.stats['retired_evicted_bytes']+=self.members.pop(k);self.stats['retired_evictions']+=1
    def read(self,xs):
        missing=[(k,s)for k,s in xs if k!=self.anchor and k not in self.members]
        self.stats['GETs']+=len(missing);self.stats['GET_bytes']+=sum(s for _,s in missing);self.stats['bulk_batches']+=batches(missing)
        for k,s in missing:
            if self.anchor is None:self.anchor=k;self.anchor_size=s;self.stats['admissions']+=1;self.stats['admitted_bytes']+=s;continue
            capacity=max(0,32*1024*1024-self.anchor_size-14*1024*1024-256*1024-1024*1024)
            # Charge256B per slot conservatively inside secondary pool; exact Rust owning gate still required.
            if self.extra and len(self.members)<31 and sum(self.members.values())+s+256*(len(self.members)+1)<=capacity:
                self.members[k]=s;self.stats['admissions']+=1;self.stats['admitted_bytes']+=s
            else:self.stats['admission_rejections']+=1
        self.stats['max_secondary_payload']=max(self.stats['max_secondary_payload'],sum(self.members.values()))
        self.stats['max_chunk_entries']=max(self.stats['max_chunk_entries'],len(self.members)+(self.anchor is not None))
        return missing
out={'kind':'conditional_offline_model_not_measurement','fresh_run':39106495382,'fresh_source':'74e4b8b5cd111341043cdab04a89c047aa052cee',
 'fresh_R15_score_usd':json.loads((ROOT/'scores/r15-score.json').read_text())['known_monthly_fixed_workload_usd'],
 'policy':'One first-GET anchor plus first-fit protected secondary pool, no eviction for later admission, prune keys absent after confirmed publication; 14MiB response/1MiB other metadata/256KiB socket reservations within32MiB, max32 chunk entries counted within256.',
 'assumptions':['all selected chunk identities reconstructed as publication+index, not archived complete raw GET key sequence','all actual full/prefix read counts and bytes must reproduce','only required timed public Git GETs admit; no PUT/startup/stats/warm admission','same response hits/readsets assumed; boundary payload occupancy only, not allocation proof','no extra callback dollar savings credited'],
 'profiles':{},'full_bill':None}
for name in ['16mib-cold','64mib-cold','16mib-warm','64mib-warm']:
    path=ROOT/'profiles'/name/'r15'/f'{name}.json';doc=json.loads(path.read_text());cold=name.endswith('cold');gens={g['tip']:g['generation']for g in doc['fixture']['generations']};samples=[]
    for sample in [0,1]:
        rows=[r for r in doc['raw']if r['backend']=='cloudflare-local'and not r['warmup']and r['sample']==sample];assert len(rows)==88
        current=[];one=Cache(False);multi=Cache(True);fullget=fullbytes=0;latest=[];operations=[]
        for r in rows:
            op=r['operation'];g=op['generation'];selected=current
            if cold and op['group']in['history_no_haves','history_with_haves']:
                cutoff=max(gens[a]for a in [op['want'],op['have']]if a);selected=[p for p in current if p['floor']<=cutoff]
            xs=chunks(selected);rh=int(r['service_metrics_delta'].get('cloud_view_rehydrates',0))if cold else 0
            actual=r['cloudflare_workload_delta'];assert rh*len(xs)==actual['r2_class_b'];assert rh*sum(s for _,s in xs)==actual['r2_read_bytes']
            fullget+=actual['r2_class_b'];fullbytes+=actual['r2_read_bytes'];m=0
            for _ in range(rh):one.read(xs);m+=len(multi.read(xs))
            if op['group']=='latest_fetch'and cold:assert m>0;latest.append(m)
            operations.append({'operation':op['key'],'rehydrates':rh,'selected':xs,'multi_misses':m})
            if op['kind']=='push':
                count=r['compaction_delta']['count'];floor=g
                if count:
                    chosen=[p for p in current if p['level']==0 and p['created']!=1];assert len(chosen)==3;floor=min(p['floor']for p in chosen);current=[p for p in current if p not in chosen]
                current.append({'created':g,'floor':floor,'level':int(bool(count)),'bytes':actual['r2_written_bytes']});multi.live({k for k,s in chunks(current)})
                assert len(chunks(current))==r['cloudflare_services_after']['r2_live_objects']
        run=next(r for r in doc['cloudflare_runs']if not r['warmup']and r['sample']==sample)
        assert [p['bytes']for p in current]==[p['pack_bytes']+p['index_bytes']for p in run['final_object_stats']['manifest']['packs']]
        maxresponse=max(r.get('server_cache_after_fetch',{}).get('resident_bytes',0)for r in rows)
        maxentries=max(r.get('server_cache_after_fetch',{}).get('entries',0)for r in rows)
        assert maxresponse<14*1024*1024
        samples.append({'sample':sample,'actual_GETs':fullget,'actual_GET_bytes':fullbytes,'one':dict(one.stats),'multi':dict(multi.stats),
          'additional_GETs_avoided':one.stats['GETs']-multi.stats['GETs'],'additional_GET_bytes_avoided':one.stats['GET_bytes']-multi.stats['GET_bytes'],
          'additional_bulk_batches_avoided_before_gateway_coalescing':one.stats['bulk_batches']-multi.stats['bulk_batches'],
          'min_latest_fetch_misses':min(latest)if latest else None,'max_response_boundary_payload_bytes':maxresponse,'max_response_boundary_entries':maxentries,
          'ordered_operations':operations})
    out['profiles'][name]={'report_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'samples':samples}
saved=sum(p['samples'][0]['additional_GETs_avoided']for p in out['profiles'].values());out['conditional_additional_GETs_avoided_per_four_profiles']=saved
out['conditional_additional_ClassB_usd_at_1000repeats']=saved*.00036
out['unconditional_net_savings_lower_bound_usd']=None
out['no_positive_net_lower_bound_proved']=True
out['loose_GET_only_upper_bound_assuming_each_new_chunk_must_be_read_once']={'ONE_remaining_GETs':852,'distinct_uploaded_required_GET_chunks_at_least':66,'additional_GETs_upper_bound':786,'usd_upper_bound':786*.00036,'ignores_memory_and_response_tradeoffs':True}
dest=pathlib.Path('/tmp/git-zero-multi-chunk-next-audit.json');dest.write_text(json.dumps(out,indent=2)+'\n')
for name,p in out['profiles'].items():
 for s in p['samples']:print(name,s['sample'],{k:v for k,v in s.items()if k not in['ordered_operations']})
print('additional GETs',saved,'ClassBUSD',saved*.00036,'supportSHA256',hashlib.sha256(dest.read_bytes()).hexdigest())
