"""Offline artifact inventory/publication only. No build, runtime or benchmark."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,os,stat,subprocess,tarfile
BASE=Path('/tmp/git-zero-hosting-multi-chunk')
SOURCE='f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5'
PUB=BASE/'docs/benchmarks/hosting-cost-loop-2026-10-18/interleaved-v1/r19-multi-chunk-candidate'
assert subprocess.check_output(['git','-C',str(BASE),'rev-parse','HEAD'],text=True).strip()==SOURCE
assert not PUB.exists()
review_path=Path('/tmp/git-zero-multi-chunk-source-review-f124d3b71ce1-inventory.json')
review=json.loads(review_path.read_text());fence=review_path.stat().st_mtime_ns
trusted={r['path']:r for r in review['files']}
handoff=json.loads(Path('/tmp/git-zero-multi-chunk-source-handoff.json').read_text())
roots=[Path(r['root']) for r in handoff['gates']]
paths=set()
for root in roots:
 for p in root.rglob('*'):
  if p.is_file() or p.is_symlink():paths.add(p)
paths.update(Path(p) for p in trusted)
inputs=json.loads(Path('/tmp/git-zero-multi-chunk-ledger-inputs.json').read_text())
paths.update(Path(r['path']) for r in inputs['files'])
paths.add(Path('/tmp/git-zero-multi-chunk-ledger-inputs.json'))
paths.add(Path(__file__))
# Include owned check/driver logs and exact initial accepted source copies.
paths.update(Path('/tmp').glob('git-zero-multi-*.log'))
paths.update(p for p in Path('/tmp/git-zero-multi-first-source-files').rglob('*') if p.is_file())
files=[];identity_cache={};streamed=0;new_bytes=0;reused=0;hardlinks=0
for p in sorted(paths,key=str):
 before=p.stat(); signature=(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)
 old=trusted.get(str(p));method='streamed-SHA256'
 if old and before.st_size==old['bytes'] and before.st_ctime_ns<=fence and before.st_mtime_ns<=fence:
  digest=old['sha256'];reused+=1;method='independently-verified-SHA256-reused-size-and-ctime-mtime-fence'
 elif signature in identity_cache:
  digest=identity_cache[signature];hardlinks+=1;method='same-unchanged-hardlink-inode-as-streamed-or-verified-record'
 else:
  h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
  digest=h.hexdigest();streamed+=1;new_bytes+=before.st_size
 after=p.stat();assert signature==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),str(p)
 identity_cache[signature]=digest
 record={'path':str(p),'bytes':before.st_size,'sha256':digest,'stat':{'device':before.st_dev,'inode':before.st_ino,'mtime_ns':before.st_mtime_ns,'ctime_ns':before.st_ctime_ns,'mode':stat.S_IMODE(before.st_mode)},'verification':method}
 if p.is_symlink():record['symlink_target']=os.readlink(p)
 files.append(record)
full={'kind':'complete immutable local R19 evidence inventory, including ALL generated fixture/state children in all15 attempt roots','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':SOURCE,'roots':[str(p) for p in roots],'scope':'all recursively retained files in all15 attempt roots (including generated Git/source/client/native and R2/SQLite persistence), all prior2388 scoped source/runtime/review records, exact prep/design/check/helper files','excluded':'compiler intermediates and unrelated tool installation files; actual named runtimes/ELFs are inventoried; this inventory and later publication derivatives exclude themselves to avoid recursive digests','prior_independent_inventory':{'path':str(review_path),'sha256':hashlib.sha256(review_path.read_bytes()).hexdigest(),'metadata_fence_mtime_ns':fence},'reuse_rule':'exact size plus mtime and Linux ctime no later than completed independent verification; fresh stat checked before/after, otherwise stream file once; unchanged identical hardlink inode can share computed digest','file_count':len(files),'logical_bytes':sum(r['bytes'] for r in files),'new_streamed_files':streamed,'new_streamed_bytes':new_bytes,'independent_hashes_reused':reused,'hardlink_hashes_reused':hardlinks,'files':files,'all_large_payloads_local_only_unless_explicit_capsule_member':True}
p=Path('/tmp/git-zero-multi-chunk-full-local-inventory.json');p.write_text(json.dumps(full,indent=2)+'\n')
print(json.dumps({'phase':'full-inventory-complete','files':len(files),'logical_bytes':full['logical_bytes'],'streamed_files':streamed,'streamed_bytes':new_bytes,'verified_hashes_reused':reused,'hardlinks_reused':hardlinks,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
# Publication starts only after immutable inventory completion.
PUB.mkdir(parents=True)
by_path={r['path']:r for r in files}
entries={};exclusions=[]
def add(path,name,category):
 path=Path(path);assert name not in entries
 raw=path.read_bytes();record=by_path.get(str(path))
 if record:assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256'],str(path)
 entries[name]={'data':raw,'original_path':str(path),'category':category}
for root in roots:
 for path in sorted(root.iterdir()):
  if not path.is_file():continue
  is_payload=path.suffix in ['.body','.request']
  raw=None
  if is_payload and path.stat().st_size>65536:
   is_json=False
   if path.stat().st_size<=2*1024*1024:
    try:json.loads(path.read_text());is_json=True
    except (UnicodeDecodeError,json.JSONDecodeError):pass
   if not is_json:
    exclusions.append({'path':str(path),'reason':'large Git request/response payload local-only','bytes':by_path[str(path)]['bytes'],'sha256':by_path[str(path)]['sha256']});continue
  add(path,'attempts/'+root.name+'/'+path.name,'raw-gate-root-evidence')
 if (root/'logs').exists():
  for path in sorted((root/'logs').rglob('*')):
   if path.is_file():add(path,'attempts/'+root.name+'/'+str(path.relative_to(root)),'runtime-log')
for record in inputs['files']:
 path=Path(record['path']);add(path,'provenance/'+path.name,'design-source-review-handoff-provenance')
add(Path('/tmp/git-zero-multi-chunk-ledger-inputs.json'),'provenance/git-zero-multi-chunk-ledger-inputs.json','frozen-input-identities')
add(Path(__file__),'provenance/'+Path(__file__).name,'offline-publication-script')
for path in sorted(Path('/tmp').glob('git-zero-multi-*.log')):add(path,'checks/'+path.name,'driver-and-check-log')
for path in sorted(Path('/tmp/git-zero-multi-first-source-files').rglob('*')):
 if path.is_file():add(path,'source/accepted-first-four/'+str(path.relative_to('/tmp/git-zero-multi-first-source-files')),'exact-first-accepted-source')
for rel in ['examples/repository-host/src','examples/repository-host/cloudflare/src']:
 for path in sorted((BASE/rel).rglob('*')):
  if path.is_file():add(path,'source/'+SOURCE+'/'+str(path.relative_to(BASE)),'exact-approved-source')
add(BASE/'examples/repository-host/tests/multi_chunk_cloudflare.rs','source/'+SOURCE+'/examples/repository-host/tests/multi_chunk_cloudflare.rs','exact-approved-Rust-runner')
add(BASE/'Cargo.lock','source/'+SOURCE+'/Cargo.lock','exact-approved-lock')
add(BASE/'examples/repository-host/Cargo.toml','source/'+SOURCE+'/examples/repository-host/Cargo.toml','exact-approved-manifest')
add(p,'provenance/full-local-inventory.json','complete-full-local-inventory')
member_records=[{'name':name,'bytes':len(e['data']),'sha256':hashlib.sha256(e['data']).hexdigest(),'original_path':e['original_path'],'category':e['category']} for name,e in sorted(entries.items())]
manifest={'kind':'exact compact-capsule member hashes; this manifest excludes itself to avoid recursive digest','source_commit':SOURCE,'members':member_records,'member_count_without_self':len(member_records),'large_gate_root_payloads_omitted':exclusions,'generated_fixture_state_policy':'all generated Git/native/R2/SQLite children are fully SHA/size-inventoried but their raw payloads are local-only, not capsule members','ELF_policy':'named actual ELF/tool runtimes are fully inventoried; raw binaries remain local-only','no_full_payload_archive_claim':True}
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();entries['CAPSULE-MANIFEST.json']={'data':manifest_bytes,'original_path':None,'category':'self-excluded-manifest'}
archive=PUB/'raw-evidence.tar.gz'
with archive.open('wb') as dest:
 with gzip.GzipFile(filename='',mode='wb',fileobj=dest,mtime=0,compresslevel=9) as zipped:
  with tarfile.open(fileobj=zipped,mode='w|') as tar:
   for name,e in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(e['data']);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(e['data']))
# Re-read every included member; no large excluded payload is rehashed here.
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(entries)
 for member in members:
  assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
  raw=tar.extractfile(member).read();assert raw==entries[member.name]['data']
assert archive.stat().st_size<4*1024*1024,archive.stat().st_size
print(json.dumps({'phase':'capsule-complete','bytes':archive.stat().st_size,'members':len(entries),'omitted_large_gate_root_payloads':len(exclusions)}),flush=True)
# Reuse approved immutable report bytes verbatim.
for source,name in [('/tmp/git-zero-multi-chunk-source-review-f124d3b71ce1.md','source-review.md'),('/tmp/git-zero-multi-chunk-independent-design-review.md','independent-design-review.md'),('/tmp/git-zero-multi-chunk-independent-design-review.json','independent-design-review.json'),('/tmp/git-zero-multi-chunk-owned-cleanup.json','cleanup.json')]:
 (PUB/name).write_bytes(Path(source).read_bytes())
def identity(path):return {'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
complete=[];nonaccepted=[]
for gate in handoff['gates']:
 item=dict(gate);root=Path(gate['root']);log=Path(str(root)+'-driver.log')
 if log.exists():
  item['driver_log']=identity(log)
  import re
  times=re.findall(r'finished in ([0-9.]+)s',log.read_text());item['test_seconds']=float(times[-1]) if times else None
 item['records']={name:identity(root/name) for name in ['source-before.json','source-after.json','contract.json','allocation-contract.json','fault-contract.json','plan-pressure-contract.json','cleanup.json'] if (root/name).exists()}
 if gate['status']=='PASS':complete.append(item)
 else:nonaccepted.append(item)
ledger={'kind':'R19 bounded MULTI verified GET-cache candidate; source-approved local correctness evidence, NOT a benchmark','status':'pending-independent-ledger-continuity-review','source_commit':SOURCE,'parent':handoff['parent'],'native_source_tree':handoff['native_source_tree'],'worker_source_tree':handoff['worker_source_tree'],'production_Worker_changed':False,'source_files_changed':5,'source_review':identity(PUB/'source-review.md'),'source_review_original_inventory':identity(review_path),'implementation':{'max_chunks':32,'max_secondaries':31,'joint_entry_limit':256,'joint_retained_bytes':33554432,'chunk_entry_bytes':16777216,'later_admission_total_chunk_owning_ceiling_bytes':17825792,'unallocated_admission_headroom_bytes':15728640,'headroom_is_not_retained_or_response_cap':True,'admission':'every already-required verified ordinary GET miss, first-fit without evicting any live cache owner','prune':'complete installed trusted winning Full publication or ordinary Full authoritative recovery only; observer/startup/projection/proposed/stale/ambiguous do not prune','anchor_after_prune':'oldest surviving resident, no allocation or replacement eviction','required_pressure':'newest secondaries then anchor, before ordinary response LRU/failure','response_entry_eligibility_bytes':16777216,'stable_Full_token_independent_of_own_admissions':True,'wire_Worker_caps_unchanged':True,'mode_controls':'off|on|one|multi; on=ONE; cold candidate default=MULTI; warm retains no pool','pressure_counter_also_counts_explicit_policy_reductions':True},'complete_accepted_gates':complete,'nonaccepted_attempt_scopes':nonaccepted,'nonaccepted_counts':{'earlier_R19_executable_policy_correction_before_all_accepted_pairs':1,'later_driver_only_failures':4,'accepted_runtime_roots':10,'total_runtime_attempts':15},'checks':handoff['checks'],'matched_correctness_pairs':{'16mib':{'GET_one':131,'GET_multi':47,'read_bytes_one':342809256,'read_bytes_multi':135422213,'rows_each':46,'actual_identical_response_pairs':31},'64mib':{'GET_one':223,'GET_multi':119,'read_bytes_one':1328932300,'read_bytes_multi':1205941859,'rows_each':46,'actual_identical_response_pairs':31},'all_four_before_after_cross_profile_source_binary_maps_equal':True,'per_state_mutation_SQLwrite_storage_Bytes_parity':True,'natural_latest_positive_GETs':True},'allocation':{'actual_first_retained_heap_delta_bytes':17365752,'conservative_joint_charge_bytes':17609588,'chunk_payload_bytes':17343308,'chunk_entries':6,'twelve_productive_response_bytes_each':16652187,'joint_retained_peak_bytes':30182041,'global_transient_request_peak_bytes':147872971,'cache_domain_not_global_process_memory':True},'held_plan':{'actual_paid_GETs':18,'actual_paid_read_bytes':180909302,'paid_discard_delta':1,'pressure_eviction_delta':15,'admission_delta':8,'all_paid_work_retained':True},'faults':{'rows':38,'publication_attempts':14,'publication_modes':13,'SAME_Native_followup_pushes':13,'unknown_SQL_NULL_not_zero':True,'missing_receipts_incomplete':True,'logical_request_input_output_once':True,'required_physical_GC_before_next_PUT':True,'confirmed_partial_delete_prune':3,'Native503_prune_delta':0,'gateway_lost_reply_after_Native_confirmed_success_distinct_from_ambiguous_Native_CAS':True},'warm_HTTP_restart':{'warm_actual_startup_GETs':8,'warm_actual_startup_read_bytes':29619316,'warm_ordinary_GET_read_delta':0,'warm_admissions':0,'HTTP_socket_RPC_Upgrade_preparation':0,'HTTP_actual_socket_retained_reservation_bytes':0,'advertised_socket_bound_is_not_actual_retention':True,'HTTP_admissions':9,'HTTP_hits':39,'same_root_restart_starts_empty':True,'restarted_prepared_receive_GETs':8,'restarted_prepared_receive_read_bytes':29619316,'restarted_prepared_receive_admissions':6,'restarted_stable_Full_tokens_consumed':1},'continuity':{'proof':identity(Path('/tmp/git-zero-multi-chunk-production-continuity.json')),'independently_verified_native_executable_prefix_including_newline_bytes':93624,'independently_verified_native_executable_prefix_sha256':'b06db24da06b4bb8249fc0b59604db02f81ec2fc7978ead063a6f8b25d8d7a42','earlier_exploratory_observer_policy_correction_NOT_in_continuity_scope':True,'later_Native_changes_trailing_cfg_test_only':True,'lib_first_read_CLI_whole_files_unchanged_after_first_pairs':True,'all_ten_accepted_Native_binary_sha256':'c6cd4d907f2614f0113eb805a9a0001f57e7e71dd057eb29b61eaf25c19b6e73','Rust_runner_versions_separately_mapped':True},'full_local_inventory':{'member':'provenance/full-local-inventory.json','identity':identity(p),'files':len(files),'logical_bytes':full['logical_bytes'],'new_streamed_files':streamed,'new_streamed_bytes':new_bytes,'independent_hashes_reused':reused,'hardlink_hashes_reused':hardlinks,'all_generated_fixture_and_R2_SQLite_state_children_included':True},'capsule':{**identity(archive),'members':len(entries),'manifest_member':'CAPSULE-MANIFEST.json','manifest_self_excluded':True,'all_members_reread':True,'large_gate_root_payloads_local_only_count':len(exclusions)},'publication_limits':{'all_large_Git_bodies_pack_fixture_state_ELF_not_published':True,'all_local_recursive_gate_files_have_SHA_size':True,'no_claim_capsule_contains_all_payload_bytes':True,'compiler_intermediates_excluded_actual_runtimes_included':True,'source_before_after_maps_and_all_failures_preserved':True},'conditional_model_only':{'additional_GETs_versus_modeled_ONE':338,'gross_ClassB_USD_per_1000_four_profile_repetitions':0.12168,'not_observed_benchmark':True,'unconditional_net_lower_bound_USD':0},'worker_cpu_ms':None,'DO_duration_GB_seconds':None,'Native_compute':None,'full_bill_USD':None,'cost_speed_resource_acceptance_promotion_plateau_stopping_claim':False,'fresh_independent_screen_required':True,'mandatory_final_five_original_R1_final_pairs_NOT_done':True,'no_build_runtime_perfbench_push_CI_deploy_in_ledger_phase':True}
(PUB/'implementation-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
(PUB/'README.md').write_text('''# R19: bounded verified GET chunk cache

Source `f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5`, parent approved R18 `f1ba8f5`.

Up to32 immutable chunks share the existing32MiB/256-entry budget. Ordinary verified GETs admit without replacing live residents; confirmed Full authority prunes, and real memory pressure can evict.

Local ONE/MULTI correctness pairs record GETs **131→47 (16MiB)** and **223→119 (64MiB)** with62 identical response pairs and matching mutation/storage totals. These are not priced benchmarks or speed results.

- [Implementation/evidence ledger](implementation-ledger.json)
- [Independent source review](source-review.md) and [design review](independent-design-review.md)
- [Compact raw evidence](raw-evidence.tar.gz), including full local SHA/size inventory
- [Publication validation](publication-validation.json) and [checksums](SHA256SUMS)

All15 attempt scopes remain explicit: ten accepted, one earlier corrected R19 source policy, and four failed drivers. Large Git/state/ELF payloads remain local-only; identities are inventoried, not claimed published.

The17MiB later chunk-admission ceiling is an unallocated heuristic, not retained memory or a14MiB response cap. Full bill remains NULL; the$0.12168 model stays conditional. Ledger review, fresh measurement and final five original/final pairs remain separate.
''')
validation={'kind':'author docs-only publication validation; independent ledger review pending','source_commit':SOURCE,'source_parent_exact':True,'source_review_hash_exact':True,'ten_accepted_maps_before_after_exact':True,'all_four_first_pair_maps_exact':True,'all15_attempts_preserved':True,'one_source_policy_correction_plus_four_driver_failures_distinguished':True,'all_capsule_members_reread':len(entries),'capsule_manifest_records':len(member_records),'manifest_self_excluded':True,'full_local_inventory_files':len(files),'full_local_inventory_logical_bytes':full['logical_bytes'],'new_streamed_files':streamed,'new_streamed_bytes':new_bytes,'independent_hashes_reused_with_metadata_fence':reused,'hardlink_hashes_reused':hardlinks,'capsule_bytes':archive.stat().st_size,'giant_excluded_payloads_not_rehashed_for_capsule':True,'source_or_tests_dependencies_caps_benchmark_fixture_runner_scorer_rates_workflows_changed_in_ledger_phase':False,'build_runtime_perfbench_push_CI_deploy_delegation_in_ledger_phase':False,'full_bill_USD':None}
(PUB/'publication-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
sums=[]
for path in sorted(PUB.iterdir()):
 if path.is_file() and path.name!='SHA256SUMS':sums.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+path.name)
(PUB/'SHA256SUMS').write_text('\n'.join(sums)+'\n')
for line in sums:
 sha,name=line.split('  ',1);assert hashlib.sha256((PUB/name).read_bytes()).hexdigest()==sha
changed=subprocess.check_output(['git','-C',str(BASE),'status','--porcelain','--untracked-files=all'],text=True)
assert all(line[3:].startswith('docs/') for line in changed.splitlines()),changed
print(json.dumps({'phase':'publication-complete','folder':str(PUB),'public_files':len(list(PUB.iterdir())),'public_total_bytes':sum(x.stat().st_size for x in PUB.iterdir()),'all_public_checksums_verified':len(sums),'ledger_sha256':hashlib.sha256((PUB/'implementation-ledger.json').read_bytes()).hexdigest()}),flush=True)
