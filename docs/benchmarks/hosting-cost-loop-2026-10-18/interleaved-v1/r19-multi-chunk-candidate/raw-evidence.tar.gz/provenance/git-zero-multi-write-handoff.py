from pathlib import Path
import datetime,hashlib,json,subprocess,shutil
base=Path('/tmp/git-zero-hosting-multi-chunk')
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
 return {'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}
def git(*args):return subprocess.check_output(['git','-C',str(base),*args],text=True).strip()
sha=git('rev-parse','HEAD');assert sha=='f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5';assert not git('status','--porcelain')
gates=[('first16-one-01','EXPLORATORY_PASS_old_R19_observer_pruning_policy_bug'),('first16-one-02','PASS'),('first16-multi-02','PASS'),('first64-one-01','PASS'),('first64-multi-01','PASS'),('allocation-01','PASS'),('faults-01','FAILED_driver_unretainable21MiB_response'),('faults-02','FAILED_driver_unpublished_have'),('faults-03','PASS'),('plan-pressure-01','FAILED_driver_client_missing_have_objects'),('plan-pressure-02','FAILED_driver_required16MiB_refill_violated_no_eviction_admission'),('plan-pressure-03','PASS'),('warm-01','PASS'),('http-01','PASS'),('restart-01','PASS')]
records=[];gate_records=[]
for suffix,status in gates:
 root=Path('/tmp/git-zero-multi-'+suffix)
 entries=[p for p in root.iterdir() if p.is_file()]
 if (root/'logs').exists():entries += [p for p in (root/'logs').rglob('*') if p.is_file()]
 records += [digest(p) for p in sorted(entries)]
 has_before=(root/'source-before.json').exists();has_after=(root/'source-after.json').exists()
 equal=json.loads((root/'source-before.json').read_text())==json.loads((root/'source-after.json').read_text()) if has_after else None
 if status in ['PASS','EXPLORATORY_PASS_old_R19_observer_pruning_policy_bug']:assert equal is True
 else:assert has_before and not has_after
 gate_records.append({'root':str(root),'status':status,'source_before_present':has_before,'source_after_present':has_after,'maps_equal':equal,'inventoried_root_regular_files_and_recursive_logs':len(entries)})
for p in sorted(Path('/tmp').glob('git-zero-multi-*.log')):records.append(digest(p))
for p in sorted(Path('/tmp/git-zero-multi-first-source-files').rglob('*')):
 if p.is_file():records.append(digest(p))
for name in ['first16-paired-review.json','first16-raw-responses-review.json','first16-paired-complete-review.json','first64-paired-complete-review.json','chunk-production-continuity.json','chunk-owned-cleanup.json','chunk-owned-fd-cleanup.json','control-driver-faults03.rs','review-pair.py','review-pair-initial.py']:
 p=Path('/tmp/git-zero-multi-'+name);records.append(digest(p))
for rel in ['examples/repository-host/src','examples/repository-host/cloudflare/src']:
 records += [digest(p) for p in sorted((base/rel).rglob('*')) if p.is_file()]
records += [digest(base/'examples/repository-host/tests/multi_chunk_cloudflare.rs'),digest(base/'Cargo.lock'),digest(base/'examples/repository-host/Cargo.toml')]
# Only current named runtime executables remain present. Earlier overwritten
# binaries are represented by their original maps, never asserted present.
runtime_paths=[Path('/tmp/git-zero-multi-chunk-target-j2/debug/repository-host'),Path('/tmp/git-zero-multi-chunk-target-j2/debug/deps/multi_chunk_cloudflare-dcddae24be8f3d8c'),Path(shutil.which('node'))]
prior=json.loads(Path('/tmp/git-zero-protected-runtime-files.json').read_text())
runtime_paths += [Path(x['invoked_path']) for x in prior['files'] if 'node' not in Path(x['invoked_path']).name]
runtimes=[]
for p in runtime_paths:
 if not any(x['path']==str(p) for x in runtimes):
  r=digest(p);r['resolved_path']=str(p.resolve());runtimes.append(r)
runtime_json=Path('/tmp/git-zero-multi-chunk-runtime-files.json');runtime_json.write_text(json.dumps({'kind':'post-gate current runtime inventory; not a fabricated before-run snapshot','files':runtimes},indent=2)+'\n')
records.append(digest(runtime_json))
inventory=Path('/tmp/git-zero-multi-chunk-evidence-inventory.json');inventory.write_text(json.dumps({'scope':'all15 gate root regular files plus recursive Wrangler logs, exact current production sources, first-gate source copies, named review/check logs and post-gate runtimes','excluded':'generated fixture Git repositories, native codec roots, mutable R2/SQLite persistence and other generated child directories remain locally retained but are NOT exhaustively inventoried here; full Git response bodies at gate roots ARE hashed and retained locally','files':records,'file_count':len(records),'logical_bytes':sum(x['bytes'] for x in records),'not_all_payloads_published':True},indent=2)+'\n')
md=Path('/tmp/git-zero-multi-chunk-source-handoff.md')
md.write_text('''# R19 clean source handoff

**STOP for independent exact-source review.** Clean SOURCE `f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5`, parent exact approved R18 `f1ba8f548507dca1e5ab78e5c5d20d8360ecee21`, branch `perf/hosting-multi-chunk`, worktree `/tmp/git-zero-hosting-multi-chunk`. NativeSRC `521d427a056711a58b757c9e52f3d5e047937f92`; WorkerSRC unchanged `7f41db4407963ed04e6cbe19556b1416633caf18`. Five committed files, no dependency, Worker, schema/rate, benchmark fixture, runner, scorer or workflow change. No push, primary edit, CI, deployment or delegation.

One anchor and insertion-ordered protected secondaries share the existing32MiB retained owning budget and256 joint entries, maximum32 chunks. Only already-required ordinary verified GETs can admit; the synchronous visitor considers every miss without a32-candidate prefix truncation. New admission never evicts a live cache owner. Complete confirmed Full authority can prune unreachable descriptors and promote the oldest survivor; proposed/stale/ambiguous publication and projections cannot prune. Required response/control ownership evicts newest secondary then anchor. The unallocated15MiB secondary admission headroom is a heuristic, never an owned reservation or hard14MiB response cap. <=16MiB responses remain eligible under actual budget. Off/on/one/multi are generic controls; on retains ONE semantics, candidate default is MULTI. Warm retains no chunk pool.

The authenticated digest binds selected order and the exact cached/missing partition while the one-use Full receive token stays independent of legitimate admissions/pruning. All paid bytes verify before files. All-cache uses existing ordinary fresh authority, with no fabricated empty bulk proof. Existing receiving/quarantine/thin validation, strict receipts, publication sync, retirement and uncertain physical GC-before-next-PUT remain intact.

| Accepted same-source local pair | Actual GET ONE → MULTI | Read bytes ONE → MULTI | Actual response pairs |
| --- | ---: | ---: | ---: |
|16MiB|131 →47|342,809,256 →135,422,213|31|
|64MiB|223 →119|1,328,932,300 →1,205,941,859|31|

All four source/binary maps match exactly before/after/across profiles;46 rows per mode/profile preserve per-state actual PUT/DELETE/LIST/CAS, written/live/peak bytes/objects, SQL writes/SQLite and logical bodies. Latest reads after ordinary pushes naturally GET new data. The fixtures include three real large replacements, middle historical refs with/without seeded haves, latest rechecks and independently proven external-base thin receiving.16MiB Worker164/SQLR220/SQLW26 stay equal, DO192→183;64MiB Worker168→167/DO248→234/SQLR255→234, SQLW32 equal. These are correctness traces, not priced benchmarks or speed results.

Accepted roots: `/tmp/git-zero-multi-first16-{one,multi}-02`, `/tmp/git-zero-multi-first64-{one,multi}-01`. Complete offline reviews are `/tmp/git-zero-multi-first16-paired-complete-review.json` SHA `dcdbc869585cfe5f7d057890860da396e10cb07c8d0858b084694506ae545d15` and `/tmp/git-zero-multi-first64-paired-complete-review.json` SHA `e33ad5a78d956e5d36466e504a459e8c1928b930b1b212f8cdfaf3f3d6335bb9`. Earlier narrower16 review `9a2975ab...` and raw-response supplement remain unchanged and explicitly superseded in scope, not erased.

Counted allocation `/tmp/git-zero-multi-allocation-01` PASS78.28s: fresh64 startup admits0; actual first retained heap delta17,365,752B versus conservative cache-domain charge17,609,588B, including6 chunk owners/17,343,308 payload B. Twelve genuine16,652,187B productive responses (>14MiB and <=16MiB) remain retainable and force real bounded pool eviction/refill. Maximum retained-domain high-water30,182,041B. The budget is retained cache-domain ownership, not all process/transient heap; later global allocator values include audit Values. Original allocation fields/request peaks are retained without relabeling them. Max32/joint256/order and observer full-recovery purpose have meaningful unit controls.

Faults `/tmp/git-zero-multi-faults-03` PASS131.68s:38 actual rows cover real external-base thin preparation, ten read/continuation failures/races, thirteen publication/socket modes and following distinct pushes on the SAME Native with required physical GC before PUT. Unknown SQL stays NULL, incomplete receipts stay incomplete/NULL, logical request/input/output count once. Native503 cases prune0; partial-delete confirmed publication prunes3; a gateway-lost reply after confirmed Native success is distinguished from an ambiguous Native CAS. Ordinary observers retain admissions/prunes unchanged. Raw fault-contract SHA `50de1bef57403cadb9716e0e3be84888f42529e022d790f3fd39fed16b4537fe`.

Held plan `/tmp/git-zero-multi-plan-pressure-03` PASS70.22s: actual valid-client seeded request and published historical want, real large-response pressure during a signed first-missing plan, then paid discard+1, pressure eviction+15, admission+8 and productive verified fallback. All18 actual GET/180,909,302 read B remain charged. Contract SHA `20719a1786ea881acf0f181875c75cc382194df1fa084540d465ddfab3b47a0d`.

Warm `/tmp/git-zero-multi-warm-01` PASS28.16s: zero pool ownership/admission and no payload GET after actual startup. Ordinary HTTP `/tmp/git-zero-multi-http-01` PASS27.96s: private preparation/socket RPC/Upgrade0, productive pool admissions9/hits39. Same-root restart `/tmp/git-zero-multi-restart-01` PASS108.48s: stop/reopen the same codec root under the same Worker, fresh session starts empty, then a real prepared receive GETs8/29,619,316B, admits6 and consumes its stable Full token; verified latest/history follow. All accepted control before/after maps match.

129 library tests, final all-target Clippy(-D warnings), fmt and diff checks PASS. Logs `/tmp/git-zero-multi-library-final.log`, `/tmp/git-zero-multi-clippy-final.log`, `/tmp/git-zero-multi-fmt-final.log`, `/tmp/git-zero-multi-diff-final.log`. Exact production continuity `/tmp/git-zero-multi-chunk-production-continuity.json` SHA `03e4fbdc119e7bef37b1a062e2a3546c0eb822b2545518b20300cbb5fdee3eb6` proves accepted first-four Native executable bytes unchanged (later trailing cfg(test) only), with lib/first_read/CLI whole-file equality. Every historical Rust driver/binary version keeps its own recorded maps; binary identity is not inferred across builds. Socket diagnostics may advertise262144 as a constant while actual `socket_storage_bytes()` retention is conditional; this does not allocate or charge idle fictitious bytes.

Explicit retained exploratory/failed scopes:

- `first16-one-01` passed its old36-row trace but had a real R19 static observer-pruning policy bug. Ordinary purpose was propagated into executable recovery before ALL four accepted pairs. No continuity or accepted comparison crosses that correction; approved R18 has no inferred bug.
- `faults-01`:21,150,875B inner response was unretainable, so no actual cache change/discard; Rust driver assertion corrected. `faults-02`: old main have was no longer a published ref, so strict planner correctly returned Unsupported. `faults-03` uses a checked retained history ref. Both failed roots preserve before maps/logs/raw bodies, without invented after maps or PASS contracts.
- `plan-pressure-01`: client had not fetched its advertised newer have; strict index-pack rejected missing objects before any held plan. `plan-pressure-02`: old R18 assertion demanded16MiB refill while R19 correctly preserved the live large response and admitted only fitting chunks. Corrected driver seeds the actual client and requires a genuine nonempty bounded cached mask. Both failed roots remain complete in their original scopes.
- Early library sandbox run104/125 passed with21 loopback EPERM failures (tool transcript only); authorized network rerun exposed a new test's incorrect1-versus36 physical GET expectation (`library-01`), corrected before `library-02`127PASS. Final129PASS includes added max32/joint256/observer controls. One initial bwrap failure executed no edits/tests. Offline review script initially treated latest rechecks as mandatory misses; its old script is retained and corrected review checks only numeric latest-after-push rows. No failed runtime was discarded or labeled a plateau.

Pressure eviction diagnostics also include explicit mode-limit reduction; all gates set mode before population, so their observed pressure increments are actual required ownership/entry pressure. Reset/error evictions remain separate.

Read-only final OS checks `/tmp/git-zero-multi-chunk-owned-cleanup.json` and `...owned-fd-cleanup.json` find no owned Native/Node/workerd process, descriptor or8843/8844 listener. Unrelated services were untouched. Runtime executable inventory is explicitly post-gate, not an invented before-run snapshot. The structured handoff and scoped evidence inventory identify every included file by full SHA/size; generated Git/R2/SQLite state remains locally retained but is not claimed exhaustively archived or published. Actual Git response payloads are locally hashed/retained, not all published.

The338-GET/$0.12168 opportunity stays a conditional source/readset model, net lower bound0 until a fresh independent screen; full bill remains NULL. No cost/speed/acceptance/plateau/stopping claim. Independent exact-source approval, later ledger review and fresh measurements remain separate. STOP READY for review.
''')
handoff={'kind':'clean exact R19 SOURCE handoff, local correctness only','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':sha,'parent':git('rev-parse','HEAD^'),'branch':git('branch','--show-current'),'clean':True,'native_source_tree':git('rev-parse','HEAD:examples/repository-host/src'),'worker_source_tree':git('rev-parse','HEAD:examples/repository-host/cloudflare/src'),'production_Worker_unchanged':True,'gates':gate_records,'source_handoff_md':digest(md),'scoped_evidence_inventory':digest(inventory),'post_gate_runtime_inventory':digest(runtime_json),'checks':{name:digest(Path('/tmp/git-zero-multi-'+name)) for name in ['library-final.log','clippy-final.log','fmt-final.log','diff-final.log']},'all_129_library_tests_passed':True,'all_target_clippy_warnings_denied':True,'full_bill_usd':None,'net_cost_or_speed_claim':False,'approval_pending_independent_exact_source_review':True,'push_or_primary_or_CI_or_deployment':False,'no_delegates_or_MJS':True,'scope_limits':['No exhaustive generated Git/native/R2/SQLite fixture-state inventory claimed','Earlier overwritten binaries retain original map identities, not claimed present','Node/Wrangler/workerd executable hashes are post-gate inventory, not before/after runtime snapshots','Exploratory observer-prune executable correction precedes accepted four gates, no continuity claim across it','Existing diagnostic pressure counter includes explicit policy reductions; measured gates set policy before ownership','32MiB is retained cache-domain accounting, not global process/transient memory']}
p=Path('/tmp/git-zero-multi-chunk-source-handoff.json');p.write_text(json.dumps(handoff,indent=2)+'\n')
for p in [md,Path('/tmp/git-zero-multi-chunk-source-handoff.json'),inventory,runtime_json]:print(str(p),p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
print('scoped inventory',len(records),'files',sum(x['bytes'] for x in records),'logical bytes')
