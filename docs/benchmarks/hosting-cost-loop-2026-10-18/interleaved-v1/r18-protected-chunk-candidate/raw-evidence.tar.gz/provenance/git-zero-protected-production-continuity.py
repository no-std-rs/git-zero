from pathlib import Path
import hashlib,json,difflib
root=Path('/tmp/git-zero-hosting-protected-chunk/examples/repository-host')
bank=Path('/tmp/git-zero-protected-pre-review-source')
old_comment='''            // Even the identical existing projection is read from R2 anew on
            // every cold miss. This is selection, never an object byte cache.'''
new_comment='''            // Always reconstruct a cold miss using the verified immutable slot
            // and ordinary verified GETs for all missing selected chunks.'''
def digest(b):return hashlib.sha256(b).hexdigest()
def core(path,b):
 s=b.decode()
 if path=='src/native.rs':s=s.replace(old_comment,new_comment)
 if path in ['src/native.rs','src/lib.rs','src/storage.rs']:
  marker='#[cfg(test)]\nmod tests {'
  assert s.count(marker)==1,path
  s=s[:s.index(marker)]
 return s.encode()
versions={}
for path,names in {
 'src/native.rs':['native-first-gate.rs','native.rs'],
 'src/lib.rs':['lib.rs'],'src/storage.rs':['storage.rs']}.items():
 versions[path]={digest((bank/name).read_bytes()):(bank/name).read_bytes() for name in names}
for path in root.joinpath('src').rglob('*.rs'):
 relative=path.relative_to(root).as_posix();data=path.read_bytes();versions.setdefault(relative,{})[digest(data)]=data
proof=[]
for path,variants in versions.items():
 target=(root/path).read_bytes()
 for sha,data in variants.items():assert core(path,data)==core(path,target),('production logic changed',path,sha)
 if len(variants)>1:proof.append({'path':path,'full_file_versions':list(variants),'production_prefix_sha256':digest(core(path,target)),'excluded_scope':'trailing cfg(test) module; native additionally normalizes one exact two-line comment','unified_diff':''.join(difflib.unified_diff(next(iter(variants.values())).decode().splitlines(keepends=True),target.decode().splitlines(keepends=True),fromfile='early-exact-hash',tofile='current'))})
roots=[
 '/tmp/git-zero-protected-first-on-01',
 '/tmp/git-zero-protected-first-on-02','/tmp/git-zero-protected-first-off-02',
 '/tmp/git-zero-protected-first64-on-01','/tmp/git-zero-protected-first64-off-01',
 '/tmp/git-zero-protected-allocation-01','/tmp/git-zero-protected-allocation-02',
 '/tmp/git-zero-protected-receive-admission-01','/tmp/git-zero-protected-faults-on-01','/tmp/git-zero-protected-faults-on-02',
 '/tmp/git-zero-protected-plan-pressure-01','/tmp/git-zero-protected-warm-01','/tmp/git-zero-protected-http-ordinary-01',
 '/tmp/git-zero-protected-final-on-01','/tmp/git-zero-protected-final-off-01']
records=[]
for directory in roots:
 p=Path(directory)
 if not p.joinpath('source-before.json').exists():continue
 before=json.loads(p.joinpath('source-before.json').read_bytes());after=p.joinpath('source-after.json')
 if after.exists():assert before==json.loads(after.read_bytes()),directory
 checked=[]
 for path,record in before.items():
  if not path.startswith('src/'):continue
  assert path in versions and record['sha256'] in versions[path],(directory,path,record['sha256'])
  data=versions[path][record['sha256']];assert len(data)==record['bytes'];checked.append(path)
 records.append({'root':directory,'exact_before_sha256':digest(p.joinpath('source-before.json').read_bytes()),'exact_after_sha256':digest(after.read_bytes()) if after.exists() else None,'before_after_identical':bool(after.exists()),'production_files_checked':checked,'result_scope':'complete only when source-after/contract/cleanup exists; failed exploratory scopes retained'})
out={'kind':'exact old-source hash reconstruction and production-prefix continuity; no benchmark/scorer replay','production_logic_unchanged':True,'changes':proof,'gates':records,'runtime_inventory':'/tmp/git-zero-protected-runtime-files.json','limits':['Trailing cfg(test) modules are explicitly excluded only for production-binary logic comparison; their final tests run separately.','One exact Native explanatory comment is normalized; no executable line is normalized.','Binary identities may differ across source/test builds and remain recorded separately.','Old Native source is reconstructed only after its whole-file hash matches the original source-before map.','Recent per-key DO maps are never extrapolated across instance epochs.','Runtime executable inventory is post-gate, not fabricated pre/post verification.']}
p=Path('/tmp/git-zero-protected-production-continuity.json');p.write_text(json.dumps(out,indent=2)+'\n');print(p,p.stat().st_size,digest(p.read_bytes()))
