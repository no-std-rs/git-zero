# R18 clean source handoff

**STOP for independent exact-source review.** Clean source `f1ba8f548507dca1e5ab78e5c5d20d8360ecee21`, parent exact`c128197cc2cf1761e93832c63eec4c25c1268249`, branch`perf/hosting-protected-chunk`, worktree`/tmp/git-zero-hosting-protected-chunk`. No push, primary edit, CI, paid deployment, delegate or ledger preparation.

NativeSRC`c5b06db80540cc21a80e1ad19b4b8d1086425749`; production WorkerSRC unchanged`7f41db4407963ed04e6cbe19556b1416633caf18`. Seven committed files, no new dependency or cap change.

Final exact on/off: all four source/binary maps and11 response SHA/lengths match. Actual GET46→29/read181,926,076→38,112,638B; same Worker70/DO77/SQLR109/SQLW17, writes/deletes/live/peak/SQLite. Earlier64pair82→65GET and638,665,288→353,452,616B, DO115→98/Worker72→71/SQLR117→118, all11 bodies and write/storage guards match. These are local correctness traces, not a priced benchmark or speed result.

| Complete gate root | Seconds | Scope |
| --- | ---: | --- |
| `/tmp/git-zero-protected-first-on-02` | 38.07 | early matched16 on |
| `/tmp/git-zero-protected-first-off-02` | 45.81 | early matched16 off |
| `/tmp/git-zero-protected-first64-on-01` | 111.39 | early matched64 on |
| `/tmp/git-zero-protected-first64-off-01` | 128.94 | early matched64 off |
| `/tmp/git-zero-protected-allocation-02` | 40.63 | real full16MiB allocation, twelve near-limit response pressure/refill requests, restart |
| `/tmp/git-zero-protected-receive-admission-01` | 14.11 | restart then prepared Full receive admits without invalidating token |
| `/tmp/git-zero-protected-faults-on-02` | 166.77 | true external-base thin receive plus38 rows of read/publication/socket/recovery evidence |
| `/tmp/git-zero-protected-plan-pressure-01` | 154.04 | real slot eviction between signed first-missing plan and paid continuation |
| `/tmp/git-zero-protected-warm-01` | 39.00 | warm zero admission and zero payload GET |
| `/tmp/git-zero-protected-http-ordinary-01` | 61.97 | ordinary HTTP, preparation and sockets both off |
| `/tmp/git-zero-protected-final-on-01` | 24.92 | exact frozen source final on |
| `/tmp/git-zero-protected-final-off-01` | 39.41 | exact frozen source final off |

125 library tests and final all-target Clippy/fmt/diff checks PASS. Added review-requested direct cached-middle/noncontiguous batch tests reject empty/duplicate/reordered/foreign/length-substituted partition and foreign cached descriptor before suffix I/O. The private immutable-handle test proves no-copy Vec ownership, full capacity charge, no mutable bytes while shared, and corruption rejection before proof creation.

The real16MiB allocation retained delta is16,798,705B versus conservative charge17,041,092B. Twelve genuine16,652,188B responses force productive slot eviction/refill. Later global LIVE includes retained test audit Values; request peaks up to106,267,051B are transient.32MiB is retained cache-domain ownership, not total process memory. The in-flight case records paid discard0→1/evict1→2/admit2→3 after a real pressure request; ordinary safe reconstruction completes exact Git bytes.

The38-row fault record contains a true external-base thin prepared Full receive, ten read/continuation cases, thirteen publication/socket modes, and distinct next pushes on the SAME Native with physical GC before PUT where required. Unknown cursor values remain NULL and incomplete receipts remain incomplete. No hidden mutation retry.

Exact continuity proof: `/tmp/git-zero-protected-production-continuity.json` SHA`43a3d1afcee607ec5a97aa32fa16b4d1927dd5133ea7fc4d070bc5cfcf357dc9`. Its script hashes reconstructed early full files against original maps, then proves unchanged executable prefixes. Changes are confined to trailing cfg(test) coverage plus one exact two-line explanatory comment. Full binaries remain individually identified, never assumed identical across builds.

Runtime executable paths/hashes are in `/tmp/git-zero-protected-runtime-files.json`; this is explicitly a post-gate inventory. Final read-only OS cleanup `/tmp/git-zero-protected-owned-cleanup.json` confirms no owned Native/Node/workerd processes, file descriptors or8841/8842 listeners; unrelated demos were untouched.

Retained failed runtime attempts: initial-on01(observer LIST assertion), allocation01(HTTP-default driver omitted socket reservation), faults-on01(unknown-SQL fired-flag assertion). All were driver corrections, no production source bug. Their before maps/logs/raw state remain; no after map or PASS is synthesized. Earlier canceled wrong-target check, sandbox-loopback tests and one no-run quote syntax error remain explicitly described in the JSON/tool transcript.

No per-key counter history is extrapolated across DO epochs. Aggregate receipts and source-selected descriptors support the17 saved GETs. The156-GET/$0.05616 full-workload opportunity remains conditional, net lower bound zero until a fresh screen, and full bill NULL. No cost, performance, acceptance or stopping conclusion follows.

Full structured handoff: `/tmp/git-zero-protected-source-handoff.json`, SHA`f3cc1c51a7917d13168af0bdb9f1a3ca19d1754dcb579476febf6f7e6eca11ca`.
