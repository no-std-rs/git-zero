from pathlib import Path
import hashlib, json, subprocess, sys

ROOT = Path('/tmp/git-zero-hosting-protected-chunk')
HOST = ROOT / 'examples/repository-host'
SHA = sys.argv[1]
BASE = 'c128197cc2cf1761e93832c63eec4c25c1268249'
def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args]).decode().strip()
def digest(data):
    return hashlib.sha256(data).hexdigest()
def identity(path):
    data = Path(path).read_bytes()
    return {'path':str(path), 'bytes':len(data), 'sha256':digest(data)}
def read(path):
    return json.loads(Path(path).read_bytes())
assert git('rev-parse', 'HEAD') == SHA
assert git('rev-parse', 'HEAD^') == BASE
assert not git('status', '--porcelain')

gates = ['first-on-02','first-off-02','first64-on-01','first64-off-01',
         'allocation-02','receive-admission-01','faults-on-02',
         'plan-pressure-01','warm-01','http-ordinary-01',
         'final-on-01','final-off-01']
failed = ['first-on-01','allocation-01','faults-on-01']
inventory = {}
def include(path, category):
    path = Path(path)
    if path.is_file():
        item = inventory.setdefault(str(path), identity(path))
        item.setdefault('categories', []).append(category)

old_comment = ('            // Even the identical existing projection is read from R2 anew on\n'
               '            // every cold miss. This is selection, never an object byte cache.')
new_comment = ('            // Always reconstruct a cold miss using the verified immutable slot\n'
               '            // and ordinary verified GETs for all missing selected chunks.')
def production(rel, data):
    text = data.decode()
    if rel == 'src/native.rs':
        text = text.replace(old_comment, new_comment)
    if rel in ['src/native.rs', 'src/storage.rs', 'src/lib.rs']:
        marker = '#[cfg(test)]\nmod tests {'
        assert text.count(marker) == 1
        text = text[:text.index(marker)]
    return text.encode()

versions = {}
bank = Path('/tmp/git-zero-protected-pre-review-source')
for rel, names in {'src/native.rs':['native-first-gate.rs','native.rs'],
                   'src/lib.rs':['lib.rs'], 'src/storage.rs':['storage.rs']}.items():
    for name in names:
        p = bank/name
        b = p.read_bytes()
        versions[(rel,digest(b))] = b
        include(p, 'historical-source-exact-hash')
for p in (HOST/'src').rglob('*'):
    if p.is_file():
        rel = p.relative_to(HOST).as_posix()
        b = p.read_bytes()
        versions[(rel,digest(b))] = b
        include(p, 'frozen-source')

gate_records = []
contracts = {}
for name in gates:
    p = Path('/tmp/git-zero-protected-'+name)
    before = read(p/'source-before.json')
    after = read(p/'source-after.json')
    assert before == after, name
    assert (p/'cleanup.json').is_file(), name
    contract = read(p/('allocation-contract.json' if name == 'allocation-02' else 'contract.json'))
    assert contract['full_bill_usd'] is None
    contracts[name] = contract
    for rel, record in before.items():
        if rel.startswith('src/'):
            b = versions[(rel,record['sha256'])]
            assert len(b) == record['bytes']
            assert production(rel,b) == production(rel,(HOST/rel).read_bytes()), (name,rel)
        elif rel.startswith('cloudflare/src/') or rel in ['Cargo.toml','cloudflare/wrangler.toml']:
            b = (HOST/rel).read_bytes()
            assert digest(b) == record['sha256'] and len(b) == record['bytes'], (name,rel)
    for f in p.iterdir():
        if f.is_file(): include(f, 'complete-local-gate-'+name)
    include(Path(str(p)+'-run.log'), 'complete-local-gate-log')
    gate_records.append({'name':name,'map':before,'before_after_identical':True,
                         'contract':str(p/('allocation-contract.json' if name=='allocation-02' else 'contract.json'))})

def check_budget(v):
    if isinstance(v,dict):
        if 'cache_retained_bytes' in v:
            assert v['cache_retained_bytes'] <= 33554432
            assert v['joint_cache_retained_peak_bytes'] <= 33554432
            assert v['joint_cache_entries'] <= 256
        for x in v.values(): check_budget(x)
    elif isinstance(v,list):
        for x in v: check_budget(x)
for c in contracts.values(): check_budget(c)

pairs=[]
for size,on,off in [(16,'first-on-02','first-off-02'),
                    (64,'first64-on-01','first64-off-01'),
                    (16,'final-on-01','final-off-01')]:
    a,b=contracts[on],contracts[off]
    assert len(a['rows']) == len(b['rows']) == 18
    bodies=0
    for x,y in zip(a['rows'],b['rows']):
        assert x['name'] == y['name']
        if 'response_sha256' in x:
            bodies += 1
            assert x['response_sha256'] == y['response_sha256']
            assert x['response_bytes'] == y['response_bytes']
            for name,row in [(on,x),(off,y)]:
                raw = Path('/tmp/git-zero-protected-'+name)/(row['name']+'.body')
                assert digest(raw.read_bytes()) == row['response_sha256']
            if x['name'].startswith('latest-'): assert x['gets'] > 0
        for k in ['r2_written_bytes','r2_deletes','r2_live_objects','r2_live_bytes','do_rows_written','do_sqlite_bytes']:
            assert x['after']['cloudflare_services'][k] == y['after']['cloudflare_services'][k], (on,x['name'],k)
    fa,fb=a['final']['cloudflare_services'],b['final']['cloudflare_services']
    pairs.append({'mib':size,'on':on,'off':off,'matched_rows':18,'body_hashes_verified':bodies,
                  'gets_on':fa['r2_class_b'],'gets_off':fb['r2_class_b'],
                  'read_bytes_on':fa['r2_read_bytes'],'read_bytes_off':fb['r2_read_bytes']})

fault_root=Path('/tmp/git-zero-protected-faults-on-02')
faults=read(fault_root/'fault-contract.json')['rows']
assert len(faults)==38
fired=[]
for r in faults:
    if r['kind']=='publication attempt' and r['fired']:
        name=f"push-{r['mode']}-{r['attempt']}"
        raw=(fault_root/(name+'.body')).read_bytes()
        assert digest(raw)==r['response_sha256']
        assert r['after']['requests']-r['before']['requests']==1
        assert r['after']['input_bytes']-r['before']['input_bytes']==(fault_root/(name+'.request')).stat().st_size
        expected=r['trace']['gateway_logical_output_bytes'] if r['mode']=='gateway-lost-reply' else len(raw)
        assert r['after']['output_bytes']-r['before']['output_bytes']==expected
        assert sum(v['name']=='manifest_cas' for v in r['trace']['trace'])<=1
        fired.append({'mode':r['mode'],'status':r['status'],'logical_output_bytes':expected,'wire_body_bytes':len(raw)})
    if r['kind']=='same Native distinct next push' and r['mode'] not in ['unknown-sql','gateway-lost-reply']:
        ops=r['trace']['trace']; put=next(i for i,v in enumerate(ops) if v['name']=='r2_put')
        assert any(v['name']=='r2_list' and v['route']=='/_services/gc' for v in ops[:put]), r['mode']
assert contracts['faults-on-02']['final']['cloudflare_services']['accounting_complete'] is False
assert contracts['faults-on-02']['final']['cloudflare_services']['do_rows_read'] is None
assert contracts['warm-01']['final']['protected_chunk_admissions']==0
assert contracts['warm-01']['final']['cloudflare_services']['r2_class_b']==0
assert contracts['http-ordinary-01']['final']['gateway_read_plans']==0
assert contracts['http-ordinary-01']['final']['gateway_receive_plans']==0

for name in failed:
    p=Path('/tmp/git-zero-protected-'+name)
    assert p.exists() and not (p/'source-after.json').exists()
    for f in p.iterdir():
        if f.is_file():include(f,'failed-exploratory-'+name)
    include(Path(str(p)+'-run.log'),'failed-exploratory-log')

for rel in git('diff','--name-only',BASE,SHA).splitlines(): include(ROOT/rel,'changed-source')
for directory in [HOST/'cloudflare/src', ROOT/'crates/git-zero-core/src']:
    for p in directory.rglob('*'):
        if p.is_file():include(p,'frozen-source-input')
for rel in ['Cargo.toml','Cargo.lock','crates/git-zero-core/Cargo.toml']:
    include(ROOT/rel,'frozen-build-input')
for rel in ['Cargo.toml','cloudflare/wrangler.toml','cloudflare/test/first-read-worker.js',
            'cloudflare/test/small-receive-worker.js','cloudflare/test/socket-rpc-worker.js']:
    include(HOST/rel,'frozen-gate-input')
for p in Path('/tmp').glob('git-zero-protected-*.log'): include(p,'recorded-build-or-gate-log')
for name in ['git-zero-protected-chunk-independent-design-review.md',
             'git-zero-protected-chunk-independent-design-review.json',
             'git-zero-protected-chunk-implementation-prep.md',
             'git-zero-protected-chunk-implementation-prep.json',
             'git-zero-post-r17-next-design-audit.md',
             'git-zero-protected-production-continuity.py',
             'git-zero-protected-production-continuity.json',
             'git-zero-protected-runtime-files.json',
             'git-zero-protected-source-handoff.md',
             'git-zero-protected-source-handoff.json',
             'git-zero-protected-owned-cleanup.json']:
    include(Path('/tmp')/name,'review-input')
runtime=read('/tmp/git-zero-protected-runtime-files.json')
for item in runtime['files']:
    actual=identity(item['resolved_path'])
    assert actual['bytes']==item['bytes'] and actual['sha256']==item['sha256']
    include(item['resolved_path'],'post-gate-runtime-inventory')
final_map=read('/tmp/git-zero-protected-final-off-01/source-after.json')
for key in ['native_binary','runner_binary']:
    record=final_map[key]; actual=identity(record['path'])
    assert actual['bytes']==record['bytes'] and actual['sha256']==record['sha256']
    include(record['path'],'final-gate-binary')
include(__file__,'independent-offline-audit')
handoff=read('/tmp/git-zero-protected-source-handoff.json')
assert handoff['source_commit']==SHA and handoff['parent']==BASE and handoff['clean']
assert handoff['native_src']==git('rev-parse','HEAD:examples/repository-host/src')
assert handoff['worker_src']==git('rev-parse','HEAD:examples/repository-host/cloudflare/src')
assert not handoff['production_worker_changed']
for item in handoff['source_files']+handoff['auxiliary']:
    actual=identity(item['path'])
    assert actual['bytes']==item['bytes'] and actual['sha256']==item['sha256']
cleanup=read('/tmp/git-zero-protected-owned-cleanup.json')
assert cleanup['owned_processes']==[] and cleanup['all_owned_listeners_stopped']
listeners=[]
for table in ['tcp','tcp6']:
    for row in Path('/proc/net/'+table).read_text().splitlines()[1:]:
        fields=row.split()
        if int(fields[1].split(':')[-1],16) in [8841,8842] and fields[3]=='0A':
            listeners.append({'table':table,'row':row})
assert not listeners
include('/tmp/git-zero-protected-chunk-source-review-'+SHA[:12]+'.md','independent-source-review')
out={'kind':'independent read-only exact-source and archived-evidence audit; no runtime/build/benchmark execution',
     'source_sha':SHA,'base_sha':BASE,'clean':True,
     'decision':'APPROVED_SOURCE_ONLY',
     'independent_proc_socket_check':{'ports':[8841,8842],'listeners':listeners},
     'inventory_scope':'All changed source, Native/Worker source inputs, core-crate source, manifests, named runtime and final Native/Rust runner binaries, every top-level regular evidence file from twelve completed gates and three failed exploratory gates, and reviewed logs/documents. Mutable persistence/Git fixture/process cache directories are excluded. Earlier binary identities are recorded in gate maps; overwritten historical binaries are not claimed to remain available.',
     'pairs':pairs,'fault_rows':38,'fired_publications':fired,'gates':gate_records,
     'files':sorted(inventory.values(),key=lambda x:x['path'])}
dest=Path('/tmp/git-zero-protected-chunk-source-review-'+SHA[:12]+'-inventory.json')
dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'inventory':identity(dest),'file_count':len(inventory),'pairs':pairs,'fired_publications':len(fired)}))
