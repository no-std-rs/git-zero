"""Offline-only evidence join; no sockets, subprocesses, or requests."""
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import json

root = Path(__file__).parent
records = [json.loads(s) for s in (root/'raw/requests.jsonl').read_text().splitlines()]
traces = [json.loads(s) for s in (root/'raw/server.stderr').read_text().splitlines() if s.startswith('{')]
by_id = {parse_qs(urlsplit(t['target']).query).get('diag', [''])[0]: t for t in traces}
joined = []
for record in records:
    row = dict(record)
    c = json.loads((root/f"raw/{row['id']}.curl.json").read_text())
    row['curl'] = {k: c.get(k) for k in ('http_code','size_download','size_upload','time_connect','time_starttransfer','time_posttransfer','time_total','exitcode','errormsg')}
    t = by_id.get(row['id'])
    row['native_trace'] = t
    if t:
        durations = {}
        for label, end, start in (
            ('intake_ms','body_done_ns','read_start_ns'),
            ('handler_ms','handler_done_ns','body_done_ns'),
            ('headers_write_ms','response_headers_sent_ns','handler_done_ns'),
            ('body_write_ms','body_writes_done_ns','response_headers_sent_ns'),
            ('native_total_ms','body_writes_done_ns','accepted_ns'),
        ):
            if t.get(end) is not None and t.get(start) is not None:
                durations[label] = (t[end]-t[start])/1e6
        if t.get('body_writes_done_ns') is not None:
            durations['client_done_after_native_write_ms'] = (row['done_monotonic_ns']-t['body_writes_done_ns'])/1e6
        durations['accept_after_client_spawn_ms'] = (t['accepted_ns']-row['start_monotonic_ns'])/1e6
        row['correlation'] = durations
    joined.append(row)

summaries = []
main = [r for r in joined if 'pair' in r]
for size in sorted({r['expected_body_bytes'] for r in main}):
    for arm in ('direct','proxy'):
        group = [r for r in main if r['expected_body_bytes']==size and r['arm']==arm]
        total = [r['curl']['time_total']*1000 for r in group]
        write = [r['correlation']['body_write_ms'] for r in group]
        post_write = [r['correlation']['client_done_after_native_write_ms'] for r in group]
        summaries.append(dict(response_bytes=size,arm=arm,count=len(group),all_valid=all(r['size_status_valid'] for r in group),
            curl_total_ms_min=min(total),curl_total_ms_max=max(total),native_write_ms_max=max(write),client_done_after_write_ms_max=max(post_write)))

probes = []
for p in sorted((root/'raw').glob('status_probe*')):
    probes.append(dict(file=p.name, result=json.loads(p.read_text()) if p.suffix=='.json' else p.read_text()))
machine = dict(source_head=(root/'source-head.txt').read_text().strip(),formal_performance_measurement=False,
    lifecycle=[json.loads(s) for s in (root/'raw/lifecycle.jsonl').read_text().splitlines()],
    no_expect_response_summaries=summaries,requests=joined,status_only_probes=probes,
    caveats=['Echo buffers and aggregate instrumentation can alter pacing.', 'No response stall reproduced; retained real Git failures remain unexplained.',
             'Strip-Expect overlay passes curl only after its fallback delay; strict interim-response probe fails.',
             'No billed CPU, isolate capacity, Git correctness, or formal speedup conclusion follows.'])
(root/'results.json').write_text(json.dumps(machine,indent=2)+'\n')
for s in summaries:
    print(f"{s['response_bytes']:>9} {s['arm']:>6} n={s['count']} curl={s['curl_total_ms_min']:.3f}..{s['curl_total_ms_max']:.3f} ms native_write_max={s['native_write_ms_max']:.3f} ms after_write_max={s['client_done_after_write_ms_max']:.3f} ms")
print('probes:',json.dumps(probes))
print('controls:')
for r in joined:
    if 'control' in r:
        print(r['id'],r['curl'],r.get('correlation'))
