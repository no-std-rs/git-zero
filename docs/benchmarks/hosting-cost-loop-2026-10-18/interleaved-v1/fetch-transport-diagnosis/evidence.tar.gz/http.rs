//! Deliberately small, bounded, loopback HTTP/1.1 runner shared by both backends.
use std::collections::BTreeMap;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::Arc;
use std::time::{Duration, Instant};

pub const MAX_BODY: usize = 64 * 1024 * 1024;

#[derive(Clone)]
pub struct Request {
    pub method: String,
    pub target: String,
    pub headers: BTreeMap<String, String>,
    pub body: Vec<u8>,
}

#[derive(Clone)]
pub struct Response {
    pub status: u16,
    pub headers: BTreeMap<String, String>,
    pub body: Arc<[u8]>,
}

impl Response {
    pub fn error(status: u16, message: &str) -> Self {
        Self {
            status,
            headers: BTreeMap::from([("Content-Type".into(), "text/plain".into())]),
            body: Arc::from(message.as_bytes()),
        }
    }
}

fn line<R: BufRead>(reader: &mut R, max: usize) -> io::Result<String> {
    let mut bytes = Vec::new();
    reader
        .take((max + 1) as u64)
        .read_until(b'\n', &mut bytes)?;
    if bytes.len() > max || !bytes.ends_with(b"\r\n") {
        return Err(io::Error::other("invalid/oversized HTTP line"));
    }
    String::from_utf8(bytes).map_err(io::Error::other)
}

#[derive(Default)]
struct Trace {
    accepted_ns: u128, read_start_ns: u128, headers_done_ns: Option<u128>,
    body_done_ns: Option<u128>, handler_done_ns: Option<u128>,
    response_headers_sent_ns: Option<u128>, body_writes_done_ns: Option<u128>,
    method: String, target: String, request_body_bytes: usize,
    response_body_bytes: usize, response_wire_bytes_written: usize,
}
#[repr(C)]
struct Timespec { tv_sec: std::os::raw::c_long, tv_nsec: std::os::raw::c_long }
extern "C" { fn clock_gettime(clock: i32, ts: *mut Timespec) -> i32; }
fn stamp(_epoch: Instant) -> u128 {
    let mut ts = Timespec { tv_sec: 0, tv_nsec: 0 };
    assert_eq!(unsafe { clock_gettime(1, &mut ts) }, 0);
    ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128
}
fn read_request(stream: &mut TcpStream, trace: &mut Trace, epoch: Instant) -> io::Result<Request> {
    let mut reader = BufReader::new(stream);
    let first = line(&mut reader, 8192)?;
    let mut parts = first.split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let target = parts.next().unwrap_or("").to_string();
    if !["GET", "POST"].contains(&method.as_str()) || !target.starts_with('/') {
        return Err(io::Error::other("invalid request"));
    }
    trace.method = method.clone();
    trace.target = target.clone();
    let mut headers = BTreeMap::new();
    let mut header_bytes = first.len();
    loop {
        let header = line(&mut reader, 8192)?;
        header_bytes += header.len();
        if header_bytes > 65536 {
            return Err(io::Error::other("headers too large"));
        }
        if header == "\r\n" {
            break;
        }
        let (name, value) = header
            .split_once(':')
            .ok_or_else(|| io::Error::other("invalid header"))?;
        let key = name.to_ascii_lowercase();
        if headers.insert(key, value.trim().to_string()).is_some() {
            return Err(io::Error::other("duplicate header"));
        }
    }
    trace.headers_done_ns = Some(stamp(epoch));
    if headers.contains_key("expect") {
        reader
            .get_mut()
            .write_all(b"HTTP/1.1 100 Continue\r\n\r\n")?;
    }
    let mut body = Vec::new();
    if let Some(encoding) = headers.get("transfer-encoding") {
        if encoding != "chunked" || headers.contains_key("content-length") {
            return Err(io::Error::other("unsupported framing"));
        }
        loop {
            let length = line(&mut reader, 128)?;
            let length = usize::from_str_radix(length.trim(), 16).map_err(io::Error::other)?;
            if length == 0 {
                if line(&mut reader, 8192)? != "\r\n" {
                    return Err(io::Error::other("trailers unsupported"));
                }
                break;
            }
            if length > MAX_BODY - body.len() {
                return Err(io::Error::other("request too large"));
            }
            let start = body.len();
            body.resize(start + length, 0);
            reader.read_exact(&mut body[start..])?;
            if line(&mut reader, 2)? != "\r\n" {
                return Err(io::Error::other("invalid chunk"));
            }
        }
    } else if let Some(length) = headers.get("content-length") {
        let length: usize = length.parse().map_err(io::Error::other)?;
        if length > MAX_BODY {
            return Err(io::Error::other("request too large"));
        }
        body.resize(length, 0);
        reader.read_exact(&mut body)?;
    }
    trace.body_done_ns = Some(stamp(epoch));
    trace.request_body_bytes = body.len();
    Ok(Request {
        method,
        target,
        headers,
        body,
    })
}

pub fn serve(port: u16, mut handler: impl FnMut(Request) -> Response) -> io::Result<()> {
    serve_with_ready(port, &mut handler, |_| Ok(()))
}

pub fn serve_with_ready(
    port: u16,
    mut handler: impl FnMut(Request) -> Response,
    ready: impl FnOnce(&str) -> io::Result<()>,
) -> io::Result<()> {
    let epoch = Instant::now();
    let listener = TcpListener::bind(("127.0.0.1", port))?;
    let origin = format!("http://127.0.0.1:{}", listener.local_addr()?.port());
    ready(&origin)?;
    println!("{origin}/repo.git");
    io::stdout().flush()?;
    for stream in listener.incoming() {
        let mut trace = Trace { accepted_ns: stamp(epoch), ..Trace::default() };
        let mut stream = stream?;
        stream.set_nodelay(true)?;
        stream.set_read_timeout(Some(Duration::from_secs(30)))?;
        stream.set_write_timeout(Some(Duration::from_secs(30)))?;
        trace.read_start_ns = stamp(epoch);
        let response = match read_request(&mut stream, &mut trace, epoch) {
            Ok(request) => handler(request),
            Err(error) => Response::error(400, &error.to_string()),
        };
        trace.handler_done_ns = Some(stamp(epoch));
        trace.response_body_bytes = response.body.len();
        let mut send = |stream: &mut TcpStream| -> io::Result<()> {
            let mut headers = Vec::with_capacity(512);
            write!(
                headers,
                "HTTP/1.1 {} OK\r\nContent-Length: {}\r\nConnection: close\r\n",
                response.status,
                response.body.len()
            )?;
            for (name, value) in &response.headers {
                if !["content-length", "connection"].contains(&name.to_ascii_lowercase().as_str()) {
                    write!(headers, "{name}: {value}\r\n")?;
                }
            }
            headers.extend_from_slice(b"Cache-Control: no-store\r\n\r\n");
            let mut counted = CountedWrite { stream, bytes: 0 };
            let result = (|| -> io::Result<()> {
                counted.write_all(&headers)?;
                trace.response_headers_sent_ns = Some(stamp(epoch));
                counted.write_all(&response.body)?;
                trace.body_writes_done_ns = Some(stamp(epoch));
                Ok(())
            })();
            trace.response_wire_bytes_written = counted.bytes;
            result
        };
        // A disconnected Git client must not stop the listening server.
        let result = send(&mut stream);
        let error = result.err().map(|e| e.to_string());
        // One aggregate record per request; no headers, credentials, or body bytes.
        eprintln!("{{\"accepted_ns\":{},\"read_start_ns\":{},\"headers_done_ns\":{},\"body_done_ns\":{},\"handler_done_ns\":{},\"response_headers_sent_ns\":{},\"body_writes_done_ns\":{},\"method\":{:?},\"target\":{:?},\"request_body_bytes\":{},\"response_body_bytes\":{},\"response_wire_bytes_written\":{},\"write_error\":{}}}",
            trace.accepted_ns, trace.read_start_ns, optional(trace.headers_done_ns),
            optional(trace.body_done_ns), optional(trace.handler_done_ns),
            optional(trace.response_headers_sent_ns), optional(trace.body_writes_done_ns),
            trace.method, trace.target, trace.request_body_bytes, trace.response_body_bytes,
            trace.response_wire_bytes_written,
            error.map(|s| format!("{:?}", s)).unwrap_or_else(|| "null".into()));
    }
    Ok(())
}

fn optional(value: Option<u128>) -> String {
    value.map(|v| v.to_string()).unwrap_or_else(|| "null".into())
}
struct CountedWrite<'a> { stream: &'a mut TcpStream, bytes: usize }
impl Write for CountedWrite<'_> {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        let n = self.stream.write(buf)?; self.bytes += n; Ok(n)
    }
    fn flush(&mut self) -> io::Result<()> { self.stream.flush() }
}
