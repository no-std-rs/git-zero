# Reproduction commands

The exact exercised implementation is `driver.rs`; its source and executable were hashed before execution. It launches child processes in distinct owned process groups and runs its requests serially. It removes registrations and terminates only those groups on exit. The source file contains complete argument construction; no request or response headers/payload are logged.

Offline preparation and compilation:

```sh
cp /tmp/git-zero-hosting-cost-loop/examples/repository-host/src/http.rs /tmp/git-zero-fetch-transport-diagnosis/http.original.rs
cp /tmp/git-zero-hosting-cost-loop/examples/repository-host/cloudflare/src/index.js /tmp/git-zero-fetch-transport-diagnosis/worker.original.js
cp /tmp/git-zero-hosting-cost-loop/examples/repository-host/cloudflare/wrangler.toml /tmp/git-zero-fetch-transport-diagnosis/wrangler.original.toml
python3 /tmp/git-zero-fetch-transport-diagnosis/instrument.py
rustc --edition=2021 -O /tmp/git-zero-fetch-transport-diagnosis/server.rs -o /tmp/git-zero-fetch-transport-diagnosis/echo-server
rustc --edition=2021 -O /tmp/git-zero-fetch-transport-diagnosis/driver.rs -o /tmp/git-zero-fetch-transport-diagnosis/driver
```

Sandbox-only bind probe, failed EPERM before the authorized exercise:

```sh
/tmp/git-zero-fetch-transport-diagnosis/echo-server > /tmp/git-zero-fetch-transport-diagnosis/raw/sandbox-bind.stdout 2> /tmp/git-zero-fetch-transport-diagnosis/raw/sandbox-bind.stderr
```

Actual approved loopback command, after the independent verifier stopped:

```sh
/tmp/git-zero-fetch-transport-diagnosis/driver > /tmp/git-zero-fetch-transport-diagnosis/raw/driver.stdout 2> /tmp/git-zero-fetch-transport-diagnosis/raw/driver.stderr
```

Initial Worker child command (the overlay changes only its config pathname):

```sh
node /tmp/git-zero-hosting-fused-retirement/examples/repository-host/cloudflare/node_modules/wrangler/bin/wrangler.js dev --config /tmp/git-zero-hosting-cost-loop/examples/repository-host/cloudflare/wrangler.toml --local --ip 127.0.0.1 --port 8829 --inspector-port 0 --persist-to /tmp/git-zero-fetch-transport-diagnosis/state --log-level info
```

It runs from the diagnostic root with telemetry disabled, `XDG_CONFIG_HOME` beneath that root, and `WRANGLER_LOG_PATH` pointing into `raw/`. The overlay config is `wrangler.strip-expect.toml`. Registration uses the loopback-only local token from the frozen configuration; credentials are never printed.

Every NoExpect request is equivalent to the following with its own ID/size/timeout and the proxy prefix for the proxy arm:

```sh
curl --silent --show-error --http1.1 --noproxy '*' --connect-timeout 5 --header 'Expect:' --header 'Connection: close' --max-time 165 --header 'Content-Type: application/x-git-upload-pack-request' --data-binary @/tmp/git-zero-fetch-transport-diagnosis/request183.bin --output /dev/null --write-out '%{json}' 'http://127.0.0.1:8830/repo.git/git-upload-pack?diag=ID&bytes=34203505'
```

Expect controls use `request8543657.bin`, `bytes=4096&upload=8543657`, a maximum 30-second timeout bounded by remaining budget, and either the empty Expect override or explicit `Expect: 100-continue`. Strict interim probes are implemented directly in Rust and only record status codes/counts. The overlay source was created offline by adding exactly one forwarded-header deletion to the original copy. It is not a production change.

Offline analysis:

```sh
python3 /tmp/git-zero-fetch-transport-diagnosis/analyze.py > /tmp/git-zero-fetch-transport-diagnosis/analysis-summary.txt
```
