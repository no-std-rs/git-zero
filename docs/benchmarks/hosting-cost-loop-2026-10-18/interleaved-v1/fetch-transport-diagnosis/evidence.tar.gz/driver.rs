use std::fs::{self, File, OpenOptions};
use std::io::{self, BufRead, BufReader, Write};
use std::net::TcpStream;
use std::os::unix::process::CommandExt;
use std::process::{Child, Command, Stdio};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

const ROOT: &str = "/tmp/git-zero-fetch-transport-diagnosis";
const NAMESPACE: &str = "diag_fetch_tail_20261018_8829";
const CLI: &str = "/tmp/git-zero-hosting-fused-retirement/examples/repository-host/cloudflare/node_modules/wrangler/bin/wrangler.js";
const CONFIG: &str = "/tmp/git-zero-hosting-cost-loop/examples/repository-host/cloudflare/wrangler.toml";
fn unix_ns() -> u128 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos() }
#[repr(C)]
struct Timespec { tv_sec: std::os::raw::c_long, tv_nsec: std::os::raw::c_long }
extern "C" { fn clock_gettime(clock: i32, ts: *mut Timespec) -> i32; }
fn monotonic_ns() -> u128 {
    let mut ts = Timespec { tv_sec: 0, tv_nsec: 0 };
    assert_eq!(unsafe { clock_gettime(1, &mut ts) }, 0);
    ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128
}

struct Owned(Child);
impl Drop for Owned {
    fn drop(&mut self) {
        let group = format!("-{}", self.0.id());
        let _ = Command::new("kill").args(["-TERM", "--", &group]).status();
        for _ in 0..30 {
            if self.0.try_wait().ok().flatten().is_some() { return; }
            std::thread::sleep(Duration::from_millis(100));
        }
        let _ = Command::new("kill").args(["-KILL", "--", &group]).status();
        let _ = self.0.wait();
    }
}
fn spawn_logged(mut command: Command, name: &str) -> io::Result<Owned> {
    command.process_group(0)
        .stdin(Stdio::null())
        .stdout(File::create(format!("{ROOT}/raw/{name}.stdout"))?)
        .stderr(File::create(format!("{ROOT}/raw/{name}.stderr"))?);
    let child = command.spawn()?;
    fs::write(format!("{ROOT}/{name}.pid"), format!("{}\n", child.id()))?;
    Ok(Owned(child))
}
fn curl() -> Command {
    let mut c = Command::new("curl");
    c.args(["--silent", "--show-error", "--http1.1", "--noproxy", "*",
        "--connect-timeout", "5", "--header", "Expect:", "--header", "Connection: close"]);
    c
}
fn service(action: &str) -> io::Result<bool> {
    static SEQUENCE: AtomicUsize = AtomicUsize::new(0);
    let sequence = SEQUENCE.fetch_add(1, Ordering::Relaxed);
    let mut c = curl();
    c.args(["--max-time", "8", "--request", "POST", "--header", "Content-Type: application/json",
        "--header", &format!("x-hosting-repo: {NAMESPACE}"),
        "--header", "x-hosting-token: git-zero-local-services",
        "--data-binary", "{\"codec_origin\":\"http://127.0.0.1:8830\"}",
        "--write-out", "\n%{http_code}\n",
        &format!("http://127.0.0.1:8829/_services/{action}")]);
    let output = c.output()?;
    fs::write(format!("{ROOT}/raw/{sequence:02}-{action}.stdout"), &output.stdout)?;
    fs::write(format!("{ROOT}/raw/{sequence:02}-{action}.stderr"), &output.stderr)?;
    Ok(output.status.success() && output.stdout.ends_with(b"\n200\n"))
}
fn ready() -> io::Result<()> {
    let phase = unix_ns();
    for attempt in 0..45 {
        let output = curl().args(["--max-time", "1", "--fail", "http://127.0.0.1:8829/health"]).output()?;
        fs::write(format!("{ROOT}/raw/readiness-{phase}-{attempt:02}.stderr"), &output.stderr)?;
        if output.status.success() { return Ok(()); }
        std::thread::sleep(Duration::from_millis(500));
    }
    Err(io::Error::other("gateway readiness deadline exceeded"))
}
fn worker_command(config: &str) -> Command {
    let mut node = Command::new("node");
    node.args([CLI, "dev", "--config", config, "--local", "--ip", "127.0.0.1",
        "--port", "8829", "--inspector-port", "0", "--persist-to", &format!("{ROOT}/state"),
        "--log-level", "info"])
        .current_dir(ROOT)
        .env("CLOUDFLARE_SEND_METRICS", "false")
        .env("WRANGLER_SEND_METRICS", "false")
        .env("XDG_CONFIG_HOME", format!("{ROOT}/config"))
        .env("WRANGLER_LOG_PATH", format!("{ROOT}/raw/wrangler-cli.log"));
    node
}
fn field(json: &str, name: &str) -> Option<f64> {
    let key = format!("\"{name}\":");
    let rest = json.split_once(&key)?.1.trim_start();
    let value = rest.split([',', '}']).next()?.trim();
    value.parse().ok()
}
fn interim_probe(arm: &str, overlay: bool) -> io::Result<()> {
    let direct = arm == "direct";
    let mut stream = TcpStream::connect(("127.0.0.1", if direct { 8830 } else { 8829 }))?;
    stream.set_read_timeout(Some(Duration::from_secs(5)))?;
    stream.set_write_timeout(Some(Duration::from_secs(5)))?;
    let id = format!("status_probe_{arm}_overlay{overlay}");
    let prefix = if direct { String::new() } else { format!("/{NAMESPACE}") };
    let request = format!("POST {prefix}/repo.git/git-upload-pack?diag={id}&bytes=4096 HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Length: 183\r\nExpect: 100-continue\r\nConnection: close\r\n\r\n");
    stream.write_all(request.as_bytes())?;
    let mut reader = BufReader::new(stream);
    let mut statuses = Vec::new();
    for _ in 0..4 {
        let mut line = String::new();
        reader.read_line(&mut line)?;
        let code = line.split_whitespace().nth(1).unwrap_or("0").parse::<u16>().unwrap_or(0);
        statuses.push(code);
        for _ in 0..100 {
            line.clear();
            reader.read_line(&mut line)?;
            if line == "\r\n" || line.is_empty() { break; }
        }
        if code == 100 { reader.get_mut().write_all(&vec![b'w'; 183])?; }
        else { break; }
    }
    let body_wire_bytes = io::copy(&mut reader, &mut io::sink())?;
    // Only status codes and counts are recorded; headers and payload are discarded.
    fs::write(format!("{ROOT}/raw/{id}.json"), format!("{{\"id\":{id:?},\"status_codes\":{statuses:?},\"response_body_wire_bytes\":{body_wire_bytes}}}\n"))?;
    Ok(())
}
fn main() -> io::Result<()> {
    let epoch = Instant::now();
    let started = unix_ns();
    let mut lifecycle = File::create(format!("{ROOT}/raw/lifecycle.jsonl"))?;
    writeln!(lifecycle, "{{\"event\":\"start\",\"unix_ns\":{started},\"max_exercise_seconds\":600}}")?;
    fs::write(format!("{ROOT}/request183.bin"), vec![b'w'; 183])?;
    let mut server_cmd = Command::new(format!("{ROOT}/echo-server"));
    server_cmd.current_dir(ROOT);
    let server = spawn_logged(server_cmd, "server")?;
    let mut worker = Some(spawn_logged(worker_command(CONFIG), "wrangler")?);
    writeln!(lifecycle, "{{\"event\":\"children_spawned\",\"server_pgid\":{},\"worker_pgid\":{},\"unix_ns\":{}}}", server.0.id(), worker.as_ref().unwrap().0.id(), unix_ns())?;
    if let Err(e) = ready() {
        writeln!(lifecycle, "{{\"event\":\"readiness_failed\",\"error\":{:?}}}", e.to_string())?;
        return Err(e);
    }
    if !service("register")? { return Err(io::Error::other("registration failed")); }
    writeln!(lifecycle, "{{\"event\":\"registered\",\"unix_ns\":{}}}", unix_ns())?;
    let exercise = Instant::now();
    let mut records = File::create(format!("{ROOT}/raw/requests.jsonl"))?;
    let mut count = 0;
    let mut failed = 0;
    // Fourteen alternating pairs: eight historical-size, two small controls,
    // two 47 MB controls, and two exact newly observed 9,440,303-byte controls.
    for pair in 0..14 {
        let size = match pair { 3 | 8 => 4096, 6 | 11 => 47_000_000, 12 | 13 => 9_440_303, _ => 34_203_505 };
        let order = if pair % 2 == 0 { ["direct", "proxy"] } else { ["proxy", "direct"] };
        for arm in order {
            let remaining = 600.0 - exercise.elapsed().as_secs_f64();
            if remaining < 1.0 {
                writeln!(lifecycle, "{{\"event\":\"exercise_budget_exhausted\",\"completed\":{count}}}")?;
                break;
            }
            let id = format!("p{pair:02}_{arm}_{size}");
            let origin = if arm == "direct" { "http://127.0.0.1:8830".to_owned() }
                else { format!("http://127.0.0.1:8829/{NAMESPACE}") };
            let url = format!("{origin}/repo.git/git-upload-pack?diag={id}&bytes={size}");
            let timeout = remaining.min(165.0).to_string();
            let mut c = curl();
            c.args(["--max-time", &timeout, "--header", "Content-Type: application/x-git-upload-pack-request",
                "--data-binary", &format!("@{ROOT}/request183.bin"), "--output", "/dev/null",
                "--write-out", "%{json}", &url]);
            let request_start = unix_ns();
            let start_monotonic_ns = monotonic_ns();
            let start = Instant::now();
            let output = c.output()?;
            let request_done = unix_ns();
            let done_monotonic_ns = monotonic_ns();
            let stdout = String::from_utf8_lossy(&output.stdout);
            fs::write(format!("{ROOT}/raw/{id}.curl.json"), &output.stdout)?;
            fs::write(format!("{ROOT}/raw/{id}.curl.stderr"), &output.stderr)?;
            let valid = output.status.success() && field(&stdout, "http_code") == Some(200.0)
                && field(&stdout, "size_download") == Some(size as f64)
                && field(&stdout, "size_upload") == Some(183.0);
            if !valid { failed += 1; }
            writeln!(records, "{{\"id\":{:?},\"pair\":{pair},\"arm\":{:?},\"expected_body_bytes\":{size},\"incoming_bytes\":183,\"start_unix_ns\":{request_start},\"done_unix_ns\":{request_done},\"start_monotonic_ns\":{start_monotonic_ns},\"done_monotonic_ns\":{done_monotonic_ns},\"driver_wall_ms\":{},\"exit_code\":{},\"size_status_valid\":{valid}}}",
                id, arm, start.elapsed().as_secs_f64()*1000.0, output.status.code().unwrap_or(-1))?;
            records.flush()?;
            count += 1;
            println!("{id}: status/length valid={valid}; curl={}", stdout.trim());
        }
    }
    // Post-exercise protocol controls. Identical large request and small response;
    // retain original failures before conditionally trying the one-line overlay.
    fs::write(format!("{ROOT}/request8543657.bin"), vec![b'w'; 8_543_657])?;
    if exercise.elapsed().as_secs() < 580 {
        for arm in ["direct", "proxy"] {
            if let Err(error) = interim_probe(arm, false) {
                fs::write(format!("{ROOT}/raw/status_probe_{arm}.error"), error.to_string())?;
            }
        }
    }
    let mut control_valid = Vec::new();
    for control in 0..6 {
        if exercise.elapsed().as_secs() >= 599 { break; }
        if control == 4 {
            let original_reproduced = control_valid == [true, true, true, false];
            writeln!(lifecycle, "{{\"event\":\"expect_original_controls\",\"overlay_eligible\":{original_reproduced}}}")?;
            if !original_reproduced { break; }
            let _ = service("unregister");
            drop(worker.take());
            worker = Some(spawn_logged(worker_command(&format!("{ROOT}/wrangler.strip-expect.toml")), "wrangler-overlay")?);
            ready()?;
            if !service("register")? { return Err(io::Error::other("overlay registration failed")); }
            if let Err(error) = interim_probe("proxy", true) {
                fs::write(format!("{ROOT}/raw/status_probe_proxy_overlay.error"), error.to_string())?;
            }
        }
        let direct = control == 0 || control == 2;
        let expect = control == 2 || control == 3 || control == 5;
        let overlay = control >= 4;
        let arm = if direct { "direct" } else { "proxy" };
        let id = format!("expect_c{control}_{arm}_explicit{expect}_overlay{overlay}");
        let origin = if direct { "http://127.0.0.1:8830".to_owned() }
            else { format!("http://127.0.0.1:8829/{NAMESPACE}") };
        let url = format!("{origin}/repo.git/git-upload-pack?diag={id}&bytes=4096&upload=8543657");
        let remaining = (600.0 - exercise.elapsed().as_secs_f64()).max(0.1);
        let mut c = Command::new("curl");
        c.args(["--silent", "--show-error", "--http1.1", "--noproxy", "*", "--connect-timeout", "5",
            "--max-time", &remaining.min(30.0).to_string(), "--header", "Connection: close",
            "--header", if expect { "Expect: 100-continue" } else { "Expect:" },
            "--header", "Content-Type: application/x-git-upload-pack-request",
            "--data-binary", &format!("@{ROOT}/request8543657.bin"), "--output", "/dev/null",
            "--write-out", "%{json}", &url]);
        let start_unix_ns = unix_ns();
        let start_monotonic_ns = monotonic_ns();
        let output = c.output()?;
        let done_monotonic_ns = monotonic_ns();
        let done_unix_ns = unix_ns();
        let stdout = String::from_utf8_lossy(&output.stdout);
        fs::write(format!("{ROOT}/raw/{id}.curl.json"), &output.stdout)?;
        fs::write(format!("{ROOT}/raw/{id}.curl.stderr"), &output.stderr)?;
        let valid = output.status.success() && field(&stdout, "http_code") == Some(200.0)
            && field(&stdout, "size_download") == Some(4096.0)
            && field(&stdout, "size_upload") == Some(8_543_657.0);
        control_valid.push(valid);
        writeln!(records, "{{\"id\":{:?},\"control\":{control},\"arm\":{:?},\"explicit_expect\":{expect},\"overlay\":{overlay},\"expected_body_bytes\":4096,\"incoming_bytes\":8543657,\"start_unix_ns\":{start_unix_ns},\"done_unix_ns\":{done_unix_ns},\"start_monotonic_ns\":{start_monotonic_ns},\"done_monotonic_ns\":{done_monotonic_ns},\"exit_code\":{},\"size_status_valid\":{valid}}}", id, arm, output.status.code().unwrap_or(-1))?;
        records.flush()?;
        count += 1;
        if !valid { failed += 1; }
        println!("{id}: status/length valid={valid}; curl={}", stdout.trim());
    }
    let unregistered = service("unregister").unwrap_or(false);
    writeln!(lifecycle, "{{\"event\":\"finished\",\"requests\":{count},\"invalid\":{failed},\"unregistered\":{unregistered},\"exercise_ms\":{},\"total_ms\":{},\"unix_ns\":{}}}",
        exercise.elapsed().as_secs_f64()*1000.0, epoch.elapsed().as_secs_f64()*1000.0, unix_ns())?;
    drop(worker);
    drop(server);
    let mut cleanup = OpenOptions::new().append(true).open(format!("{ROOT}/raw/lifecycle.jsonl"))?;
    writeln!(cleanup, "{{\"event\":\"owned_process_groups_stopped\",\"unix_ns\":{}}}", unix_ns())?;
    Ok(())
}
