mod http;
use std::collections::BTreeMap;
use std::sync::Arc;

fn main() -> std::io::Result<()> {
    // Immutable buffers allocated before accept; fixed bytes and uncached responses.
    let normal: Arc<[u8]> = Arc::from(vec![0x47u8; 34_203_505]);
    let large: Arc<[u8]> = Arc::from(vec![0x47u8; 47_000_000]);
    let nine: Arc<[u8]> = Arc::from(vec![0x47u8; 9_440_303]);
    let small: Arc<[u8]> = Arc::from(vec![0x47u8; 4096]);
    http::serve(8830, move |request| {
        let _header_count = request.headers.len();
        let body = if request.target.contains("bytes=47000000") { large.clone() }
            else if request.target.contains("bytes=9440303") { nine.clone() }
            else if request.target.contains("bytes=4096") { small.clone() }
            else { normal.clone() };
        let expected_upload = if request.target.contains("upload=8543657") { 8_543_657 } else { 183 };
        if request.method != "POST" || request.body.len() != expected_upload {
            return http::Response::error(400, "diagnostic POST length mismatch");
        }
        http::Response {
            status: 200,
            headers: BTreeMap::from([("Content-Type".into(), "application/x-git-upload-pack-result".into())]),
            body,
        }
    })
}
