"""Offline-only exact-source instrumentation; this utility never sends requests."""
from pathlib import Path

root = Path(__file__).parent
source = (root / 'http.original.rs').read_text()
source = source.replace('use std::time::Duration;', 'use std::time::{Duration, Instant};')
source = source.replace('fn read_request(stream: &mut TcpStream) -> io::Result<Request> {', '''#[derive(Default)]
struct Trace {
    accepted_ns: u128, read_start_ns: u128, headers_done_ns: Option<u128>,
    body_done_ns: Option<u128>, handler_done_ns: Option<u128>,
    response_headers_sent_ns: Option<u128>, body_writes_done_ns: Option<u128>,
    method: String, target: String, request_body_bytes: usize,
    response_body_bytes: usize, response_wire_bytes_written: usize,
}
#[repr(C)]
struct Timespec { tv_sec: std::os::raw::c_long, tv_nsec: std::os::raw::c_long }
extern "C" { fn clock_gettime(clock: i32, ts: *mut Timespec) -> i32; }
fn stamp(_epoch: Instant) -> u128 {
    let mut ts = Timespec { tv_sec: 0, tv_nsec: 0 };
    assert_eq!(unsafe { clock_gettime(1, &mut ts) }, 0);
    ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128
}
fn read_request(stream: &mut TcpStream, trace: &mut Trace, epoch: Instant) -> io::Result<Request> {''')
source = source.replace('    let mut headers = BTreeMap::new();\n', '    trace.method = method.clone();\n    trace.target = target.clone();\n    let mut headers = BTreeMap::new();\n')
source = source.replace('    if headers.contains_key("expect") {', '    trace.headers_done_ns = Some(stamp(epoch));\n    if headers.contains_key("expect") {')
source = source.replace('    Ok(Request {', '    trace.body_done_ns = Some(stamp(epoch));\n    trace.request_body_bytes = body.len();\n    Ok(Request {')
source = source.replace('    let listener = TcpListener::bind', '    let epoch = Instant::now();\n    let listener = TcpListener::bind')
source = source.replace('        let mut stream = stream?;', '        let mut trace = Trace { accepted_ns: stamp(epoch), ..Trace::default() };\n        let mut stream = stream?;')
source = source.replace('        let response = match read_request(&mut stream) {', '        trace.read_start_ns = stamp(epoch);\n        let response = match read_request(&mut stream, &mut trace, epoch) {')
source = source.replace('        let send = |stream: &mut TcpStream| -> io::Result<()> {', '''        trace.handler_done_ns = Some(stamp(epoch));
        trace.response_body_bytes = response.body.len();
        let mut send = |stream: &mut TcpStream| -> io::Result<()> {''')
source = source.replace('            stream.write_all(&headers)?;\n            stream.write_all(&response.body)', '''            let mut counted = CountedWrite { stream, bytes: 0 };
            let result = (|| -> io::Result<()> {
                counted.write_all(&headers)?;
                trace.response_headers_sent_ns = Some(stamp(epoch));
                counted.write_all(&response.body)?;
                trace.body_writes_done_ns = Some(stamp(epoch));
                Ok(())
            })();
            trace.response_wire_bytes_written = counted.bytes;
            result''')
source = source.replace('        let _ = send(&mut stream);', '''        let result = send(&mut stream);
        let error = result.err().map(|e| e.to_string());
        // One aggregate record per request; no headers, credentials, or body bytes.
        eprintln!("{{\\"accepted_ns\\":{},\\"read_start_ns\\":{},\\"headers_done_ns\\":{},\\"body_done_ns\\":{},\\"handler_done_ns\\":{},\\"response_headers_sent_ns\\":{},\\"body_writes_done_ns\\":{},\\"method\\":{:?},\\"target\\":{:?},\\"request_body_bytes\\":{},\\"response_body_bytes\\":{},\\"response_wire_bytes_written\\":{},\\"write_error\\":{}}}",
            trace.accepted_ns, trace.read_start_ns, optional(trace.headers_done_ns),
            optional(trace.body_done_ns), optional(trace.handler_done_ns),
            optional(trace.response_headers_sent_ns), optional(trace.body_writes_done_ns),
            trace.method, trace.target, trace.request_body_bytes, trace.response_body_bytes,
            trace.response_wire_bytes_written,
            error.map(|s| format!("{:?}", s)).unwrap_or_else(|| "null".into()));''')
source += '''
fn optional(value: Option<u128>) -> String {
    value.map(|v| v.to_string()).unwrap_or_else(|| "null".into())
}
struct CountedWrite<'a> { stream: &'a mut TcpStream, bytes: usize }
impl Write for CountedWrite<'_> {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        let n = self.stream.write(buf)?; self.bytes += n; Ok(n)
    }
    fn flush(&mut self) -> io::Result<()> { self.stream.flush() }
}
'''
(root / 'http.rs').write_text(source)
