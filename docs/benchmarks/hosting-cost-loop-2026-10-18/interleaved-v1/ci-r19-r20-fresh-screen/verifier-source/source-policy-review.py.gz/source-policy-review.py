"""Read-only complete source identities and cache ownership policy receipts."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970')
SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
decl=json.loads((ROOT/'prospective-source-identities.json').read_text())
expected=json.loads((ROOT/'expected-source-identities.json').read_text())
def git(*args):return subprocess.check_output(['git','-C',str(SOURCE),*args])
def sha(b):return hashlib.sha256(b).hexdigest()
def manifest(commit,prefix):
    result={}
    for path in git('ls-tree','-r','--name-only',commit,'--',prefix).decode().splitlines():
        result[path]=sha(git('show',commit+':'+path))
    return result
providers={}
for label,commit in decl['provider_commits'].items():
    providers[label]={'commit':commit,'native_source_tree':git('rev-parse',commit+':examples/repository-host/src').decode().strip(),'every_native_source_file_SHA256':manifest(commit,'examples/repository-host/src')}
    assert providers[label]['native_source_tree']==decl['provider_native_source_trees'][label]
actual=manifest(decl['head'],'examples/repository-host/src')
r20=providers['r20']['every_native_source_file_SHA256']
changed=[p for p in sorted(actual.keys()|r20.keys()) if actual.get(p)!=r20.get(p)]
assert changed==['examples/repository-host/src/bin/hosting-bench.rs','examples/repository-host/src/bin/hosting-bench/failure_logs.rs'],changed
worker=manifest(decl['head'],'examples/repository-host/cloudflare/src')
assert worker==decl['common_worker_modules']
unchanged={p:v for p,v in expected['sources'].items() if p.endswith(('hosting-bench.rs','hosting-cost.rs','benchmark_cost.rs'))}
assert all(v['current_sha256']==v['prior_sha256'] for v in unchanged.values())
assert expected['pricing_source']['current_sha256']==expected['pricing_source']['prior_sha256']
review={'run_id':39128927970,'attempt':1,'head':decl['head'],'providers':providers,'common_head_native_source_manifest':actual,'head_native_differences_from_pinned_R20':changed,'difference_scope':'The independently reviewed prior 5901 error-only benchmark failure-log exporter; no successful workload, scorer or pricing change.','common_six_Worker_modules':worker,'provider_native_changed_paths':git('diff','--name-only',decl['provider_commits']['r19'],decl['provider_commits']['r20'],'--','examples/repository-host/src').decode().splitlines(),'runner_scorer_entries_unchanged':unchanged,'pricing_source':expected['pricing_source']}
review['ownership_source_policy']={
 'default':'Pinned R19 defaults to Multi; pinned R20 CLI and Cloudflare cold Native default Joint, both up to 32 chunks, warm mode Off. The compatibility boolean API still means One/off. No benchmark-specific key or workload switch.',
 'admission':'Production materialize_view_prefetched calls read_snapshot_selection_cached, snapshots the exact cached set, resolves every verified missing chunk in order, and visits every required miss through the production admit_chunk callback. The cfg(test) one-slot wrapper/helper is not the production path.',
 'no_implicit_admission':'Construction and recover clear ordinary admission; startup/observer/recovery/PUT/prewarm do not admit. Any actual startup GETs remain charged and separate.',
 'selection':'Ordered selected chunk descriptors are merged from the captured verified cached set and every verified missing GET before materialization; cached-mask identity participates in signed first-read selection. Stable Full validation survives its own admission.',
 'fallback':'Invalid/stale prepared selection causes counted paid discard and ordinary safe reconstruction. All-cache Unsupported uses ordinary dispatch. No GET, byte, DO or preparation parity or 338-model count is presumed.',
 'secondary_heuristic':'R19 Multi requires nonempty pool prospective ownership including backing growth to fit 17 MiB, leaving an unallocated 15 MiB preference. R20 Joint removes ONLY that heuristic. Both use actual 32 MiB/256-entry joint first-fit admission, up to 32 chunks, 16 MiB per chunk/response and 262144 socket reservation. Admission never replaces live owners; required pressure evicts newest secondary, then anchor, then responses. R20 is not a resident superset because different residency can induce different pressure and later misses.',
 'ownership':'metadata_bytes includes retained payload ownership, pool capacity+growth overlap, keys/headers/response ring, actual and pending certificates/history/proof and 262144 B socket reservation. Actual required pressure evicts newest secondary chunks then anchor before response LRU.',
 'pruning':'prune_protected_chunks uses only snapshot_chunks(self.manifest) after confirmed RetiringCas::Published/current Full or ordinary authoritative recovery; observer/startup recovery does not prune. Proposed, ambiguous, stale and projection states cannot establish pruning authority. Logical pruning is distinct from actual R2 retirement.',
 'freshness':'Required-GET-only admission leaves newly PUT chunks uncached; cold latest-after-push reads must retain positive actual GET+bytes. Warm ordinary payload GET remains zero.',
 'runtime_limit':'All 704 measured R20 host rows, 704 measured R19 rows and all raw warmups retain actual gauges and counters. Source owning counters are not RSS or transient request heap. Source controls do not create a missing per-key membership/attempt timeline or prove absence of future callbacks.'}
(ROOT/'whole-source-and-cache-policy-review.json').write_text(json.dumps(review,indent=2)+'\n')
prior_head='556fa3bcacb46bf7cf1f7a3c04c6b3db77c54667'
failure_module='examples/repository-host/src/bin/hosting-bench/failure_logs.rs'
assert git('show',prior_head+':'+failure_module)==git('show',decl['head']+':'+failure_module)
(ROOT/'failure-only-runner-source-audit.json').write_text(json.dumps({'head':decl['head'],'failure_only_runner_unchanged_from_prior_source':True,'new_failure_module_SHA256':sha(git('show',decl['head']+':'+failure_module)),'successful_workload_scorer_and_pricing_unchanged':True,'prior_source_comparison_only':prior_head,'old_samples_reports_scores_used':False},indent=2)+'\n')
print(json.dumps({'provider_native_source_file_counts':{p:len(v['every_native_source_file_SHA256']) for p,v in providers.items()},'common_Worker_modules':len(worker),'head_only_reviewed_diagnostic_files':changed}))
