"""Read-only fresh-run API snapshots; preserve original ZIP/tar, safe member review before extraction."""
import hashlib,json,subprocess,tarfile,zipfile,stat
from datetime import datetime,timezone,timedelta
from pathlib import Path,PurePosixPath
RUN=39128927970;HEAD='d5cdefe53fc24f34114292b7d19563e73afea293';REPO='no-std-rs/git-zero'
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970');MAX=4194304
PROFILES=['16mib-cold','16mib-warm','64mib-cold','64mib-warm']
def api(s):return subprocess.check_output(['gh','api',s],timeout=90)
def h(b):return hashlib.sha256(b).hexdigest()
def save(n,v):(ROOT/n).write_text(json.dumps(v,indent=2)+'\n')
def safe(n):
 p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and '\\' not in n and '\x00' not in n,n
 return n.removeprefix('./').rstrip('/')
def verify(d):
 ls=(d/'SHA256SUMS').read_text().splitlines();names=[]
 for line in ls:
  digest,n=line.split('  ',1);rel=safe(n);assert rel not in names;names.append(rel)
  p=d/rel;assert p.is_file() and not p.is_symlink();assert h(p.read_bytes())==digest,(p,digest)
 files={str(p.relative_to(d)) for p in d.rglob('*') if p.is_file()}
 assert files==set(names)|{'SHA256SUMS'},files-set(names)
 (d/'checksum-verification.txt').write_text(f'All {len(ls)} checksums independently verified.\n')
 return len(ls)
run=json.loads(api(f'repos/{REPO}/actions/runs/{RUN}'));assert run['id']==RUN and run['head_sha']==HEAD and run['run_attempt']==1
jobs=json.loads(api(f'repos/{REPO}/actions/runs/{RUN}/jobs'));inv=json.loads(api(f'repos/{REPO}/actions/runs/{RUN}/artifacts'))
(ROOT/'progress').mkdir(exist_ok=True);stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
save('progress/'+stamp+'-snapshot.json',{'run':run,'jobs':jobs,'artifact_index':inv})
for n,v in [('run.json',run),('jobs.json',jobs),('artifact-index.json',inv)]:save(n,v)
assert inv['total_count']<=5 and len({a['name'] for a in inv['artifacts']})==inv['total_count']
downloaded=[];transport=[]
for a in inv['artifacts']:
 assert a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==HEAD
 assert not a['expired'] and a['size_in_bytes']<=MAX
 assert datetime.fromisoformat(a['expires_at'].replace('Z','+00:00'))-datetime.fromisoformat(a['created_at'].replace('Z','+00:00'))<=timedelta(days=1,minutes=5)
 name=a['name'];assert name in ['hosting-scores-screen-1']+['hosting-screen-'+p+'-1' for p in PROFILES],name
 d=ROOT/'downloads'/name;d.mkdir(parents=True,exist_ok=True)
 zpath=d/(name+'.zip')
 if not zpath.exists():
  b=api(f'repos/{REPO}/actions/artifacts/{a["id"]}/zip');assert len(b)<=MAX
  if a.get('digest'):assert a['digest']=='sha256:'+h(b)
  zpath.write_bytes(b)
 with zipfile.ZipFile(zpath) as z:
  infos=z.infolist();assert len(infos)==1
  for i in infos:
   n=safe(i.filename);assert '/' not in n and n.endswith('.tar.gz')
   mode=i.external_attr>>16;assert not stat.S_ISLNK(mode) and (not stat.S_IFMT(mode) or stat.S_ISREG(mode))
   assert i.file_size<=MAX and not i.flag_bits&1
   b=z.read(i);assert len(b)==i.file_size
   transport.append({'artifact_id':a['id'],'artifact_name':name,'API_digest':a.get('digest'),'API_size_in_bytes':a['size_in_bytes'],'local_ZIP_path':str(zpath.relative_to(ROOT)),'ZIP_bytes':zpath.stat().st_size,'ZIP_SHA256':h(zpath.read_bytes()),'ZIP_original_preserved':True,'ZIP_publication':'local-only original transport wrapper; exact embedded tar.gz published','entry':{'name':i.filename,'uncompressed_bytes':i.file_size,'compressed_bytes':i.compress_size,'compression_type':i.compress_type,'CRC32':f'{i.CRC:08x}','flag_bits':i.flag_bits,'external_attr':i.external_attr,'embedded_exact_SHA256':h(b)}})
   archive=d/n
   if archive.exists():assert archive.read_bytes()==b
   else:archive.write_bytes(b)
 target=ROOT/'scores' if name.startswith('hosting-scores-') else ROOT/'profiles'/name.removeprefix('hosting-screen-').removesuffix('-1')
 if not (target/'checksum-verification.txt').exists():
  target.mkdir(parents=True,exist_ok=True)
  with tarfile.open(archive) as tar:
   seen=set();total=0
   for m in tar.getmembers():
    n=safe(m.name);assert n not in seen or not n;seen.add(n)
    assert m.isfile() or m.isdir(),m.name
    assert not m.issym() and not m.islnk() and not m.sparse
    assert (target/m.name).resolve().is_relative_to(target.resolve())
    assert 0<=m.size<=128*1024*1024;total+=m.size
   assert total<=512*1024*1024
   tar.extractall(target,filter='data')
  count=verify(target)
  downloaded.append({'artifact_id':a['id'],'name':name,'ZIP_bytes':zpath.stat().st_size,'ZIP_SHA256':h(zpath.read_bytes()),'tar_bytes':archive.stat().st_size,'tar_SHA256':h(archive.read_bytes()),'verified_internal_files':count})
save('transport-archive-index.json',transport)
archives=list((ROOT/'downloads').rglob('*.tar.gz'));assert len(archives)<=5 and sum(p.stat().st_size for p in archives)<=20*1024*1024
result={'run':RUN,'head':HEAD,'attempt':1,'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'active_step':next((s['name'] for s in j['steps'] if s['status']=='in_progress'),None)} for j in jobs['jobs']],'new_downloads':downloaded,'archives':len(archives),'archive_bytes':sum(p.stat().st_size for p in archives)}
save('monitor-state.json',result);print(json.dumps(result))
