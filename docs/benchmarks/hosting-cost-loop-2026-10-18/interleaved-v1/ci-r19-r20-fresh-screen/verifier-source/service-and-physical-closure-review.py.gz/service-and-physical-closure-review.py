"""Independent phase/API/count/cost closure and observed physical equivalence; fresh raw receipts only."""
import collections,json,math
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970')
PROVIDERS=['r19','r20'];PROFILES=['16mib-cold','16mib-warm','64mib-cold','64mib-warm']
checks=collections.Counter();trials=[];physical=[];categories=[];violations=[]
def save(n,v):(ROOT/n).write_text(json.dumps(v,indent=2)+'\n')
def test(ok,label,where):
 checks[label]+=1
 if not ok:violations.append({'check':label,**where})
def audit(s,keys,where):
 test(s['accounting_complete'] and not s['accounting_errors'],'receipt_complete',where)
 for k in keys:
  if k in ['worker_cpu_ms','do_gb_seconds']:
   test(s[k] is None,'unmeasured_'+k+'_remains_NULL',where);continue
  values=[v.get(k,0) for v in s['by_phase'].values()]
  test(s[k] is None if any(v is None for v in values) else s[k]==sum(values),'all_phase_sum_'+k,where)
 for phase,v in s['by_phase'].items():
  test(v['worker_requests']==sum(v.get(k,0) for k in ['worker_gateway_requests','worker_service_requests','worker_observer_requests']),'phase_Worker_category_sum',where|{'phase':phase})
 op=s['operations'];attempts=lambda n:op.get(n,{}).get('attempts',0)
 for k,names in [('r2_class_a',['r2_put','r2_list']),('r2_class_b',['r2_get','r2_head']),('r2_deletes',['r2_delete'])]:test(s[k]==sum(attempts(n) for n in names),'actual_API_classification_'+k,where)
 for key,field in [('r2_read_bytes','read_bytes'),('r2_written_bytes','written_bytes')]:test(s[key]==sum(v[field] for k,v in op.items() if k.startswith('r2_')),'actual_API_byte_sum_'+key,where)
 test(s['worker_cpu_ms'] is None and s['do_gb_seconds'] is None,'compute_unknown_preserved',where)
for profile in PROFILES:
 if not (ROOT/'profiles'/profile/'checksum-verification.txt').exists():continue
 reports={p:json.loads((ROOT/'profiles'/profile/p/f'{profile}.json').read_text()) for p in PROVIDERS}
 test(reports['r19']['fixture']==reports['r20']['fixture'],'complete_fixture_semantic_identity',{'profile':profile})
 for p,report in reports.items():
  for sample in [-1,0,1]:
   where={'profile':profile,'provider':p,'sample':sample};rs=[r for r in report['raw'] if r['backend']=='cloudflare-local' and r['sample']==sample]
   run=next(r for r in report['cloudflare_runs'] if r['sample']==sample);final=run['final_object_stats'];s=final['cloudflare_services'];keys=list(rs[0]['cloudflare_workload_delta'])
   for r in rs:
    for when in ['before','after']:audit(r['cloudflare_services_'+when],keys,where|{'operation':r['operation']['key'],'snapshot':when})
   audit(s,keys,where|{'snapshot':'final'})
   fixed={k:None if rs[0]['cloudflare_workload_delta'][k] is None else sum(r['cloudflare_workload_delta'][k] for r in rs) for k in keys}
   actual_phases={phase:{k:values.get(k,None if s[k] is None else 0) for k in keys} for phase,values in s['by_phase'].items()}
   whole=run['estimated_service_costs']['observed_workload'];stats=actual_phases.get('stats',{});startup=actual_phases.get('startup',{})
   for k,v in whole.items():
    test(v is None if s[k] is None or stats.get(k,0) is None else v==s[k]-stats.get(k,0),'whole_minus_observer_'+k,where)
    test(v is None if fixed[k] is None or startup.get(k,0) is None else v==fixed[k]+startup.get(k,0),'whole_equals_actual_fixed_plus_startup_'+k,where)
   total_ops={k:dict(v) for k,v in s['operations'].items()}
   for name in ['r2_get','r2_head','r2_put','r2_delete','r2_list']:total_ops.setdefault(name,{k:0 for k in ['attempts','successes','failures','read_bytes','written_bytes']})
   trials.append(where|{'warmup':sample<0,'all_actual_phase_counters':actual_phases,'phase_counters_as_originally_exported':s['by_phase'],'unknown_phase_fields_note':'CPU/duration fields omitted by original phase receipts remain unknown/NULL in normalized tables, never zero.','unclassified_counters':actual_phases.get('unclassified',{k:None if s[k] is None else 0 for k in keys}),'unclassified_phase_present':'unclassified' in actual_phases,'actual_fixed_counters':fixed,'actual_whole_nonobserver_counters':whole,'actual_all_category_and_API_totals':{k:s[k] for k in keys},'actual_all_API_bindings':total_ops,'actual_R2_live_objects':s['r2_live_objects'],'actual_R2_live_bytes':s['r2_live_bytes'],'actual_R2_peak_bytes':s['r2_peak_bytes'],'actual_SQLite_current_bytes':s['do_sqlite_bytes'],'SQL_rows_known':s['do_rows_read'] is not None and s['do_rows_written'] is not None,'monthly_SQLite_GBmo':None,'Worker_CPU':None,'DO_duration':None,'Native_compute':None,'whole_cost_report':run['estimated_service_costs'],'counter_epoch':s['counter_epoch'],'do_instance_epoch':s['do_instance_epoch'],'counter_scope':s['counter_scope']})
 for sample in [-1,0,1]:
  raw={p:{r['operation']['key']:r for r in report['raw'] if r['backend']=='cloudflare-local' and r['sample']==sample} for p,report in reports.items()}
  stats={p:next(r for r in report['cloudflare_runs'] if r['sample']==sample)['final_object_stats'] for p,report in reports.items()}
  diffs=[]
  for key,a in raw['r19'].items():
   b=raw['r20'][key]
   fields={k:[a['cloudflare_workload_delta'][k],b['cloudflare_workload_delta'][k]] for k in ['r2_class_a','r2_deletes','r2_written_bytes','do_rows_written']}
   inventory={k:[a['cloudflare_services_after'][k],b['cloudflare_services_after'][k]] for k in ['r2_live_bytes','r2_live_objects','r2_peak_bytes','do_sqlite_bytes','manifest_generation']}
   # Equality is recorded per observed row; divergences remain reviewable rather than presupposed.
   diffs.append({'operation':a['operation'],'actual_write_pairs':fields,'actual_inventory_pairs':inventory,'write_pairs_equal':all(x==y for x,y in fields.values()),'inventory_pairs_equal':all(x==y for x,y in inventory.values()),'compaction_pairs':[a.get('compaction_delta'),b.get('compaction_delta')],'compaction_equal':a.get('compaction_delta')==b.get('compaction_delta'),'backend_validation_pairs':[a['backend_validation_complete'],b['backend_validation_complete']]})
  object_equality=stats['r19']['objects']==stats['r20']['objects']
  manifest_equality=stats['r19']['manifest']==stats['r20']['manifest']
  physical.append({'profile':profile,'sample':sample,'warmup':sample<0,'all_actual_operation_write_pairs_equal':all(r['write_pairs_equal'] for r in diffs),'all_actual_operation_inventory_pairs_equal':all(r['inventory_pairs_equal'] for r in diffs),'all_compaction_deltas_equal':all(r['compaction_equal'] for r in diffs),'actual_final_object_inventory_equal':object_equality,'actual_final_manifest_equal':manifest_equality,'final_objects_by_provider':{p:v['objects'] for p,v in stats.items()},'all_actual_operations':diffs,'equivalence_scope':'Exact fixture and every paired backend validation establish Git data semantics. Physical writes, compaction, live/peak R2 and SQLite are compared as actual observations, with every difference retained; no causal/per-key timeline is invented.'})
for p in PROVIDERS:
 for profile in PROFILES:
  rs=[r for r in trials if r['provider']==p and r['profile']==profile and not r['warmup']]
  if not rs:continue
  categories.append({'provider':p,'profile':profile,'measured_trial_count':len(rs),'all_fixed_counter_values':{k:[r['actual_fixed_counters'][k] for r in rs] for k in rs[0]['actual_fixed_counters']},'all_startup_counter_values':{k:[r['all_actual_phase_counters'].get('startup',{}).get(k,0) for r in rs] for k in rs[0]['actual_fixed_counters']},'actual_ordinary_service_Worker_may_be_less_than_DO':'Count actual SDK socket Upgrades and ordinary DO dispatches; do not force Worker>=DO or multiply frame counts.'})
save('complete-service-phase-category-and-API-review.json',{'run_id':39128927970,'checks':dict(checks),'violations':violations,'all_24_warmup_and_measured_trials':trials,'all_8_provider_profile_counter_variations':categories,'cost_scope':'1000 repeats each profile fixed 32push+56fetch; single observed peak retained30d. Startup, whole nonobserver and observer remain separately measured. Full bill stays NULL.'})
save('actual-data-write-space-equivalence-review.json',physical)
print(json.dumps({'trial_records':len(trials),'closure_checks':sum(checks.values()),'violations':len(violations),'physical_pair_trials':len(physical)}))
