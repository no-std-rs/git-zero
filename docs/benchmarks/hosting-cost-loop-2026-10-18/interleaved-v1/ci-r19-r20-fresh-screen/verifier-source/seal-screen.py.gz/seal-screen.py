"""Seal current-run originals and complete derived review; no selection or final-validation claim."""
import csv,gzip,hashlib,json,shutil,subprocess,tarfile,zipfile
from pathlib import Path
BASE=Path(__file__).parent;ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970');PUB=ROOT/'publication';SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((ROOT/n).read_text())
def save(n,v):(ROOT/n).write_text(json.dumps(v,indent=2)+'\n')
save('monitor-history.json',{'scope':'Only current-run API status/artifact snapshots; exact local snapshot files remain preserved. Parsed snapshots are derived here; local snapshot bytes have separate SHA256 identities.','snapshots':[{'local_path':str(p.relative_to(ROOT)),'original_snapshot_SHA256':sha(p),'original_snapshot_bytes':p.stat().st_size,'snapshot':json.loads(p.read_text())} for p in sorted((ROOT/'progress').glob('*.json'))]})
run=read('run.json');jobs=read('jobs.json')['jobs'];inventory=read('artifact-index.json');decl=read('prospective-source-identities.json');expected=read('expected-source-identities.json')
assert run['id']==39128927970 and run['head_sha']==decl['head']=='d5cdefe53fc24f34114292b7d19563e73afea293' and run['run_attempt']==1 and run['conclusion']=='success'
assert len(jobs)==5 and all(j['conclusion']=='success' for j in jobs);assert inventory['total_count']==5
assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==run['head_sha']
assert subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True)==''
for p,v in expected['sources'].items():assert sha(SOURCE/p)==v['current_sha256'],p
archives=[];checks=0
for a in inventory['artifacts']:
 d=ROOT/'downloads'/a['name'];tar=next(d.glob('*.tar.gz'));zpath=next(d.glob('*.zip'))
 assert a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==run['head_sha'];assert tar.stat().st_size<=4194304 and zpath.stat().st_size<=4194304
 with zipfile.ZipFile(zpath) as z:
  assert len(z.infolist())==1;member=z.infolist()[0];assert z.read(member)==tar.read_bytes()
 if a.get('digest'):assert a['digest']=='sha256:'+sha(zpath)
 directory=ROOT/'scores' if a['name'].startswith('hosting-scores-') else ROOT/'profiles'/a['name'].removeprefix('hosting-screen-').removesuffix('-1')
 for line in (directory/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);p=(directory/n).resolve();assert p.is_relative_to(directory.resolve()) and p.is_file() and sha(p)==h;checks+=1
 archives.append({'artifact_id':a['id'],'artifact_name':a['name'],'run_id':run['id'],'attempt':1,'expires_at':a['expires_at'],'API_artifact_size_bytes':a['size_in_bytes'],'API_digest':a.get('digest'),'tar_path':str(tar.relative_to(ROOT)),'tar_bytes':tar.stat().st_size,'tar_SHA256':sha(tar),'ZIP_path':str(zpath.relative_to(ROOT)),'ZIP_bytes':zpath.stat().st_size,'ZIP_SHA256':sha(zpath),'ZIP_member_name':member.filename,'ZIP_member_uncompressed_bytes':member.file_size,'ZIP_member_compressed_bytes':member.compress_size,'ZIP_member_CRC32':f'{member.CRC:08x}','ZIP_embedded_tar_exact_byte_equality':True,'publication':'Exact original embedded tar.gz published; original API ZIP wrapper remains local-only, fully retained with identity and entry metadata.'})
assert sum(a['tar_bytes'] for a in archives)<=20971520 and sum(a['ZIP_bytes'] for a in archives)<=20971520
raw=list((ROOT/'profiles').glob('*/*/*mib-*.json'));assert len(raw)==8
validation=read('independent-validation.json');assert len(validation['profiles'])==4 and len({r['boot_id'] for r in validation['profiles']})==4
summary=read('summary.json');guards=read('guard-report.json');distribution=read('distribution-review.json');tail=read('tail-completeness-review.json');cache=read('joint-cache-review.json');cacheactivation=read('protected-chunk-activation-and-scope-review.json');service=read('complete-service-phase-category-and-API-review.json');transport=read('transport-activation-checks.json');physical=read('actual-data-write-space-equivalence-review.json');repro=read('offline/evaluator-provenance.json')
assert len(repro['identical_files'])==3 and repro['two_scores_and_one_comparison_byte_identical_to_ci']
assert all(c['comparison']['decision']=='inconclusive' and c['comparison']['eligible_rejected_candidate_for_plateau'] is False for c in guards['comparisons'])
assert tail['all_individual_ratios_reconstructed']==1408 and tail['all_selected_top8_tails_reconstructed']==64 and tail['all_provider_profile_latency_group_maxima']==48
assert cache['measured_R20_host_rows']==704 and cache['observed_operations']==2112
resource_guards=sum(len(p['resource_guards']) for c in guards['comparisons'] for p in c['profiles']);cost_guards=sum(len(c['profiles']) for c in guards['comparisons']);latency_groups=sum(len(p['latency_guards']) for c in guards['comparisons'] for p in c['profiles'])
assert (resource_guards,cost_guards,latency_groups)==(36,4,24)
failed_groups=sum(len(c['failed_latency_guards']) for c in guards['comparisons']);failed_limits=sum(not r[k] for c in guards['comparisons'] for p in c['profiles'] for r in p['latency_guards'] for k in ['median_passed','p95_passed'])
physical_failures=[{'profile':p['profile'],'sample':p['sample'],'failed_observed_equalities':[k for k in ['all_actual_operation_write_pairs_equal','all_actual_operation_inventory_pairs_equal','all_compaction_deltas_equal','actual_final_object_inventory_equal','actual_final_manifest_equal'] if not p[k]]} for p in physical if not all(p[k] for k in ['all_actual_operation_write_pairs_equal','all_actual_operation_inventory_pairs_equal','all_compaction_deltas_equal','actual_final_object_inventory_equal','actual_final_manifest_equal'])]
comparisons=[{'name':c['name'],'known_baseline_USD':c['baseline_known_usd'],'known_candidate_USD':c['candidate_known_usd'],'known_reduction_fraction':c['comparison']['known_cost_reduction_fraction'],'conservative_separated_at_least_1pct_cost_envelope_passed':c['conservative_dollar_threshold_passed'],'resource_failures':c['resource_guard_failures'],'profile_cost_failures':c['failed_profile_cost_guards'],'latency_group_failures':c['latency_guard_failures'],'formal_decision':c['comparison']['decision'],'plateau_eligible':c['comparison']['eligible_rejected_candidate_for_plateau']} for c in summary['comparisons']]
review=read('INDEPENDENT_REVIEW.json');review.update({'scope':'Independent all-four-profile R19/R20 two-pair screen audit only. No new benchmark, build, deployment, source edit, trigger, push, CI cancellation, shadow/API integration, or selection by auditor.','all_four_outcomes_reviewed':True,'all_scores_and_comparison_byte_exact':True,'current_run_binaries_recorded_without_historical_SHA_requirement':True,'all_original_ZIP_and_tar_bytes_retained':True,'ZIP_wrapper_publication':'local only; five exact embedded tar.gz originals publicly staged with all ZIP/member identities','original_artifact_internal_checksums_reverified_after_analysis':checks,'all_36_resource_4_cost_24_latency_group_48_limits_reviewed':True,'comparisons':comparisons,'failed_latency_groups':failed_groups,'failed_latency_limits':failed_limits,'all_failed_group_individual_pairs_preserved':True,'all_1408_individual_ratios_preserved':True,'all_48_provider_profile_group_maxima_preserved':True,'all_64_published_top8_tails_reconstructed':True,'every_original_raw_tail_and_warmup_preserved':True,'R20_measured_host_rows_individually_audited':704,'R19_measured_host_rows_individually_audited':704,'all_raw_host_operation_receipts_including_warmups':2112,'cache_policy':'R19 Multi uses a 17 MiB secondary owning preference with 15 MiB unallocated; R20 Joint removes only that heuristic. Both modes preserve actual first-fit 32 MiB/256 joint budget, pool32, 16 MiB chunks/responses, socket262144, newest-secondary then anchor then response pressure, and authoritative confirmed Full pruning. No resident-superset or modeled GET claim.','maximum_observed_joint_retained_bytes':max(r['maximum_observed_joint_retained_bytes'] for r in cache['trials']),'maximum_source_joint_retained_peak_bytes':max(r['actual_final_cache_gauges']['joint_cache_retained_peak_bytes'] for r in cacheactivation['trials']),'sourcecap_scope':'Owning retained-byte counters, not RSS or transient request heap. No per-key full ordered cache timeline is exported. Archived bounded topkeys remain separate.','service_closure_checks':sum(service['checks'].values()),'service_closure_violations':service['violations'],'transport_diagnostic_checks':transport['checks_inspected'],'transport_diagnostic_failures':transport['failed_checks'],'protected_chunk_diagnostic_checks':cacheactivation['diagnostic_checks_inspected'],'protected_chunk_diagnostic_failures':cacheactivation['diagnostic_failures'],'actual_physical_equivalence_review_differences':physical_failures,'source_of_all_samples':'Only run39128927970 attempt1. Prior audit code reused after current identity/semantics adaptation; no old sample/report/score/comparison reused.','known_objective':'Each of four profiles repeats exactly measured32push+56fetch 1000times; actual R2 peak retained once30d; startup and observer separately measured. Rates frozen2026-10-17.','Worker_request_scope':'Actual gateway/service/observer Worker counts and actual SDK socket Upgrades; ordinary DO dispatches may exceed service Worker requests. No invented invocation ratio or frame multiplier.','formal_acceptance_speed_plateau_or_stop_established':False,'provisional_selection':'None by auditor; coordinator independent all-source/scope/guard/tail audit required before any selection or unfreeze.','mandatory_original_R1_final_five_fresh_pairs_each_all_four_profiles':'NOT DONE; this screen does not satisfy final validation.','unknown_billing_dimensions':['Worker CPU','DO duration','monthly SQLite storage','Native compute'],'full_hosting_cost_USD':None,'timing_scope':'Ready pushes include maintenance; fetched packs verified nonempty, tree/want, archive and strict fsck. Elapsed time never stands in for CPU or full billing.','future_scope':'Final receipts do not prove absence of later ACK/close/teardown traffic, permanent proof validity, or free future recovery/GC.','primary_at_seal':{'head':run['head_sha'],'clean':True}})
save('INDEPENDENT_REVIEW.json',review)
save('all-four-outcomes.json',{'run_id':run['id'],'attempt':1,'head':run['head_sha'],'jobs':[{'name':j['name'],'conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at']} for j in jobs],'all_five_original_CI_artifacts':archives,'original_payload_total_bytes':sum(a['tar_bytes'] for a in archives),'original_transport_total_bytes':sum(a['ZIP_bytes'] for a in archives),'original_API_artifact_limits_apply_to_five_artifacts_not_duplicate_representations':True,'raw_reports':8,'old_samples_reports_or_scores_reused':False})
save('original-artifact-final-reverification.json',{'internal_SHA256_checks_reverified':checks,'original_API_ZIPs':5,'exact_embedded_original_tar_gz':5,'ZIP_to_tar_bytes_reverified':True,'original_reports_mutated':False,'artifacts':archives})
save('analysis.json',{'run_id':run['id'],'head':run['head_sha'],'attempt':1,'stage':'screen','fresh_scores':summary['scores'],'comparisons':comparisons,'failed_latency_groups':failed_groups,'failed_latency_limits':failed_limits,'largest_host_latency':tail['global_largest_host_latency'],'largest_individual_ratio':tail['global_largest_individual_ratio'],'service_accounting_violations':len(service['violations']),'transport_diagnostic_failures':len(transport['failed_checks']),'protected_chunk_diagnostic_failures':len(cacheactivation['diagnostic_failures']),'physical_equalities_with_differences':physical_failures,'formal_result':'INCONCLUSIVE; plateau-ineligible; no speed, acceptance, selection or stopping claim','full_bill_USD':None,'mandatory_originalR1_final_five_fresh_pairs_all4':'NOT DONE'})
score_lines='\n'.join(f"- {p.upper()}: `${v['known_fixed_usd']:.12f}`; conservative envelope `{v['envelope']}`" for p,v in summary['scores'].items())
failure_lines='\n'.join(f"- {f['profile']} / {f['workload']}: median {'pass' if f['median_passed'] else 'FAIL'}, p95 {'pass' if f['p95_passed'] else 'FAIL'}." for c in summary['comparisons'] for f in c['latency_guard_failures']) or '- None.'
scopes=read('counter-scopes.json');physical_rows=[]
for profile in ['16mib-cold','16mib-warm','64mib-cold','64mib-warm']:
 for p in ['r19','r20']:
  rs=[r['fixed_workload'] for r in scopes if r['profile']==profile and r['provider']==p]
  physical_rows.append('| '+profile+' | '+p+' | '+' | '.join(str(sum(r[k] for r in rs)/len(rs)) for k in ['r2_class_b','r2_read_bytes','worker_requests','do_requests','do_rows_read'])+' |')
body=f'''# Fresh R19/R20 two-pair screen independent review

Run [39128927970](https://github.com/no-std-rs/git-zero/actions/runs/39128927970), attempt1, head `{run['head_sha']}`. All four profiles and scoring completed. Eight original schema4 reports, sixteen measured cost trials, all warmups, and five original artifacts are preserved. The frozen Rust evaluator reproduced both schema2 scores and the comparison byte for byte.

Known fixed objective USD (1000 repeats EACH profile, actual R2 peak once30d; frozen2026-10-17 rates):

{score_lines}

All36 resource guards,4 profile-cost guards,24 latency groups and48 median/p95 limits were inspected. Failed latency groups: {failed_groups}; failed limits: {failed_limits}. Cost-envelope and all guard outcomes are retained in `guard-report.json` and `comparison-summary.tsv`, including every failure.

{failure_lines}

All1408 individual host/Git ratios, all48 provider/profile group maxima,64 independently reconstructed top8 tails and every pair in every failed group are retained. Largest host operation: {tail['global_largest_host_latency']['host_ms']/1000:.6f}s, paired Git {tail['global_largest_host_latency']['paired_Git_ms']/1000:.6f}s. Largest individual ratio: {tail['global_largest_individual_ratio']['ratio']:.9f}. No operation, sample, severe tail or unsupported preparation row was discarded.

Actual per-trial mean fixed-window counters across two measured samples (all individual values and SQL variation retained):

| Profile | Provider | Class B | R2 read bytes | Worker requests | DO requests | SQL rows read |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(physical_rows)}

Every API classification, byte total, phase/category closure, counter epoch and complete receipt was checked. There are {len(service['violations'])} service closure violations, {len(transport['failed_checks'])} retained transport diagnostic failures and {len(cacheactivation['diagnostic_failures'])} retained protected-cache diagnostic failures. Actual write/space/data comparisons with differences: {len(physical_failures)}; all exact fields and differences remain in `actual-data-write-space-equivalence-review.json`. Worker categories may total fewer requests than ordinary DO dispatches because socket RPCs are counted at their actual service boundaries. No frame multiplier is charged.

R19 source `f124d3b71ce1acc44ab20d6850b2b619b4bd8ec5`, NativeSRC `521d427a056711a58b757c9e52f3d5e047937f92`. R20 source `b74c91738a3fbfe3ebf30a936fbf9d7ff79f1ae0`, NativeSRC `ff99eaf58a5e4f68e744d0b50ddee2af67aff1cf`. Common Worker tracked six-module tree `7f41db4407963ed04e6cbe19556b1416633caf18`. Complete source, current-run binary/runtime, fresh-state, chronology and ancestry receipts are retained; no historical ELF identity is imposed. Primary differs from pinned R20 only by the reviewed common error-only runner files.

R20 Joint removes only Multi's unallocated15MiB secondary preference. Both retain actual32MiB/256 joint budget, pool32,16MiB chunks/responses,262144 socket reservation, first-fit verified ordinary GET admission with no live-owner replacement, required pressure newest secondary then anchor then response LRU, and pruning only after confirmed current Full authority. Startup/recovery/observer/PUT/warm paths do not admit. Newly published chunks still require naturally paid cold GETs. Runtime cache hits/bytes/owners/entries/growth/prune/reject/pressure/reset counters and socket16RPC rotation/ACK receipts are preserved. R20 is not a resident superset. Source ownership gauges are not RSS or transient heap; bounded archived topkeys are not a complete ordered per-key timeline.

Startup, ordinary fixed windows, whole nonobserver trace, observer restoration and unclassified phase counts remain separate actual receipts. Whole-minus-observer equals fixed-plus-actual-startup only where verified; no startup count is prescribed. Worker CPU, DO duration, monthly SQLite storage and Native compute remain unknown; full bill is NULL. Final snapshots do not establish permanent proof validity, free future GC/recovery, or absence of later ACK/close/teardown traffic. Ready push latency includes reference maintenance; elapsed is never billed CPU.

The screen is formally INCONCLUSIVE and plateau-ineligible. No speed, acceptance, provisional selection or stopping claim is made. Root must independently review all sources/scopes/guards/tails before any selection or unfreeze. Mandatory FIVE fresh original-R1/final pairs on EACH of all four profiles remain NOT DONE.

Publication contains five exact original embedded tar.gz payloads and deterministic gzip of exact derived metadata/scripts. Original API ZIP wrappers stay local-only with complete SHA256/member mappings in `transport-archive-index.json` and `all-four-outcomes.json`; no original is removed. Large fixtures, ELFs and runtime R2/SQLite state were not in these bounded CI artifacts and are not uploaded. Prior samples/capsules/reviews remain separate and unchanged. All shadow/API work remains cancelled. This is local staging only; nothing published or pushed by auditor.
'''
(ROOT/'INDEPENDENT_REVIEW.md').write_text(body)
vs=ROOT/'verifier-source';vs.mkdir(exist_ok=True)
for p in sorted(BASE.iterdir()):
 if p.is_file() and p.suffix in ['.py','.json']:shutil.copyfile(p,vs/p.name)
shutil.copyfile(ROOT/'summarize-chain.py',vs/'summarize-chain.py');shutil.copyfile('/tmp/prepare-r19-r20-independent-audit.py',vs/'prepare-r19-r20-independent-audit.py')
(vs/'LOCATION.json').write_text(json.dumps({'tooling_root':str(BASE),'evidence_root':str(ROOT),'scope':'Read-only GitHub APIs/artifact download, offline verification/packaging, pre-existing frozen Rust evaluator. No benchmark, build, source/workflow edit, deployment, push, trigger, cancellation, or delegation by verifier.'},indent=2)+'\n')
PUB.mkdir(exist_ok=True);mapping=[]
def payload(src,name,compress):
 dst=PUB/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if compress:
  with dst.open('wb') as out:
   with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as z:z.write(src.read_bytes())
  assert gzip.decompress(dst.read_bytes())==src.read_bytes()
 else:shutil.copyfile(src,dst)
 mapping.append({'published_path':name,'source_path':str(src.relative_to(ROOT)),'source_bytes':src.stat().st_size,'source_exact_SHA256':sha(src),'published_bytes':dst.stat().st_size,'published_SHA256':sha(dst),'encoding':'deterministic gzip of exact source bytes' if compress else 'original bytes'})
for a in archives:payload(ROOT/a['tar_path'],'original-archives/'+Path(a['tar_path']).name,False)
for p in sorted(ROOT.iterdir()):
 if p.is_file() and (p.suffix in ['.json','.tsv','.md'] or p.name=='RAW_SHA256SUMS'):payload(p,'review/'+p.name+'.gz',True)
for d,label in [(ROOT/'offline','offline'),(vs,'verifier-source')]:
 for p in sorted(d.iterdir()):
  if p.is_file():payload(p,label+'/'+p.name+'.gz',True)
(PUB/'README.md').write_text(body)
(PUB/'ARTIFACT_MAP.json').write_text(json.dumps({'mapped_exact_payloads':mapping,'local_only_original_transport_wrappers':[{'path':a['ZIP_path'],'bytes':a['ZIP_bytes'],'SHA256':a['ZIP_SHA256'],'member_name':a['ZIP_member_name'],'embedded_original_SHA256':a['tar_SHA256'],'reason':'Redundant transport wrapper stays local-only; its exact embedded original tar.gz is published.'} for a in archives],'not_in_CI_payload':['large fixtures','ELFs','runtime R2/SQLite emulator state'],'staging_only':True},indent=2)+'\n')
files=sorted(p for p in PUB.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(PUB/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(PUB)}\n' for p in files))
for line in (PUB/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(PUB/n)==h
bundle=ROOT/'fresh-screen-evidence.tar.gz'
with bundle.open('wb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for p in sorted(p for p in PUB.rglob('*') if p.is_file()):
    i=tar.gettarinfo(str(p),arcname='fresh-screen-evidence/'+str(p.relative_to(PUB)));i.mtime=0;i.uid=i.gid=0;i.uname=i.gname=''
    with p.open('rb') as data:tar.addfile(i,data)
with tarfile.open(bundle) as tar:
 for m in tar.getmembers():assert tar.extractfile(m).read()==(PUB/m.name.removeprefix('fresh-screen-evidence/')).read_bytes()
allfiles=sorted(p for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'SHA256SUMS');(ROOT/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT)}\n' for p in allfiles))
for line in (ROOT/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(ROOT/n)==h
handoff={'screen_status':'SEALED INCONCLUSIVE; no selection or final-validation claim','evidence_root':str(ROOT),'review_MD_SHA256':sha(ROOT/'INDEPENDENT_REVIEW.md'),'review_JSON_SHA256':sha(ROOT/'INDEPENDENT_REVIEW.json'),'capsule':str(bundle),'capsule_bytes':bundle.stat().st_size,'capsule_SHA256':sha(bundle),'publication':str(PUB),'publication_payloads':len(mapping),'publication_manifest_SHA256':sha(PUB/'SHA256SUMS'),'whole_evidence_manifest_SHA256':sha(ROOT/'SHA256SUMS'),'whole_evidence_files':len(allfiles),'internal_original_checksums':checks,'original_tar_total_bytes':sum(a['tar_bytes'] for a in archives),'original_ZIP_total_bytes':sum(a['ZIP_bytes'] for a in archives),'ratios':1408,'tails':64,'group_maxima':48,'resource_guards':36,'cost_guards':4,'latency_groups':24,'failed_latency_groups':failed_groups,'failed_latency_limits':failed_limits,'mandatory_five_fresh_originalR1_final_pairs_all4':'NOT DONE'}
print(json.dumps(handoff))
