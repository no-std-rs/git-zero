import json
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970')
tail_details=[]
# Preserve every operation pair in each failed latency workload.
if (ROOT/'guard-report.json').exists():
    guards=json.loads((ROOT/'guard-report.json').read_text())
    for c in guards['comparisons']:
        for failed in c['failed_latency_guards']:
            profile=failed['profile'];group=failed['workload']
            detail={'comparison':c['name'],'profile':profile,'group':group,'guard':failed,'all_baseline_and_candidate_pairs':[]}
            for p in [c['baseline'],c['candidate']]:
                report=json.loads((ROOT/'profiles'/profile/p/f'{profile}.json').read_text())
                for r in report['raw']:
                    if r['warmup'] or r['backend']!='cloudflare-local' or r.get('operation',{}).get('group')!=group:continue
                    g=next(v for v in report['raw'] if v['backend']=='git' and v['sample']==r['sample'] and v.get('operation')==r['operation'])
                    host=r.get('ready_wall_ms',r['wall_ms']);git=g.get('ready_wall_ms',g['wall_ms'])
                    detail['all_baseline_and_candidate_pairs'].append({'provider':p,'sample':r['sample'],'operation':r['operation'],'host_ms':host,'git_ms':git,'ratio':host/git,'fixed_receipt':r['cloudflare_workload_delta'],'native_metric_delta':r['service_metrics_delta'],'host_client_resources':r['client_resources'],'Git_client_resources':g['client_resources'],'contention_before':r['run_contention_before'],'contention_after':r['run_contention_after']})
            tail_details.append(detail)
(ROOT/'latency-failure-pair-details.json').write_text(json.dumps(tail_details,indent=2)+'\n')
print(json.dumps({'failed_workload_details':len(tail_details)}))
