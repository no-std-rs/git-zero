"""Audit recorded build identity and provider chronology using fresh evidence only."""
import hashlib,json
from datetime import datetime
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970')
EXPECTED=json.loads((ROOT/'expected-source-identities.json').read_text())
def pairs(path):return dict(line.split('=',1) for line in path.read_text().splitlines() if '=' in line)
def hashes(path):return {name:digest for digest,name in (line.split('  ',1) for line in path.read_text().splitlines())}
records=[]
for profile in ['16mib-cold','16mib-warm','64mib-cold','64mib-warm']:
    d=ROOT/'profiles'/profile
    if not (d/'checksum-verification.txt').exists():continue
    prov=d/'provenance';runtime=pairs(prov/'runtime.txt');current=hashes(prov/'common-sha256.txt')
    chronology=[];last_end=None
    for p in EXPECTED['providers']:
        start=(d/p/'start.txt').read_text().strip();end=(d/p/'end.txt').read_text().strip()
        assert start<=end
        assert last_end is None or last_end<=start
        last_end=end
        service=pairs(d/p/'service.txt')
        assert service['vm_boot_id']==runtime['vm_boot_id']
        chronology.append({'provider':p,'start':start,'end':end,'Worker_PID':service['worker_pid'],'persist_state':service['state'],'same_boot_id':runtime['vm_boot_id'],'health_and_fresh_state_source_policy':'Workflow tests state path absence before startup and waits for ready workerd before timing. All raw first-push namespaces independently start generation zero.'})
    binary=[]
    for name in ['hosting-bench','hosting-cost','reference-host']:
        key=next(k for k in current if k.endswith('/bin/common/'+name))
        binary.append({'binary':name,'fresh_CI_sha256':current[key],'historical_binary_identity_prescribed':False})
    records.append({'profile':profile,'actual_provider_order':chronology,'common_binary_comparison':binary,'fresh_complete_common_manifest':current})
assert len(records)==4
assert len({r['actual_provider_order'][0]['same_boot_id'] for r in records})==4
for r in records[1:]:assert r['fresh_complete_common_manifest']==records[0]['fresh_complete_common_manifest']
(ROOT/'binary-and-order-provenance-review.json').write_text(json.dumps({'profiles':records,'frozen_local_evaluator_sha256':hashlib.sha256(Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/evaluators/zero-get-fix/hosting-cost').read_bytes()).hexdigest(),'runner_and_evaluator_entry_source_identities':{k:v for k,v in EXPECTED['sources'].items() if k.endswith(('hosting-bench.rs','hosting-cost.rs','benchmark_cost.rs'))},'linked_source_note':'Common tools link changed host-library source, and hosting-bench retains the already reviewed error-only exporter. Fresh common binary hashes are independently recorded and compared; scorer/pricing entry sources are unchanged. Exact frozen offline reproduction is checked separately; no historical binary identity is substituted.','prior_provenance_use':'No historical binaries or raw report, sample, score or comparison enter the fresh measurement.'},indent=2)+'\n')
print(json.dumps({'profile_chronologies':len(records),'distinct_VM_boots':4,'fresh_all_four_common_manifests_match':True,'common_binary_comparison':records[0]['common_binary_comparison']}))
