"""Verify preserved frozen evaluator provenance against its original source and current CI source; no build."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970');SOURCE=Path('/tmp/git-zero-hosting-cost-loop');FROZEN=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/evaluators/zero-get-fix')
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((FROZEN/'hosting-cost').read_bytes())=='01b36df2f5f2019eeb09ebe79eb8ae80e9f86d0cdf39667c9fec9b0584e61fb8'
for n in ['SHA256SUMS','built-source-commit.txt']:
 assert (ROOT/'offline'/('frozen-evaluator-original-'+n)).read_bytes()==(FROZEN/n).read_bytes()
commit=(FROZEN/'built-source-commit.txt').read_text().strip();expected=json.loads((ROOT/'expected-source-identities.json').read_text());items=[]
for p in ['examples/repository-host/src/bin/hosting-cost.rs','examples/repository-host/src/benchmark_cost.rs','examples/repository-host/src/cost.rs','Cargo.lock']:
 original=sha(subprocess.check_output(['git','-C',str(SOURCE),'show',commit+':'+p]));current=sha((SOURCE/p).read_bytes());items.append({'source_path':p,'original_frozen_evaluator_built_source_SHA256':original,'current_CI_source_SHA256':current,'identical':original==current})
 if p!='Cargo.lock':assert original==current,p
out={'original_frozen_evaluator_built_source_commit':commit,'current_CI_source_commit':expected['head'],'source_identity_comparison':items,'scope':'Original frozen evaluator ELF pinned by SHA256; current-run CI ELF recorded independently. Cargo.lock differs; scorer entry, arithmetic and pricing source are identical. Complete outputs require byte-exact fresh-run reproduction separately.'}
(ROOT/'offline/frozen-evaluator-source-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'frozen_evaluator_SHA256_verified':True,'original_scorer_and_pricing_source_identical_to_current_CI':True,'original_Cargo_lock_differs_and_is_retained_honestly':True}))
