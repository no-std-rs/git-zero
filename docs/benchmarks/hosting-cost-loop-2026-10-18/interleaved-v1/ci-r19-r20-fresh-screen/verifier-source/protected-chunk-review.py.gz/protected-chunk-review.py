"""Retain every actual R20 cache event and operation receipt; no modeled saving."""
import collections,json
from pathlib import Path
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970')
PROVIDERS=['r19','r20'];PROFILES=['16mib-cold','16mib-warm','64mib-cold','64mib-warm']
events=['protected_chunk_admissions','protected_chunk_hits','protected_chunk_hit_bytes','protected_chunk_evictions','protected_chunk_pressure_evictions','protected_chunk_reset_evictions','protected_chunk_prunes','protected_chunk_rejections']
gauges=['protected_chunk_bytes','protected_chunk_owning_bytes','joint_cache_entries','joint_cache_retained_peak_bytes','cache_retained_bytes','cache_bytes','cache_entries','protected_chunk_entries']
trials=[];operations=[];checks=[]
def check(ok,label,detail):checks.append({'passed':bool(ok),'check':label,**detail})
for profile in PROFILES:
    d=ROOT/'profiles'/profile
    if not (d/'checksum-verification.txt').exists():continue
    for provider in PROVIDERS:
        report=json.loads((d/provider/f'{profile}.json').read_text())
        for sample in [-1,0,1]:
            rows=[r for r in report['raw'] if r['backend']=='cloudflare-local' and r['sample']==sample]
            final=next(r for r in report['cloudflare_runs'] if r['sample']==sample)['final_object_stats']
            timed={k:sum(r['service_metrics_delta'].get(k,0) for r in rows) for k in events}
            outside={k:final.get(k,0)-v for k,v in timed.items()}
            phase=collections.defaultdict(collections.Counter);first_admission=None;first_hit=None
            for row in rows:
                metric=row['service_metrics_delta'];receipt=row['cloudflare_workload_delta'];op=row['operation'];detail={'profile':profile,'provider':provider,'sample':sample,'operation':op['key']}
                delta={k:metric.get(k,0) for k in events}
                phase[op['kind']].update(delta)
                if delta['protected_chunk_admissions'] and first_admission is None:first_admission=op
                if delta['protected_chunk_hits'] and first_hit is None:first_hit=op
                if delta['protected_chunk_admissions']:
                    check(receipt['r2_class_b']>0 and receipt['r2_read_bytes']>0,'Admission occurs in an operation with an actual required successful payload GET',detail)
                if op['kind']=='fetch' and op['group']=='latest_fetch' and profile.endswith('cold'):
                    check(receipt['r2_class_b']>0 and receipt['r2_read_bytes']>0,'New published chunk still requires positive cold GET and bytes',detail)
                if profile.endswith('warm'):
                    check(receipt['r2_class_b']==receipt['r2_read_bytes']==delta['protected_chunk_admissions']==0,'Warm persistent view performs no payload GET or protected admission',detail)
                before,after=row['cloudflare_services_before'],row['cloudflare_services_after']
                bindings={name:{k:after['operations'].get(name,{}).get(k,0)-before['operations'].get(name,{}).get(k,0) for k in ['attempts','successes','failures','read_bytes','written_bytes']} for name in set(before['operations'])|set(after['operations'])}
                operations.append({**detail,'warmup':sample<0,'operation_descriptor':op,'actual_fixed_receipt':receipt,'actual_binding_attempts_including_observer':bindings,'actual_protected_event_delta':delta,'actual_protected_and_joint_gauge_delta':{k:metric.get(k,0) for k in gauges},'actual_preparation_delta':{k:v for k,v in metric.items() if k.startswith(('gateway_read_','gateway_receive_'))},'actual_selected_view_gauge_delta':metric.get('native_view'),'actual_response_only_cache':row.get('server_cache_after_fetch',row.get('server_cache_after_push')),'native_socket_diagnostic_delta':metric.get('native_socket_rpc'),'receipt_complete':after['accounting_complete'],'receipt_errors':after['accounting_errors']})
            if provider in PROVIDERS:
                check(outside['protected_chunk_admissions']==0,'No observed protected admission outside timed ordinary requests',{'profile':profile,'provider':provider,'sample':sample})
                check(outside['protected_chunk_prunes']==0,'No observed logical prune outside timed ordinary requests',{'profile':profile,'provider':provider,'sample':sample})
                check(rows[0]['service_metrics_delta'].get('protected_chunk_admissions',0)==0,'Fresh first push does not admit a newly PUT chunk',{'profile':profile,'provider':provider,'sample':sample})
            trials.append({'profile':profile,'provider':provider,'sample':sample,'warmup':sample<0,'actual_timed_events':timed,'actual_events_after_subtracting_timed_rows':outside,'actual_events_by_kind':{k:dict(v) for k,v in phase.items()},'actual_final_event_counters':{k:final.get(k,0) for k in events},'actual_final_cache_gauges':{k:final.get(k) for k in gauges},'first_actual_admission_operation':first_admission,'first_actual_hit_operation':first_hit,'actual_startup_phase':final['cloudflare_services']['by_phase'].get('startup'),'actual_observer_phase':final['cloudflare_services']['by_phase'].get('stats'),'protected_gauge_availability':'Both providers export payload/owning/joint gauges, pool entries, pressure/reset evictions, logical prunes and rejected candidates. R19 uses Multi; R20 uses Joint, both up to 32 chunks.'})
review={'run_id':39128927970,'attempt':1,'trials':trials,'diagnostic_checks_inspected':len(checks),'diagnostic_failures':[c for c in checks if not c['passed']],'checks_are_diagnostic':'No modeled GET, byte, DO or preparation count is prescribed. Diagnostic deviations are retained; no valid sample is removed or price/guard result forced.','source_secondary_heuristic':{'R20_pool_entries':32,'R19_secondary_chunk_owning_admission_limit_bytes':17825792,'R19_unallocated_headroom_bytes':15728640,'R20_secondary_heuristic_removed':True,'R20_secondary_chunk_owning_admission_limit_bytes':None,'headroom_is_owned_or_reserved':False,'response_cap_bytes':16777216,'joint_cap_bytes':33554432,'joint_entry_cap':256,'socket_reserved_bytes':262144,'runtime_rule':'Each actual gauge and pressure/rejection/prune counter is retained. Only R19 retains the unallocated secondary preference; R20 removes it and still uses actual first-fit joint accounting. Neither allocates a reserve or reduces response eligibility.'},'admission_scope':'Source gates exclude startup/recovery/observer/PUT/warm preload admission. Actual final-minus-timed admission totals and all per-operation successful GET receipts are retained separately.','selection_scope':'The source validates exact ordered selected descriptors and digest+length before materialization, including the retained handle and all missing GETs. Runtime receipts expose aggregate attempts, bytes, selected-view gauges and cache events per operation; individual internal chunk keys/attempt timestamps are not exported by this frozen runner.','fallback_scope':'Actual Unsupported, consumed, paid-discard, generation-change and error counts are retained as measured; safe fallback is ordinary fresh reconstruction and is never modeled as a free proof.','billing_scope':'All actual Worker categories/Upgrades, ordinary DO dispatches, R2 and SQL receipts are priced from the fixed measured windows; startup and final observer restoration stay separate. No source hypothesis is substituted for observed savings.','future_scope':'No absence of later callbacks, ACKs, closes or teardown traffic is inferred from the final snapshot. Full hosting bill remains null.'}
(ROOT/'protected-chunk-activation-and-scope-review.json').write_text(json.dumps(review,indent=2)+'\n')
(ROOT/'protected-chunk-every-operation-receipts.json').write_text(json.dumps(operations,indent=2)+'\n')
print(json.dumps({'actual_cache_trials':len(trials),'operation_receipts':len(operations),'diagnostic_checks':len(checks),'diagnostic_failures':len(review['diagnostic_failures'])}))
