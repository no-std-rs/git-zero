"""Derive independent scope, history, migration and resource evidence from fresh CI bytes only."""
import csv
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970')
PROVIDERS = ["r19", "r20"]
PROFILES = ["16mib-cold", "16mib-warm", "64mib-cold", "64mib-warm"]

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n")

def numeric_delta(after, before):
    return {k: (None if v is None else v - before.get(k, 0))
            for k, v in after.items() if v is None or isinstance(v, (int, float))}

def scalars(value):
    return {k:v for k,v in value.items() if not isinstance(v, (list, dict))}

history, observers, migration, fingerprints, all_native, operation_resources = [], [], [], [], [], []
for provider in PROVIDERS:
    score = json.loads((ROOT / "offline" / f"{provider}-score.json").read_text())
    for profile in PROFILES:
        raw_path = ROOT / "profiles" / profile / provider / f"{profile}.json"
        report = json.loads(raw_path.read_text())
        fingerprints.append({"provider":provider,"profile":profile,
            "original_file_bytes_sha256":hashlib.sha256(raw_path.read_bytes()).hexdigest(),
            "scorer_serde_json_canonical_sha256":score["profiles"][profile]["source_report_sha256"],
            "fingerprint_scopes":"Original file bytes and the scorer's parsed serde_json representation are distinct identities; neither substitutes for the other."})
        for sample in [-1, 0, 1]:
            rows = [r for r in report["raw"] if r["backend"] == "cloudflare-local" and r["sample"] == sample]
            assert len(rows) == 88
            first, last = rows[0], rows[-1]
            run = next(r for r in report["cloudflare_runs"] if r["sample"] == sample)
            stats = run["final_object_stats"]
            final_services = stats["cloudflare_services"]
            last_services = last["cloudflare_services_after"]
            after_fixed = numeric_delta(final_services, last_services)
            stats_delta = numeric_delta(final_services["by_phase"]["stats"], last_services["by_phase"].get("stats", {}))
            for phase in set(final_services["by_phase"]) - {"stats"}:
                assert final_services["by_phase"][phase] == last_services["by_phase"].get(phase, {}), (provider, profile, sample, phase)
            for key in stats_delta:
                if key in after_fixed:
                    assert stats_delta[key] == after_fixed[key], (provider,profile,sample,key)
            binding_delta = {name:numeric_delta(value,last_services["operations"].get(name,{})) for name,value in final_services["operations"].items()}
            native_events = {key:sum(r["service_metrics_delta"].get(key,0) for r in rows)
                for key in ["cloud_view_rehydrates","history_projections","history_full_restores"] if key in stats}
            final_native_extra = {key:stats[key] - value for key,value in native_events.items()}
            assert all(v >= 0 for v in final_native_extra.values())
            observers.append({"provider":provider,"profile":profile,"sample":sample,"warmup":sample < 0,
                "scope":"After the last timed operation receipt through full object inventory; actual physical work retained, all charged to excluded observer stats. These counters are excluded from the exact fixed 32:56 objective and whole non-stats traffic.",
                "actual_counter_delta":after_fixed,"stats_phase_counter_delta":stats_delta,
                "actual_binding_operation_delta":binding_delta,
                "native_event_difference_after_timed_rows":final_native_extra,
                "final_native_view":stats.get("native_view"),
                "observer_usage_entire_trial":run["estimated_service_costs"]["excluded_observer_usage"]})
            per_group = {}
            for row in rows:
                group = row["operation"]["group"]
                metric = row["service_metrics_delta"]
                selected = {k:v for k,v in metric.items() if isinstance(v,(int,float)) and any(term in k for term in ["history", "rehydrate", "witness", "discovery", "advertisement", "cache", "noop", "gateway_read", "gateway_receive", "socket"])}
                entry = {"provider":provider,"profile":profile,"sample":sample,"warmup":sample < 0,
                    "operation":row["operation"],"actual_native_metric_delta":selected,
                    "fixed_workload_receipt":row["cloudflare_workload_delta"],
                    "cache_after":row.get("server_cache_after_fetch",row.get("server_cache_after_push")),
                    "native_view_metric_delta":metric.get("native_view")}
                all_native.append(entry)
                group_metrics = per_group.setdefault(group,{"operations":0,"native_event_sums":{},"r2_get_attempts":0,"r2_read_bytes":0,"worker_requests":0,"do_requests":0,"do_rows_read":0,"do_rows_written":0})
                group_metrics["operations"] += 1
                for key,value in selected.items():
                    if not any(gauge in key for gauge in ["bytes", "budget", "limit", "entries"]):
                        group_metrics["native_event_sums"][key] = group_metrics["native_event_sums"].get(key,0) + value
                operations = metric["cloudflare_services"]["operations"]
                group_metrics["r2_get_attempts"] += operations.get("r2_get",{}).get("attempts",0)
                for key in ["r2_read_bytes","worker_requests","do_requests","do_rows_read","do_rows_written"]:
                    group_metrics[key] += row["cloudflare_workload_delta"][key]
                if sample >= 0:
                    operation_resources.append({"provider":provider,"profile":profile,"sample":sample,"operation":row["operation"]["key"],"group":group,
                        "wall_ms":row["wall_ms"],"ready_wall_ms":row.get("ready_wall_ms"),
                        **{"fixed_"+k:v for k,v in row["cloudflare_workload_delta"].items()},
                        **{"client_"+k:v for k,v in row["client_resources"].items()}})
            history.append({"provider":provider,"profile":profile,"sample":sample,"warmup":sample < 0,
                "groups":per_group,"final_native_metrics":scalars(stats),"final_native_view":stats.get("native_view"),
                "final_object_inventory":stats["objects"],"final_manifest_pack_count":len(stats["manifest"]["packs"]),
                "final_manifest_garbage":stats["manifest"].get("garbage", []),"final_manifest_garbage_entries":len(stats["manifest"].get("garbage", [])),
                "final_sqlite_bytes":final_services["do_sqlite_bytes"],"physical_sqlite_page_count":None,
                "page_count_note":"databaseSize bytes are measured; SQL page_count/page_size was not separately queried by the frozen runner, so a physical page count remains unknown.",
                "final_live_r2_bytes":final_services["r2_live_bytes"],"final_peak_r2_bytes":final_services["r2_peak_bytes"],
                "final_live_r2_objects":final_services["r2_live_objects"]})
            pushes = [r for r in rows if r["operation"]["kind"] == "push"]
            migration.append({"provider":provider,"profile":profile,"sample":sample,"warmup":sample < 0,
                "catalog_peak_requested_by_native_source":True,
                "catalog_pages_requested_by_native_source":True,
                "deferred_retirement_requested_by_native_source":True,
                "first_timed_push_exact_receipt":first["cloudflare_workload_delta"],
                "first_timed_push_services_before":first["cloudflare_services_before"],
                "first_timed_push_services_after":first["cloudflare_services_after"],
                "push_sql_rows_read":sum(r["cloudflare_workload_delta"]["do_rows_read"] for r in pushes),
                "push_sql_rows_written":sum(r["cloudflare_workload_delta"]["do_rows_written"] for r in pushes),
                "startup_phase_exact_receipt":final_services["by_phase"]["startup"],
                "final_sqlite_bytes":final_services["do_sqlite_bytes"],"actual_peak_r2_bytes":final_services["r2_peak_bytes"],
                "per_push_rows":[{"generation":r["operation"]["generation"],"do_rows_read":r["cloudflare_workload_delta"]["do_rows_read"],"do_rows_written":r["cloudflare_workload_delta"]["do_rows_written"],"r2_class_a":r["cloudflare_workload_delta"]["r2_class_a"],"r2_deletes":r["cloudflare_workload_delta"]["r2_deletes"],"compaction":r["compaction_delta"]} for r in pushes]})

save('peak-migration-metrics.json',{'scope':'Fresh CI first timed push and actual per-push SQL/R2 receipts; separate existing correctness proofs add no samples.', 'trials':migration})
save('history-selection-metrics.json',history)
save('observer-physical-restore-metrics.json',observers)
save('all-native-operation-metrics.json',all_native)
save('report-fingerprints.json',fingerprints)
with (ROOT/'operation-resource-receipts.tsv').open('w') as stream:
    writer=csv.DictWriter(stream,delimiter='\t',fieldnames=list(dict.fromkeys(k for row in operation_resources for k in row)))
    writer.writeheader();writer.writerows(operation_resources)
print(json.dumps({"history_trials":len(history),"observer_trials":len(observers),"migration_trials":len(migration),"report_fingerprints":len(fingerprints),"measured_operation_resource_rows":len(operation_resources)}))
