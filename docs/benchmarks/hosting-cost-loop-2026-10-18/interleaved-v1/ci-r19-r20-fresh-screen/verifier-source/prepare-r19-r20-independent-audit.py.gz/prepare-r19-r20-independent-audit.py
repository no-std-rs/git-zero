import json,hashlib,subprocess
from pathlib import Path
OLD=Path('/tmp/git-zero-r18-r19-run-39118509165-audit')
NEW=Path('/tmp/git-zero-r19-r20-run-39128927970-audit'); NEW.mkdir()
ROOT=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970');ROOT.mkdir(parents=True)
SOURCE=Path('/tmp/git-zero-hosting-cost-loop')
DECL=Path('/tmp/git-zero-r19-r20-screen-source-identities.json')
assert hashlib.sha256(DECL.read_bytes()).hexdigest()=='0b38cc9a84d6ba907e0a5881601529fbb01bfd8ffd971fec723c01dd249f5886'
d=json.loads(DECL.read_text());(ROOT/'prospective-source-identities.json').write_bytes(DECL.read_bytes())
def git(*a):return subprocess.check_output(['git','-C',str(SOURCE),*a])
def h(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==d['head'];assert git('status','--porcelain')==b''
prior=json.loads(Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r18-r19-screen/run-39118509165/expected-source-identities.json').read_text())
e={'reference_commit':prior['reference_commit'],'reference_tree':git('rev-parse',prior['reference_commit']+'^{tree}').decode().strip(),'reference_manifest_sha256':{p:h(git('show',prior['reference_commit']+':'+p)) for p in prior['reference_manifest_sha256']},'head':d['head'],'head_tree':git('rev-parse',d['head']+'^{tree}').decode().strip(),'head_parent':git('rev-parse',d['head']+'^').decode().strip(),'worker_source_tree':d['common_worker_source_tree'],'sources':{},'providers':{}}
for p,v in prior['sources'].items():e['sources'][p]={'current_sha256':h(git('show',d['head']+':'+p)),'prior_sha256':v['current_sha256']}
for label,commit in d['provider_commits'].items():
 subprocess.run(['git','-C',str(SOURCE),'merge-base','--is-ancestor',commit,d['head']],check=True)
 e['providers'][label]={'commit':commit,'tree':git('rev-parse',commit+'^{tree}').decode().strip(),'native_source_tree':git('rev-parse',commit+':examples/repository-host/src').decode().strip(),'manifest_sha256':{p:h(git('show',commit+':'+p)) for p in ['Cargo.lock','Cargo.toml','examples/repository-host/Cargo.toml']}}
 assert e['providers'][label]['native_source_tree']==d['provider_native_source_trees'][label]
p=prior['pricing_source']['path'];e['pricing_source']={'path':p,'current_sha256':h(git('show',d['head']+':'+p)),'prior_sha256':prior['pricing_source']['current_sha256']}
(ROOT/'expected-source-identities.json').write_text(json.dumps(e,indent=2)+'\n')
provenance=[]
def adapt(s):
 return s.replace('r19','__NEXT__').replace('r18','r19').replace('__NEXT__','r20').replace('R19','__NEXT__').replace('R18','R19').replace('__NEXT__','R20').replace('39118509165','39128927970').replace('622b3482b8f460c2e9b24bedf1ccc5735634aab8',d['head'])
for p in sorted(OLD.glob('*.py')):
 if p.name in ['monitor-once.py','seal-screen.py']:continue
 s=adapt(p.read_text());(NEW/p.name).write_text(s)
 provenance.append({'derived_script':p.name,'prior_code_only_path':str(p),'prior_code_SHA256':h(p.read_bytes()),'adaptation':'Updated current-run root/head/id/provider labels. Provider-specific cache semantics amended separately before execution. No historical samples/reports/scores copied.'})
p=Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r18-r19-screen/run-39118509165/summarize-chain.py');(ROOT/p.name).write_text(adapt(p.read_text()));provenance.append({'derived_script':'summarize-chain.py','prior_code_only_path':str(p),'prior_code_SHA256':h(p.read_bytes())})
(NEW/'ADAPTATION_PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'new_tooling':str(NEW),'new_root':str(ROOT),'source_files':len(e['sources']),'providers':e['providers']}))
