"""Expose actual HEAD, SQL, first-push migration and observed epoch evidence."""
import collections
import json
from pathlib import Path

ROOT = Path('/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/ci/r19-r20-screen/run-39128927970')
PROVIDERS = ["r19", "r20"]
PROFILES = ["16mib-cold", "16mib-warm", "64mib-cold", "64mib-warm"]


def op_delta(after, before):
    return {name:{k:after.get(name,{}).get(k,0)-before.get(name,{}).get(k,0)
                  for k in ["attempts","successes","failures","read_bytes","written_bytes"]}
            for name in set(after)|set(before)}


records = []
for profile in PROFILES:
    if not (ROOT/"profiles"/profile/"checksum-verification.txt").exists():
        continue
    for provider in PROVIDERS:
        report = json.loads((ROOT/"profiles"/profile/provider/f"{profile}.json").read_text())
        for sample in [-1,0,1]:
            rows = [r for r in report["raw"] if r["backend"] == "cloudflare-local" and r["sample"] == sample]
            first,last = rows[0],rows[-1]
            final = next(r for r in report["cloudflare_runs"] if r["sample"]==sample)["final_object_stats"]
            final_services = final["cloudflare_services"]
            before,after = first["cloudflare_services_before"],first["cloudflare_services_after"]
            epochs = []
            operation_totals = collections.Counter()
            observer_r2b_during_windows = 0
            pushes = []
            for row in rows:
                start,end = row["cloudflare_services_before"],row["cloudflare_services_after"]
                for snap in [start,end]:
                    if not epochs or epochs[-1] != snap["do_instance_epoch"]:
                        epochs.append(snap["do_instance_epoch"])
                binding = op_delta(end["operations"],start["operations"])
                for k,v in binding.items():
                    operation_totals[k] += v["attempts"]
                observer_r2b_during_windows += end["by_phase"].get("stats",{}).get("r2_class_b",0)-start["by_phase"].get("stats",{}).get("r2_class_b",0)
                if row["operation"]["kind"] == "push":
                    pushes.append({"operation":row["operation"],"exact_timed_receipt":row["cloudflare_workload_delta"],
                        "actual_binding_delta_including_observer":binding,
                        "sqlite_bytes_before":start["do_sqlite_bytes"],"sqlite_bytes_after":end["do_sqlite_bytes"],
                        "observed_compaction_delta":row["compaction_delta"]})
            if epochs[-1] != final_services["do_instance_epoch"]:
                epochs.append(final_services["do_instance_epoch"])
            observer = op_delta(final_services["operations"],last["cloudflare_services_after"]["operations"])
            fixed = {k:None if v is None else sum(r["cloudflare_workload_delta"][k] for r in rows)
                     for k,v in first["cloudflare_workload_delta"].items()}
            # /metrics only inventories via LIST and reads SQLite, with no GET
            # or HEAD. This assertion establishes the exact fixed-window HEAD
            # count without assigning it to an unrecorded proof/GC cause.
            assert observer_r2b_during_windows == 0
            assert fixed["r2_class_b"] == operation_totals["r2_get"]+operation_totals["r2_head"]
            records.append({"provider":provider,"profile":profile,"sample":sample,"warmup":sample<0,
                "actual_fixed_HEAD_attempts":operation_totals["r2_head"],"actual_fixed_GET_attempts":operation_totals["r2_get"],
                "actual_fixed_SQL_rows_read":fixed["do_rows_read"],"actual_fixed_SQL_rows_written":fixed["do_rows_written"],
                "actual_fixed_R2_deletes":fixed["r2_deletes"],"exact_fixed_receipt":fixed,
                "actual_first_timed_push_receipt":first["cloudflare_workload_delta"],
                "first_timed_push_SQLite_bytes_before":before["do_sqlite_bytes"],"first_timed_push_SQLite_bytes_after":after["do_sqlite_bytes"],
                "startup_receipt":final_services["by_phase"]["startup"],
                "final_SQLite_bytes":final_services["do_sqlite_bytes"],"final_R2_peak_bytes":final_services["r2_peak_bytes"],
                "observed_DO_instance_epoch_sequence":epochs,"observed_DO_instance_epoch_changes":len(epochs)-1,
                "observability_limit":"An observed epoch transition establishes an instance change. The trace does not enumerate every reopen, individual proof issuance/acceptance/fallback, or GC service route; no cause or hypothetical charge is inferred.",
                "final_observer_actual_binding_delta":observer,
                "final_observer_actual_counter_delta":{k:None if final_services.get(k) is None else final_services[k]-last["cloudflare_services_after"][k] for k in fixed},
                "final_manifest_retirement_keys":final["manifest"].get("garbage",[]),
                "pushes":pushes})

schema = []
for provider in PROVIDERS:
    for profile in PROFILES:
        rs = [r for r in records if r["provider"]==provider and r["profile"]==profile]
        if not rs:
            continue
        fields = ["actual_first_timed_push_receipt","first_timed_push_SQLite_bytes_before","first_timed_push_SQLite_bytes_after","startup_receipt","final_SQLite_bytes"]
        schema.append({"provider":provider,"profile":profile,"warmup_and_samples":{str(r["sample"]):{k:r[k] for k in fields} for r in rs},
            "all_first_push_schema_receipts_identical_across_warmup_and_samples":all(all(r[k]==rs[0][k] for k in fields[:4]) for r in rs),
            "all_final_SQLite_bytes_identical_across_warmup_and_samples":all(r["final_SQLite_bytes"]==rs[0]["final_SQLite_bytes"] for r in rs)})
(ROOT/"observable-lifecycle-review.json").write_text(json.dumps(records,indent=2)+"\n")
(ROOT/"warmup-first-DDL-and-SQLite-review.json").write_text(json.dumps(schema,indent=2)+"\n")
print(json.dumps({"actual_trial_records":len(records),"schema_profile_records":len(schema),"fixed_actual_HEAD_attempts":sum(r["actual_fixed_HEAD_attempts"] for r in records),"observed_DO_epoch_changes":sum(r["observed_DO_instance_epoch_changes"] for r in records)}))
