#!/usr/bin/env python3
"""Documentation-only packaging; never starts a service, build, or benchmark."""
import collections
import gzip
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

WT = pathlib.Path('/tmp/git-zero-hosting-socket-rpc')
SOURCE = 'c128197cc2cf1761e93832c63eec4c25c1268249'
OUT = WT / 'docs/benchmarks/hosting-cost-loop-2026-10-18/interleaved-v1/r17-worker-socket-rpc-candidate'
OUT.mkdir(parents=True, exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WT)

def digest(path):
    h = hashlib.sha256()
    size = 0
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
            size += len(b)
    return {'bytes': size, 'sha256': h.hexdigest()}

def jb(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def readj(path):
    return json.loads(pathlib.Path(path).read_text())

def gzwrite(path, data):
    with open(path, 'wb') as out:
        with gzip.GzipFile(filename='', mode='wb', fileobj=out, mtime=0) as z:
            z.write(data)

assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
HANDOFF = pathlib.Path('/tmp/git-zero-socket-rpc-review-handoff.json')
h = readj(HANDOFF)
review = readj('/tmp/git-zero-socket-rpc-source-review-final-c128197-inventory.json')
paired = readj('/tmp/git-zero-socket-final-c128-paired-control.json')
pair_review = readj('/tmp/git-zero-socket-final-c128-independent-pair-review.json')
fault_review = readj('/tmp/git-zero-socket-final-c128-independent-fault-review.json')
root_validation = readj('/tmp/git-zero-socket-final-c128-root-validation.json')

old_roots = list(h['artifact_roots'].values())
new_roots = [x['root'] for x in root_validation['runs'].values()]
roots = old_roots + new_roots
paths = set(pathlib.Path(p) for p in h['evidence_files'])
for root in roots:
    paths.update(p for p in pathlib.Path(root).rglob('*') if p.is_file() or p.is_symlink())
for pattern in ['git-zero-socket*.log', 'git-zero-socket*.json', 'git-zero-socket*.md', 'git-zero-socket-protocol-controls.rs', 'git-zero-worker-socket*.md', 'git-zero-worker-socket*.json']:
    paths.update(p for p in pathlib.Path('/tmp').glob(pattern) if p.is_file())
paths.update(pathlib.Path('/tmp') / p for p in [
    'git-zero-small-receive-source-review-603b224.md',
    'git-zero-small-receive-source-review-603b224-inventory.json',
    'git-zero-review-final-socket-pair.py',
])

# Include owning current Native/runner ELF files named by all retained maps.
# Earlier hashes at reused paths are historical identities, not retained earlier ELFs.
map_refs = []
for root in roots:
    for p in pathlib.Path(root).rglob('source-*.json'):
        data = readj(p)
        for key, value in data.items():
            if isinstance(value, dict) and 'path' in value and 'sha256' in value:
                q = pathlib.Path(value['path'])
                map_refs.append({'manifest': str(p), 'entry': key, **value})
                if q.is_file():
                    paths.add(q.resolve())

retained = []
members = {}
member_origins = {}

def add_bytes(name, data, origin):
    assert name not in members, name
    assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    members[name] = data
    member_origins[name] = origin

for p in sorted(paths, key=str):
    assert p.exists(), p
    assert not p.is_symlink(), ('unexpected symlink; explicit handling required', p)
    meta = digest(p)
    containing = next((r for r in roots if p.is_relative_to(r)), None)
    rel = p.relative_to(containing) if containing else None
    if p.suffix in ['.json', '.log', '.toml', '.md', '.rs', '.py'] and not (rel and ('persist' in rel.parts or any(x.endswith('.git') for x in rel.parts))):
        disposition = 'capsule'
        reason = 'compact original source, log, receipt, map, review, or JSON proof'
    elif rel and len(rel.parts) == 1 and meta['bytes'] <= 262144:
        disposition = 'capsule'
        reason = 'bounded original wire request, response, or header'
    else:
        disposition = 'local-hash-only'
        reason = ('current Native/runner ELF; earlier identities only as recorded in original maps' if 'target-j2' in str(p)
                  else 'generated Git fixture, workerd R2/SQLite state, or large original wire payload; complete local bytes retained')
    member = 'raw/' + str(p).lstrip('/') if disposition == 'capsule' else None
    item = {'path': str(p), **meta, 'publication': disposition, 'reason': reason, 'capsule_member': member}
    retained.append(item)
    if member:
        add_bytes(member, p.read_bytes(), str(p))

by_path = {x['path']: x for x in retained}
for p, expected in h['evidence_files'].items():
    actual = by_path[p]
    assert all(actual[k] == expected[k] for k in ['sha256', 'bytes']), p
fresh = review['independently_hashed_fresh_top_level_raw_files']
for item in fresh:
    actual = by_path[item['path']]
    assert all(actual[k] == item[k] for k in ['sha256', 'bytes']), item['path']
assert len(fresh) == 956 and sum(x['bytes'] for x in fresh) == 233677080

# Byte-exact c128 tracked code and build inputs, excluding unrelated old docs archives.
source_paths = ['Cargo.toml', 'Cargo.lock', 'LICENSE-APACHE', 'LICENSE-MIT', 'crates', 'src', 'tests', 'examples', 'docs/hosting-socket-rpc.md']
source_archive = git('archive', '--format=tar', SOURCE, *source_paths)
source_inventory = []
with tarfile.open(fileobj=io.BytesIO(source_archive), mode='r:') as archive:
    for item in archive:
        if not item.isfile():
            assert item.isdir(), item.name
            continue
        data = archive.extractfile(item).read()
        source_inventory.append({'path': item.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        add_bytes('source/' + item.name, data, 'git ' + SOURCE + ':' + item.name)
source_lookup = {x['path']: x for x in source_inventory}

# Match every exact-final source/config/lock/binary map to current bytes and capsule.
final_maps = []
for name, path in [
    ('production-first-gate', '/tmp/git-zero-socket-first-proof-final-02/production/source-before.json'),
    *[(k, v['root'] + '/source-before.json') for k, v in root_validation['runs'].items()],
]:
    d = readj(path)
    after = pathlib.Path(path).with_name('source-after.json')
    assert readj(after) == d, path
    verified = []
    for key, value in d.items():
        current = pathlib.Path(value['path']) if 'path' in value else WT / 'examples/repository-host' / key
        actual = digest(current)
        assert all(actual[k] == value[k] for k in ['bytes', 'sha256']), (path, key)
        if key not in ['native_binary', 'runner_binary']:
            tracked = 'Cargo.lock' if key == 'workspace_lock' else 'examples/repository-host/' + key
            assert all(source_lookup[tracked][k] == value[k] for k in ['bytes', 'sha256']), tracked
        verified.append(key)
    final_maps.append({'name': name, 'path': path, **digest(path), 'entries': len(verified), 'before_after_current_and_capsule_match': True})

dependency = readj('/tmp/git-zero-socket-rpc-dependency-audit.json')
dep_inventory = []
registry = pathlib.Path('/var/home/pawel/.cargo/registry/src')
for rel, expected in dependency['source_hashes'].items():
    candidates = list(registry.glob('*/' + rel))
    assert len(candidates) == 1, rel
    p = candidates[0]
    actual = digest(p)
    assert actual == expected, rel
    dep_inventory.append({'path': str(p), 'member': 'dependency-source/' + rel, **actual})
    add_bytes('dependency-source/' + rel, p.read_bytes(), str(p))
for rel in ['tungstenite-0.30.0/LICENSE-MIT', 'tungstenite-0.30.0/LICENSE-APACHE', 'bytes-1.12.1/LICENSE']:
    candidates = list(registry.glob('*/' + rel))
    assert len(candidates) == 1, rel
    p = candidates[0]
    dep_inventory.append({'path': str(p), 'member': 'dependency-source/' + rel, 'kind': 'license', **digest(p)})
    add_bytes('dependency-source/' + rel, p.read_bytes(), str(p))

for x in map_refs:
    p = pathlib.Path(x['path'])
    x['current_path_exists'] = p.is_file()
    x['current_path_matches_recorded_identity'] = p.is_file() and digest(p) == {k: x[k] for k in ['bytes', 'sha256']}

def totals(items):
    return {'files': len(items), 'bytes': sum(x['bytes'] for x in items)}

root_totals = []
for r in roots:
    files = [x for x in retained if pathlib.Path(x['path']).is_relative_to(r)]
    root_totals.append({'root': r, **totals(files), 'capsule': totals([x for x in files if x['publication'] == 'capsule']), 'local_hash_only': totals([x for x in files if x['publication'] == 'local-hash-only'])})
inventory = {
    'schema': 'r17-complete-retained-files-v1', 'source': SOURCE,
    'scope': 'All regular files recursively under all 12 R17 artifact roots, all historical handoff evidence, final raw evidence, relevant direct logs/reviews/design proofs and mapped currently retained Native/runner ELFs. No deleted or earlier overwritten source/ELF is invented.',
    'historical_handoff_verified': {'path': str(HANDOFF), **digest(HANDOFF), **totals(list(h['evidence_files'].values()))},
    'final_review_top_level_raw_verified': totals(fresh),
    'roots': root_totals, 'totals': totals(retained),
    'capsule': totals([x for x in retained if x['publication'] == 'capsule']),
    'local_hash_only': totals([x for x in retained if x['publication'] == 'local-hash-only']),
    'files': retained,
    'recorded_binary_and_lock_map_references': map_refs,
}
source_provenance = {'commit': SOURCE, 'parent': h['parent_commit'], 'native_src_tree': h['native_src_tree'], 'worker_src_tree': h['worker_src_tree'], 'files': source_inventory, 'exact_final_maps_verified': final_maps, 'dependency_source': dep_inventory}
add_bytes('provenance/source-manifest.json', jb(source_provenance), 'assembled from exact c128 tracked Git blobs and original maps')
add_bytes('provenance/retained-artifacts.json', jb(inventory), 'complete recursive original-file inventory')
add_bytes('provenance/source-commit.txt', git('show', '--format=fuller', '--stat', SOURCE), 'git show ' + SOURCE)
add_bytes('provenance/package-ledger.py', pathlib.Path(__file__).read_bytes(), str(pathlib.Path(__file__)))

evidence_refs = []
for p in [HANDOFF, pathlib.Path('/tmp/git-zero-socket-rpc-source-review-c128197.md'), pathlib.Path('/tmp/git-zero-socket-rpc-source-review-final-c128197.md'), pathlib.Path('/tmp/git-zero-socket-rpc-source-review-final-c128197-inventory.json'), *[pathlib.Path('/tmp/git-zero-socket-final-c128-' + n + '.json') for n in ['root-validation', 'paired-control', 'independent-pair-review', 'independent-fault-review']]]:
    evidence_refs.append({'path': str(p), **digest(p), 'capsule_member': by_path[str(p)]['capsule_member']})

ledger = {
    'schema': 'r17-worker-socket-rpc-candidate-v1',
    'status': 'Frozen source and local correctness independently approved. Compact ledger awaiting independent continuity review; no integration, benchmark selection, cost or speed acceptance.',
    'source': source_provenance | {'files': {'count': len(source_inventory), 'inventory': 'provenance/source-manifest.json inside capsule'}},
    'implementation': {
        'topology': 'Public Worker gateway -> local Rust Git codec -> authenticated Worker WebSocket service bridge -> existing Durable Object HTTP dispatch -> R2/SQLite',
        'worker_billing': 'Each actual Upgrade attempt charged in its triggering phase; subsequent application messages add no Worker request count.',
        'do_billing': 'One ordinary HTTP DO dispatch/receipt per application RPC; no DO socket, 20:1 discount, self-HTTP dispatch or receipt substitution.',
        'session_rpc_limit': 16, 'one_synchronous_outstanding_rpc_per_registration': True,
        'rfc_request_fragment_bytes': 16384, 'response_application_message_bytes': 16384,
        'joint_retained_budget_bytes': 33554432, 'transport_retained_reserve_bytes': 262144,
        'routes': [
            {'method': 'POST', 'route': 'blobs/read', 'request_limit_bytes': 1500000, 'response_limit_bytes': 16779276},
            {'method': 'POST', 'route': 'manifest/upload-retire', 'request_limit_bytes': 16779276, 'response_limit_bytes': 32768},
            {'method': 'PUT', 'route': 'blob/chunks/<64 lowercase hex>', 'request_limit_bytes': 16777216, 'response_limit_bytes': 32768},
        ],
        'http_compatibility': 'Registration/metrics/unknown routes and legacy scalar GET retain HTTP. Existing 128 MiB scalar cap unchanged. Known 404/426/429 Upgrade responses may select HTTP before application I/O; 401/409/500 or ambiguous attempts never replay.',
        'after_attempted_rpc': 'Drop failed/ambiguous connection; no resend or HTTP fallback. Next distinct operation may pay one new Upgrade, preserving same-Native dirty GC/proof barriers before PUT.',
        'capability_reset': 'Reset transport and related capabilities before registration I/O. Exact opt-in capability independent of gateway first-read. Old/absent capability uses HTTP.',
        'stale_registration': 'Captured registration identity checked before dispatch and around awaits; passive cross-request close remains best effort.',
        'dependency': 'tungstenite =0.30.0; default-features=false, handshake only. 20 added locked packages, existing versions preserved. Declared MSRV audit only; no independently executed Rust 1.85 build.',
    },
    'exact_final_correctness': {
        'maps': final_maps,
        'first_gate': {'root': '/tmp/git-zero-socket-first-proof-final-02', 'passed_rust_tests': 3, 'seconds_test_runtime_only': 44.01, 'protocol_cases': 21, 'http_Worker_DO_requests': [2, 2], 'socket_Worker_DO_requests': [1, 2], 'physical_PUT_GET_bytes_each': 40, 'SQL_rows_read_written_both': [15, 3]},
        'maximum': {'put_and_bulk_bytes': 16777216, 'metadata_bytes': 1500000, 'whole_GZUP_bytes': 16779276, 'one_byte_over_unsupported_pre_application_io': True, 'rpcs': 34, 'paid_upgrades': 3, 'rotations': 2, 'request_RFC_frames': 1091, 'response_binary_messages': 1125, 'ack_frames': 34, 'retained_requested_delta_after_put': 16230, 'retained_requested_delta_after_get_and_output_drop': 32614, 'transient_live_requested_peak_bytes': 50501711, 'allocator_scope': 'Transparent test-only System allocator requested live owning allocations, including caller fixture/transient copies. Not RSS or Worker-isolate total.'},
        'real_git_runs': {'socket_on': {'root': new_roots[0], 'seconds_test_runtime_only': 76.64}, 'socket_off': {'root': new_roots[1], 'seconds_test_runtime_only': 45.28}, 'ambiguous_fault_matrix': {'root': new_roots[2], 'seconds_test_runtime_only': 158.44, 'rows': 29}},
        'paired_push_rows': paired['rows'],
        'public_bodies_byte_identical': 11,
        'first_Upgrade_paid_then_worker_requests_saved_each_later_push': [0, 1, 1, 1, 1, 1, 1, 1],
        'physical_DO_R2_SQL_and_history_certificate_equal_all_8_pushes': True,
        'six_contract_stages_physical_equal': True,
        'separate_projected_thin_restore': {'on_then_off_actual_deltas_including_observers': pair_review['projection_to_Full_receive_physical_deltas'], 'Projection_to_Full_once': True},
        'fault_rows': fault_review['rows'],
        'socket_post_CAS_fault_modes': fault_review['socket_ambiguous_reply_cases'],
        'each_post_CAS_fault': 'Actual one upload PUT + one CAS, one logical 503/22 bytes, no replay. Same Native next distinct operation: one fresh paid Upgrade and physical /_services/gc list before next PUT; strict fsck/archive recovery assertions passed.',
        'normal_fixture_SQLite_limit_bytes': 24576,
        'library_passed': 119, 'library_seconds_test_runtime_only': 56.93, 'clippy_all_targets_passed': True, 'clippy_seconds_test_runtime_only': 8.05,
        'old_Native_and_warm_scope': 'Structurally preserved common HTTP path and independent opt-in. No final-source old-Native binary or warm-host Git runtime claimed.',
    },
    'historical_runs': h['artifact_roots'],
    'historical_scope': 'Original handoff and source maps remain immutable. Earlier real Git d23b1... and matrix 2ff956... lack retained byte-exact historical source snapshots; do not relabel them final or assert an unverified telemetry-only delta. Fresh exact c128 controls close the behavior gap. Historical continuity JSON predates final socket telemetry and is not a complete final-source diff.',
    'retained_failed_attempts': h['retained_failures'],
    'counter_scope': 'First private unknown-SQL row changes known rows to NULL while accounting_complete=true. Missing receipt next makes completeness false. Later body/socket rows inherit sticky NULL/incomplete and do not prove fresh per-case transitions. Actual known counters/traces/mutations/recovery remain retained. Metrics/reconnect never replace lost receipts or restore unknowns to zero.',
    'publication': {k: inventory[k] for k in ['scope', 'totals', 'capsule', 'local_hash_only', 'roots', 'historical_handoff_verified', 'final_review_top_level_raw_verified']},
    'evidence_references': evidence_refs,
    'limitations': [
        'Local pinned workerd plus Rust correctness controls only; no production Cloudflare deployment or latency benchmark.',
        'Worker CPU, DO duration, monthly SQLite retention and external Native compute remain UNKNOWN/NULL; elapsed wall time is not CPU billing.',
        'No pricing/scorer/objective/fixture/cap changes and no net cost, speed, promotion, plateau or stopping claim.',
        'No many-repository or hostile-authenticated-peer total Worker-memory capacity proof.',
        'Large wire payloads, generated Git fixtures, all R2/SQLite persisted state and current ELF files remain local hash-only. Compact capsule is not a self-contained offline replay environment or cloud backup.',
        'Prospective two-pair cost/performance screens per optimization and mandatory five fresh original-R1/final pairs across all four profiles remain separate work.',
    ],
    'full_bill': None, 'measured_net_cost_saving': None, 'measured_speed_improvement': None, 'benchmark_candidate_accepted': False,
}
add_bytes('provenance/implementation.json', jb(ledger), 'compact scoped ledger')
(OUT / 'implementation.json').write_bytes(jb(ledger))
gzwrite(OUT / 'retained-artifacts.json.gz', jb(inventory))
gzwrite(OUT / 'source-manifest.json.gz', jb(source_provenance))
(OUT / 'source-review.md').write_bytes(pathlib.Path('/tmp/git-zero-socket-rpc-source-review-final-c128197.md').read_bytes())

member_inventory = [{'member': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'origin': member_origins[name]} for name, data in sorted(members.items())]
gzwrite(OUT / 'capsule-members.json.gz', jb(member_inventory))
capsule = OUT / 'correctness-evidence.tar.gz'
with capsule.open('wb') as out:
    with gzip.GzipFile(filename='', mode='wb', fileobj=out, mtime=0) as zipped:
        with tarfile.open(mode='w|', fileobj=zipped, format=tarfile.PAX_FORMAT) as archive:
            for name, data in sorted(members.items()):
                item = tarfile.TarInfo(name)
                item.size = len(data)
                item.mode = 0o644
                item.mtime = item.uid = item.gid = 0
                item.uname = item.gname = ''
                archive.addfile(item, io.BytesIO(data))

# Every actual archive member is reopened and read byte-for-byte; inventory exact set.
expected = {x['member']: x for x in member_inventory}
seen = set()
with tarfile.open(capsule, 'r:gz') as archive:
    for item in archive:
        assert item.isfile() and item.name not in seen
        assert not item.name.startswith('/') and '..' not in pathlib.PurePosixPath(item.name).parts
        data = archive.extractfile(item).read()
        assert len(data) == expected[item.name]['bytes'] == item.size
        assert hashlib.sha256(data).hexdigest() == expected[item.name]['sha256']
        seen.add(item.name)
assert seen == set(expected)
verification = {
    'kind': 'Documentation packaging verification only; no runtime/build/test/benchmark performed',
    'source': SOURCE, 'source_maps_verified': final_maps,
    'historical_original_files_rehashed': 479,
    'fresh_final_top_level_files_rehashed': 956,
    'all_retained_files_rehashed': inventory['totals'],
    'capsule_all_members_read_verified': totals(member_inventory),
    'capsule_member_set_exact': True, 'duplicates_or_unsafe_paths': False,
    'capsule': {'name': capsule.name, **digest(capsule)},
    'large_local_only_files': inventory['local_hash_only'],
    'all_12_recursive_artifact_roots_inventoried': True,
    'tracked_source_capsule': totals(source_inventory),
    'audited_dependency_source_files_verified': len(dependency['source_hashes']),
    'dependency_license_files_retained': 3,
    'independent_ledger_review': 'pending', 'full_bill': None,
}
(OUT / 'verification.json').write_bytes(jb(verification))
print(json.dumps({'directory': str(OUT), 'retained': inventory['totals'], 'packaged_raw': inventory['capsule'], 'local_only': inventory['local_hash_only'], 'source': totals(source_inventory), 'capsule_members': totals(member_inventory), 'capsule': digest(capsule), 'map_entries': [x['entries'] for x in final_maps]}, indent=2))
