import { readBytes } from "./bytes.mjs";

const encoder = new TextEncoder();
const decoder = new TextDecoder("utf-8", { fatal: true });
export const MAX_SNAPSHOT_BYTES = 8192;
const MAX_RECORD_BYTES = MAX_SNAPSHOT_BYTES + 128;

export class SnapshotError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

export function decodeSnapshot(bytes, version = 1) {
  if (bytes.length > MAX_SNAPSHOT_BYTES) throw new Error("Snapshot exceeds 8 KiB");
  const payload = JSON.parse(decoder.decode(bytes));
  let parts;
  if (version === 1) parts = payload;
  else if (version === 2 && payload?.version === 2 && payload.layout === "tree" && payload.format === "sha1") parts = payload.parts;
  else throw new Error("Invalid snapshot version or layout");
  if (!Array.isArray(parts) || parts.length !== 4 || parts.some((part) => typeof part !== "string")) {
    throw new Error("Invalid snapshot data");
  }
  return parts;
}

function binding(env, backend) {
  const value = backend === "kv" ? env.SNAPSHOTS_KV : backend === "r2" ? env.SNAPSHOTS_R2 : undefined;
  if (!value || typeof value.get !== "function" || typeof value.put !== "function") {
    throw new SnapshotError("Snapshot storage is not configured", 503);
  }
  return value;
}

async function digest(bytes) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))]
    .map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function persistSnapshot(bytes, env, version = 1) {
  const backend = env.SNAPSHOT_STORAGE;
  const store = binding(env, backend);
  const ttl = Number(env.SNAPSHOT_TTL_SECONDS ?? 86400);
  if (!Number.isSafeInteger(ttl) || ttl < 60 || ttl > 31536000) {
    throw new SnapshotError("Snapshot retention must be 60 through 31536000 seconds", 503);
  }
  // The expiry is part of the immutable, authenticated record. Recreating the
  // same files later cannot revive an expired URL or replace its contents.
  const expiresAt = Math.floor(Date.now() / 1000) + ttl;
  const parts = decodeSnapshot(bytes, version);
  const record = encoder.encode(JSON.stringify(version === 1 ? { version, expiresAt, parts }
    : { version, expiresAt, layout: "tree", format: "sha1", parts }));
  const id = await digest(record);
  try {
    if (backend === "kv") await store.put(`snapshots/v${version}/${id}`, record.buffer, { expirationTtl: ttl });
    else await store.put(`snapshots/v${version}/${id}`, record, { sha256: id, httpMetadata: { contentType: "application/json" } });
  } catch {
    throw new SnapshotError("Snapshot storage is unavailable", 503);
  }
  return { path: `/s/${version === 1 ? "" : "v2/"}${backend}/${id}/repo.git`, expiresAt };
}

export async function loadSnapshot(env, backend, id, version = 1) {
  const store = binding(env, backend);
  let stored;
  try {
    stored = await store.get(`snapshots/v${version}/${id}`, ...(backend === "kv" ? ["stream"] : []));
  } catch {
    throw new SnapshotError("Snapshot storage is unavailable", 503);
  }
  if (stored === null) throw new SnapshotError("Snapshot not found, expired or not yet available", 404);
  let record;
  try {
    const bytes = await readBytes(backend === "kv" ? stored : stored.body, MAX_RECORD_BYTES);
    if (await digest(bytes) !== id) throw new Error("Stored snapshot digest mismatch");
    record = JSON.parse(decoder.decode(bytes));
    if (record.version !== version || !Number.isSafeInteger(record.expiresAt)) throw new Error("Invalid stored snapshot");
    // Reuse the inline format's schema and size limit after unwrapping storage.
    record.parts = decodeSnapshot(encoder.encode(JSON.stringify(version === 1 ? record.parts : {
      version: record.version, layout: record.layout, format: record.format, parts: record.parts,
    })), version);
  } catch {
    throw new SnapshotError("Stored snapshot failed integrity validation", 502);
  }
  if (record.expiresAt <= Math.floor(Date.now() / 1000)) throw new SnapshotError("Snapshot expired", 410);
  return record.parts;
}
