from pathlib import Path
import json,hashlib,subprocess
work=Path('/tmp/git-zero-hosting-socket-rpc');on=Path('/tmp/git-zero-socket-final-c128-git-on-01');off=Path('/tmp/git-zero-socket-final-c128-git-off-01');source='c128197cc2cf1761e93832c63eec4c25c1268249'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==source
base=(on/'source-before.json').read_bytes()
for p in [on/'source-after.json',off/'source-before.json',off/'source-after.json']: assert p.read_bytes()==base
m=json.loads(base);sourcefiles=0
for rel,v in m.items():
 if rel in ['native_binary','runner_binary','workspace_lock']:p=Path(v['path'])
 else:p=work/'examples/repository-host'/rel
 data=p.read_bytes();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256'];sourcefiles+=1
keys=['worker_requests','worker_service_requests','worker_gateway_requests','worker_observer_requests','do_requests','r2_class_a','r2_class_b','r2_deletes','r2_read_bytes','r2_written_bytes','do_rows_read','do_rows_written'];physical=keys[4:];rows=[]
for i in range(1,9):
 name=f'small-push-{i}-receipt.json';r={}
 for mode,folder in [('on',on),('off',off)]:
  x=json.loads((folder/name).read_text());a=x['after']['cloudflare_services'];b=x['before']['cloudflare_services'];assert a['accounting_complete'] and b['accounting_complete'];assert a['counter_epoch']==b['counter_epoch'];r[mode]={k:a[k]-b[k] for k in keys};assert x['after']['cache_retained_bytes']<=32*1024*1024
  r[mode+'_joint_bytes']=x['after']['cache_retained_bytes'];r[mode+'_history_bytes']=x['after']['history_lineage_bytes']
 assert all(r['on'][k]==r['off'][k] for k in physical);assert r['on_history_bytes']==r['off_history_bytes'];saved=r['off']['worker_requests']-r['on']['worker_requests'];assert saved==(0 if i==1 else 1),(i,saved)
 rows.append({'name':name,**r,'worker_requests_saved':saved})
bodies=[]
for name in ['retirement-5-immediate.body','discovery.body','latest.body','history-no-haves.body','history-with-haves.body','latest-recheck.body','history-before-large.body','partial-noop.body','large-latest.body','final-history.body','small-project-start.body']:
 data=(on/name).read_bytes();assert data==(off/name).read_bytes();bodies.append(dict(name=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
out=dict(kind='Exact frozen final-source same-fixture socket on/off correctness topology; no benchmark cost/latency score',source=source,on=str(on),off=str(off),source_manifest_sha256=hashlib.sha256(base).hexdigest(),source_files_and_binaries_checked=sourcefiles,native_binary_sha256=m['native_binary']['sha256'],runner_binary_sha256=m['runner_binary']['sha256'],rows=rows,identical_public_body_files=bodies,full_bill=None)
p=Path('/tmp/git-zero-socket-final-c128-paired-control.json');p.write_text(json.dumps(out,indent=2)+'\n');print('PASS',str(p),'sha256',hashlib.sha256(p.read_bytes()).hexdigest(),'8 actualpairs/allphysicalDO-R2-SQLequal/11bodiesidentical',sourcefiles,'exactsource/binarymaps')
