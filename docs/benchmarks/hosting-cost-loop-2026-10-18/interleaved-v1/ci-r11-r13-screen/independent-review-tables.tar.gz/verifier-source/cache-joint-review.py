"""Reconstruct actual joint retained-byte gauges from final anchor and deltas."""
import json
from pathlib import Path

ROOT = Path(__file__).parent / "run-39097951585"
PROVIDERS = ["r11", "r111", "r12", "r13"]
PROFILES = ["16mib-cold", "16mib-warm", "64mib-cold", "64mib-warm"]
records, rows_out = [], []
initial_by_provider_cache = {}
for provider in PROVIDERS:
    for profile in PROFILES:
        if not (ROOT/"profiles"/profile/"checksum-verification.txt").exists():
            continue
        report=json.loads((ROOT/"profiles"/profile/provider/f"{profile}.json").read_text())
        for sample in [-1,0,1]:
            rows=[r for r in report["raw"] if r["backend"]=="cloudflare-local" and r["sample"]==sample]
            final=next(r for r in report["cloudflare_runs"] if r["sample"]==sample)["final_object_stats"]
            cache=rows[-1]["server_cache_after_fetch"]
            assert final["cache_bytes"]==cache["resident_bytes"]
            assert final["cache_entries"]==cache["entries"]
            assert final["cache_evictions"]==sum(r["service_metrics_delta"]["cache_evictions"] for r in rows)
            names=["cache_retained_bytes","cache_bytes","cache_entries","history_lineage_bytes",
                   "history_pending_lineage_bytes","upload_advertisement_template_bytes"]
            initial={k:final[k]-sum(r["service_metrics_delta"].get(k,0) for r in rows) for k in names}
            assert initial["cache_bytes"]==initial["cache_entries"]==0
            assert all(v>=0 for v in initial.values())
            identity=(provider,profile.split("-")[1])
            assert initial_by_provider_cache.setdefault(identity,initial)==initial,(identity,sample,initial)
            current=dict(initial)
            peak=0
            for row in rows:
                for key in current:
                    current[key]+=row["service_metrics_delta"].get(key,0)
                cache=row.get("server_cache_after_fetch",row.get("server_cache_after_push"))
                assert current["cache_bytes"]==cache["resident_bytes"]
                assert current["cache_entries"]==cache["entries"]
                assert current["cache_retained_bytes"] <= 33554432
                assert 0<=current["cache_bytes"]<=current["cache_retained_bytes"]
                assert 0<=current["cache_entries"]<=256
                peak=max(peak,current["cache_retained_bytes"])
                rows_out.append({"provider":provider,"profile":profile,"sample":sample,"operation":row["operation"]["key"],
                    "actual_joint_gauge_reconstructed":dict(current)})
            assert current=={k:final[k] for k in names}
            records.append({"provider":provider,"profile":profile,"sample":sample,"initial_actual_gauges_derived":initial,
                "maximum_observed_joint_retained_bytes":peak,"final_retained_bytes":final["cache_retained_bytes"],
                "joint_cap_bytes":33554432,"entry_cap":256,"single_cached_response_cap_bytes":16777216,
                "final_observer_changed_cache_bytes_or_entries_or_evictions":False})
completed_profiles=[p for p in PROFILES if (ROOT/"profiles"/p/"checksum-verification.txt").exists()]
assert len(records)==12*len(completed_profiles) and len(rows_out)==1056*len(completed_profiles)
(ROOT/"joint-cache-operation-gauges.json").write_text(json.dumps(rows_out,indent=2)+"\n")
(ROOT/"joint-cache-review.json").write_text(json.dumps({
    "method":"The frozen source's final full-view observer restores objects without changing response cache or valid same-manifest lineage allocation. Final actual gauges anchor the contiguous per-operation numeric deltas. Final response bytes/entries and zero observer eviction are independently checked, and initial gauges must agree across all same-provider/cache profiles and trials.",
    "completed_profiles":completed_profiles,"observed_operations":len(rows_out),"trials":records,"every_observed_joint_gauge_within_cap":True},indent=2)+"\n")
print(json.dumps({"observed_operations":len(rows_out),"trials":len(records),"largest_actual_joint_gauge_bytes":max(r["maximum_observed_joint_retained_bytes"] for r in records)}))
