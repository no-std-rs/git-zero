import json
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).parent
previous = None
while True:
    result = subprocess.run(["python3", str(HERE / "monitor-once.py")], text=True, capture_output=True, timeout=55)
    if result.returncode:
        print(result.stdout, result.stderr, flush=True)
        raise SystemExit(result.returncode)
    state = json.loads(result.stdout)
    signature = [(j["name"],j["status"],j["conclusion"],j["active_step"]) for j in state["jobs"]]
    if signature != previous or state["new_downloads"]:
        print(result.stdout.strip(), flush=True)
        previous = signature
    if state["new_downloads"]:
        validation = subprocess.run(["python3", str(HERE / "validate-profiles.py")], text=True, capture_output=True, timeout=55)
        print(validation.stdout, validation.stderr, flush=True)
        if validation.returncode:
            (HERE / "run-39097951585" / "validation-failure.txt").write_text(validation.stdout + validation.stderr)
            print("VALIDATION FAILED: preserve this failure and continue downloading the remaining run artifacts.", flush=True)
    if state["status"] == "completed":
        print("MONITOR COMPLETE: " + str(state["conclusion"]), flush=True)
        break
    time.sleep(180)
