"""Recheck original hashes and package only derived review tables/provenance."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).parent
ROOT = BASE / "run-39097951585"
assert json.loads((ROOT/"run.json").read_text())["conclusion"] == "success"
assert json.loads((ROOT/"distribution-review.json").read_text())["all_screen_inconclusive"]
original_count = 0
for directory in [*(ROOT/"profiles").iterdir(),ROOT/"scores"]:
    for line in (directory/"SHA256SUMS").read_text().splitlines():
        expected,relative = line.split("  ",1)
        path = (directory/relative).resolve()
        assert path.is_relative_to(directory.resolve())
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected,(directory,relative)
        original_count += 1
(ROOT/"original-artifact-final-reverification.json").write_text(json.dumps({
    "all_original_internal_hashes_reverified_after_all_analysis":True,
    "original_file_checksums":original_count,"raw_reports":16,
    "original_reports_mutated":False},indent=2)+"\n")

source = ROOT/"verifier-source"
source.mkdir(exist_ok=True)
for path in BASE.glob("*.py"):
    shutil.copyfile(path,source/path.name)
(source/"LOCATION.json").write_text(json.dumps({
    "executed_script_directory":str(BASE),"raw_directory":str(ROOT),
    "scope":"Python scripts are offline evidence analysis and GitHub read-only artifact monitoring. Only the pre-existing Rust CI runner performs benchmarks."},indent=2)+"\n")
derived = sorted(p for p in ROOT.rglob("*") if p.is_file()
                 and p.relative_to(ROOT).parts[0] not in {"profiles","downloads","scores"}
                 and p.name not in {"SHA256SUMS","DERIVED_SHA256SUMS","independent-review-tables.tar.gz"})
manifest = ROOT/"DERIVED_SHA256SUMS"
manifest.write_text("".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}\n" for p in derived))
bundle = ROOT/"independent-review-tables.tar.gz"
with bundle.open("wb") as raw:
    with gzip.GzipFile(fileobj=raw,mode="wb",mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode="w") as archive:
            for path in [*derived,manifest]:
                info=archive.gettarinfo(str(path),arcname=str(path.relative_to(ROOT)))
                info.mtime=0
                with path.open("rb") as stream:
                    archive.addfile(info,stream)
all_files = sorted(p for p in ROOT.rglob("*") if p.is_file() and p != ROOT/"SHA256SUMS")
(ROOT/"SHA256SUMS").write_text("".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}\n" for p in all_files))
print(json.dumps({"original_internal_hashes_reverified":original_count,
    "derived_files":len(derived),"all_files_hashed":len(all_files),
    "compressed_tables_bytes":bundle.stat().st_size,
    "compressed_tables_sha256":hashlib.sha256(bundle.read_bytes()).hexdigest(),
    "path":str(bundle)}))
