"""Reproduce CI with the already frozen evaluator; never runs a benchmark."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).parent / "run-39097951585"
EVALUATOR = Path("/tmp/git-zero-hosting-loop-artifacts/interleaved-v1/evaluators/zero-get-fix/hosting-cost")
EVALUATOR_SHA = "01b36df2f5f2019eeb09ebe79eb8ae80e9f86d0cdf39667c9fec9b0584e61fb8"
PROVIDERS = ["r11", "r111", "r12", "r13"]
PROFILES = ["16mib-cold", "16mib-warm", "64mib-cold", "64mib-warm"]
OFFLINE = ROOT / "offline"
assert hashlib.sha256(EVALUATOR.read_bytes()).hexdigest() == EVALUATOR_SHA
expected = json.loads((ROOT / "expected-source-identities.json").read_text())
frozen_source = Path("/tmp/git-zero-hosting-cost-loop")
assert subprocess.check_output(["git", "-C", str(frozen_source), "rev-parse", "HEAD"], text=True).strip() == expected["head"]
assert subprocess.check_output(["git", "-C", str(frozen_source), "status", "--porcelain"], text=True) == ""
for source_path in ["examples/repository-host/src/bin/hosting-cost.rs", "examples/repository-host/src/benchmark_cost.rs"]:
    assert hashlib.sha256((frozen_source/source_path).read_bytes()).hexdigest() == expected["sources"][source_path]["current_sha256"]
assert hashlib.sha256((frozen_source/expected["pricing_source"]["path"]).read_bytes()).hexdigest() == expected["pricing_source"]["current_sha256"]
assert expected["pricing_source"]["current_sha256"] == expected["pricing_source"]["prior_sha256"]
for path in ["examples/repository-host/src/bin/hosting-cost.rs", "examples/repository-host/src/benchmark_cost.rs"]:
    assert expected["sources"][path]["current_sha256"] == expected["sources"][path]["prior_sha256"]
assert len(json.loads((ROOT / "independent-validation.json").read_text())["profiles"]) == 4
assert json.loads((ROOT / "run.json").read_text())["conclusion"] == "success"
score_provenance = (ROOT / "scores" / "provenance.txt").read_text()
for line in ["commit="+expected["head"],"stage=screen","run_id=39097951585","run_attempt=1"]:
    assert line in score_provenance.splitlines(), line
assert (ROOT / "scores" / "providers.tsv").read_bytes() == (ROOT / "profiles" / "16mib-cold" / "provenance" / "providers.tsv").read_bytes()
score_hashes = {name:digest for digest,name in re.findall(r"^([0-9a-f]{64})  (.+)$",score_provenance,re.M)}
common = json.loads((ROOT / "independent-validation.json").read_text())["common_hashes"]
assert score_hashes["target/release/hosting-cost"] == common[next(k for k in common if k.endswith("/bin/common/hosting-cost"))]
for profile in PROFILES:
    archive = next((ROOT / "downloads" / f"hosting-screen-{profile}-1").glob("*.tar.gz"))
    recorded = next(digest for name,digest in score_hashes.items() if name.endswith("/"+archive.name))
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == recorded
OFFLINE.mkdir(exist_ok=True)
scopes = {(r["provider"],r["profile"],r["sample"]):r for r in json.loads((ROOT/"counter-scopes.json").read_text())}
identical = []
for p in PROVIDERS:
    reports = [str(ROOT / "profiles" / profile / p / f"{profile}.json") for profile in PROFILES]
    output = OFFLINE / f"{p}-score.json"
    subprocess.run([str(EVALUATOR), "--output", str(output), *reports], check=True)
    assert output.read_bytes() == (ROOT / "scores" / output.name).read_bytes(), output.name
    identical.append(output.name)
    score = json.loads(output.read_text())
    assert score["total_estimate_usd"] is None
    for profile, ps in score["profiles"].items():
        # The scorer hashes serde_json::to_vec(parsed_report), not original file bytes.
        # Regeneration above reproduces this canonical fingerprint from the unchanged raw file;
        # archive checksums and RAW_SHA256SUMS independently cover original file bytes.
        assert len(ps["source_report_sha256"]) == 64
        assert ps["source_report_sha256"] == json.loads((ROOT / "scores" / f"{p}-score.json").read_text())["profiles"][profile]["source_report_sha256"]
        assert ps["total_estimate_usd"] is None
        for trial in ps["trials"]:
            assert trial["fixed_workload"] == scopes[(p,profile,trial["sample"])]["fixed_workload"]
    for earlier in PROVIDERS[:PROVIDERS.index(p)]:
        output = OFFLINE / f"{p}-vs-{earlier}.json"
        subprocess.run([str(EVALUATOR), "--baseline", str(OFFLINE / f"{earlier}-score.json"), "--output", str(output), *reports], check=True)
        assert output.read_bytes() == (ROOT / "scores" / output.name).read_bytes(), output.name
        value = json.loads(output.read_text())
        assert value["score"] == score
        assert value["comparison"]["decision"] == "inconclusive"
        assert value["comparison"]["eligible_rejected_candidate_for_plateau"] is False
        identical.append(output.name)
provenance = {"unchanged_source_sha256":{path:expected["sources"][path]["current_sha256"] for path in ["examples/repository-host/src/bin/hosting-cost.rs","examples/repository-host/src/benchmark_cost.rs"]} | {expected["pricing_source"]["path"]:expected["pricing_source"]["current_sha256"]},"path":str(EVALUATOR),"sha256":EVALUATOR_SHA,"same_evaluator_source_as_ci":True,"four_scores_and_six_comparisons_byte_identical_to_ci":True,"identical_files":identical}
(OFFLINE / "evaluator-provenance.json").write_text(json.dumps(provenance,indent=2)+"\n")
result = subprocess.run(["python3",str(ROOT / "summarize-chain.py")],capture_output=True,text=True,check=True)
(ROOT / "summary-console.json").write_text(result.stdout)
summary = json.loads((ROOT / "summary.json").read_text())
print(json.dumps({"identical_scores":4,"identical_comparisons":6,"scores":summary["scores"],"comparisons":[{"name":c["name"],"conservative_dollar_threshold_passed":c["conservative_dollar_threshold_passed"],"resource_guard_failures":c["resource_guard_failures"],"profile_cost_failures":c["failed_profile_cost_guards"],"latency_failures":len(c["latency_guard_failures"]),"decision":c["comparison"]["decision"]} for c in summary["comparisons"]]}))
