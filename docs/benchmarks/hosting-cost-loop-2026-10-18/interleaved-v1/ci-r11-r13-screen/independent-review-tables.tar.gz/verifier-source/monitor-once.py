import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from datetime import datetime, timezone, timedelta

RUN = 39097951585
HEAD = "5c616c23469fff9c7f64789dc29dc640bbc0dfc1"
ROOT = Path(__file__).parent / f"run-{RUN}"
REPO = "no-std-rs/git-zero"
MAX_ARCHIVE = 4 * 1024 * 1024

def gh(*args):
    return subprocess.check_output(["gh", *args], text=True)

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n")

def verify_checksums(directory):
    lines = (directory / "SHA256SUMS").read_text().splitlines()
    verified = []
    for line in lines:
        digest, rel = line.split("  ", 1)
        target = (directory / rel).resolve()
        assert target.is_relative_to(directory.resolve()), rel
        assert target.is_file(), rel
        assert hashlib.sha256(target.read_bytes()).hexdigest() == digest, rel
        verified.append(rel)
    files = {str(p.relative_to(directory)) for p in directory.rglob("*") if p.is_file()}
    assert files == {p.removeprefix("./") for p in verified} | {"SHA256SUMS"}
    (directory / "checksum-verification.txt").write_text(f"All {len(lines)} checksums independently verified.\n")
    return len(lines)

ROOT.mkdir(parents=True, exist_ok=True)
run = json.loads(gh("api", f"repos/{REPO}/actions/runs/{RUN}"))
assert run["head_sha"] == HEAD
assert run["run_attempt"] == 1
save("run.json", run)
jobs = json.loads(gh("api", f"repos/{REPO}/actions/runs/{RUN}/jobs"))
save("jobs.json", jobs)
inventory = json.loads(gh("api", f"repos/{REPO}/actions/runs/{RUN}/artifacts"))
save("artifact-index.json", inventory)
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
(ROOT / "progress").mkdir(exist_ok=True)
save("progress/"+stamp+"-snapshot.json", {"run":run,"jobs":jobs,"artifact_index":inventory})
downloaded = []
assert inventory["total_count"] <= 5
assert len({a["name"] for a in inventory["artifacts"]}) == len(inventory["artifacts"])
for artifact in inventory["artifacts"]:
    assert artifact["workflow_run"]["id"] == RUN
    assert artifact["workflow_run"]["head_sha"] == HEAD
    created = datetime.fromisoformat(artifact["created_at"].replace("Z", "+00:00"))
    expires = datetime.fromisoformat(artifact["expires_at"].replace("Z", "+00:00"))
    assert expires - created <= timedelta(days=1, minutes=5)
    name = artifact["name"]
    assert name.startswith("hosting-") and name.endswith("-1"), name
    assert not artifact["expired"], name
    directory = ROOT / "downloads" / name
    if not any(directory.glob("*.tar.gz")):
        directory.mkdir(parents=True, exist_ok=True)
        gh("run", "download", str(RUN), "--repo", REPO, "--name", name, "--dir", str(directory))
    archives = list(directory.glob("*.tar.gz"))
    assert len(archives) == 1, name
    archive = archives[0]
    assert archive.stat().st_size <= MAX_ARCHIVE, archive
    if name.startswith("hosting-scores-"):
        target = ROOT / "scores"
    else:
        profile = name.removeprefix("hosting-screen-").removesuffix("-1")
        assert profile in ["16mib-cold", "16mib-warm", "64mib-cold", "64mib-warm"], name
        target = ROOT / "profiles" / profile
    if not (target / "checksum-verification.txt").exists():
        target.mkdir(parents=True, exist_ok=True)
        with tarfile.open(archive) as tar:
            for member in tar.getmembers():
                assert member.isfile() or member.isdir(), member.name
                assert (target / member.name).resolve().is_relative_to(target.resolve()), member.name
            tar.extractall(target, filter="data")
        checksums = verify_checksums(target)
        downloaded.append({"name": name, "bytes": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "checksums": checksums})
archives = list((ROOT / "downloads").rglob("*.tar.gz"))
assert len(archives) <= 5
total_bytes = sum(a.stat().st_size for a in archives)
assert total_bytes <= 20 * 1024 * 1024
result = {"run": RUN, "status": run["status"], "conclusion": run["conclusion"], "jobs": [{"name": j["name"], "status": j["status"], "conclusion": j["conclusion"], "active_step": next((s["name"] for s in j["steps"] if s["status"] == "in_progress"), None)} for j in jobs["jobs"]], "new_downloads": downloaded, "archives": len(archives), "total_bytes": total_bytes}
save("monitor-state.json", result)
print(json.dumps(result))
