import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parent / "run-39097951585"
inventory = json.loads((ROOT / "artifact-index.json").read_text())
artifacts = []
for artifact in inventory["artifacts"]:
    archive = next((ROOT / "downloads" / artifact["name"]).glob("*.tar.gz"))
    artifacts.append({"artifact_id":artifact["id"],"name":artifact["name"],"api_zip_bytes":artifact["size_in_bytes"],"tar_gz_bytes":archive.stat().st_size,"sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"path":str(archive.relative_to(ROOT))})
assert len(artifacts) == 5
assert all(a["tar_gz_bytes"] <= 4194304 for a in artifacts)
assert sum(a["tar_gz_bytes"] for a in artifacts) <= 20971520
(ROOT / "archive-validation.json").write_text(json.dumps({"per_archive_cap_bytes":4194304,"total_cap_bytes":20971520,"total_archive_bytes":sum(a["tar_gz_bytes"] for a in artifacts),"artifacts":artifacts},indent=2)+"\n")
raw = sorted((ROOT / "profiles").glob("*/*/*mib-*.json"))
assert len(raw) == 16
(ROOT / "RAW_SHA256SUMS").write_text("".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}\n" for p in raw))
validation = json.loads((ROOT / "independent-validation.json").read_text())
boots = [r["boot_id"] for r in validation["profiles"]]
assert len(boots) == len(set(boots)) == 4
assert len(validation["profiles"]) == 4
review = {
    "run_id":39097951585,"attempt":1,"head":"5c616c23469fff9c7f64789dc29dc640bbc0dfc1","run_url":"https://github.com/no-std-rs/git-zero/actions/runs/39097951585",
    "benchmark_execution":"Free standard ubuntu-24.04 GitHub-hosted VMs; local workerd/R2/SQLite only; no local measurements or paid production deployment by verifier.",
    "raw_reports":16,"profile_vms":4,"providers_per_shared_vm":4,"pairs_per_provider_profile":2,"warmups_per_backend":1,"fixed_pushes_per_trial":32,"verified_fetches_per_trial":56,
    "internal_checksums_verified":sum(int((p/"checksum-verification.txt").read_text().split()[1]) for p in (ROOT/"profiles").iterdir())+int((ROOT/"scores/checksum-verification.txt").read_text().split()[1]),
    "source_binary_runtime_identity":"Pinned full provider commit and tree refs, four distinct native source trees and native binary hashes, common runner/scorer/Worker/reference Git, strict report binary and source SHA256 ties.",
    "fresh_state":"All providers share a profile VM but use distinct Worker PIDs, state directories and report namespaces. All warmup and measured first pushes start generation 0. All sources clean after measurements.",
    "receipts":"Complete accounting, no binding failures, complete 32-push/56-fetch schedules and backend verification; fetches retain nonempty packs with strict fsck, archive and tree/want verification. Every original report and full tail retained.",
    "counter_scope":"Fixed objective prices exactly summed measured push/fetch row receipts. Whole observed workload counters also include startup and are separately labelled. No whole counter is paired with the fixed objective.",
    "offline_reproduction":"Frozen evaluator 01b36df2f5f2019eeb09ebe79eb8ae80e9f86d0cdf39667c9fec9b0584e61fb8 has unchanged evaluator source; all four scores and all six comparisons match CI byte for byte.",
    "correlation":"Intermediate suites were freshly measured once in this prospectively declared batch and are shared across all six comparisons; they are correlated observations, not additional independent pairs.",
    "formal_result":"All two-pair screen comparisons are inconclusive; no formal plateau or speed claim. Full five-pair validation is separate.",
    "full_hosting_cost_usd":None,"unknown_billing_dimensions":["Worker CPU-ms","Durable Object duration","monthly SQLite storage","native codec compute"],
    "timing_limit":"Client elapsed time is never inferred as billed CPU. Workerd header timing does not establish full HTTP completion."
}
(ROOT / "INDEPENDENT_REVIEW.json").write_text(json.dumps(review,indent=2)+"\n")
print(json.dumps({"raw_reports":len(raw),"artifacts":len(artifacts),"total_archive_bytes":sum(a["tar_gz_bytes"] for a in artifacts),"verified_internal_checksums":review["internal_checksums_verified"],"distinct_profile_boots":len(set(boots))}))
